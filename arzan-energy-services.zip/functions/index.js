/**
 * ITI Trainee Attendance System - Firebase Cloud Functions
 * Secure Backend Administration, Auth User Deletion, GPS Validation & Notifications
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");

if (admin.apps.length === 0) {
  admin.initializeApp();
}
const db = admin.firestore();

/**
 * Calculates distance between two GPS coordinates in meters using the Haversine formula
 */
function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371000; // Earth radius in meters
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * ---------------------------------------------------------------------------------
 * 1. SECURE CLOUD CALLABLE: deleteUserAccount
 * Securely deletes a user from Firebase Authentication & Cloud Firestore using Admin SDK
 * ---------------------------------------------------------------------------------
 */
exports.deleteUserAccount = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "The function must be called while authenticated."
    );
  }

  const callerUid = context.auth.uid;
  const targetUid = data.targetUid || data.uid;
  const role = data.role || "instructor";

  if (!targetUid) {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "targetUid is required."
    );
  }

  // Verify caller is an Admin
  const adminDoc = await db.collection("admins").doc(callerUid).get();
  if (!adminDoc.exists) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "Only ITI administrators have permission to delete user accounts."
    );
  }

  try {
    // 1. Delete from Firebase Authentication (Admin SDK)
    try {
      await admin.auth().deleteUser(targetUid);
      console.log(`[Admin SDK] Successfully deleted user ${targetUid} from Firebase Auth.`);
    } catch (authErr) {
      console.warn(`[Admin SDK] Auth deletion notice for ${targetUid}:`, authErr.message);
    }

    // 2. Clean up Firestore documents
    const batch = db.batch();
    batch.delete(db.collection("users").doc(targetUid));

    if (role === "instructor") {
      batch.delete(db.collection("instructors").doc(targetUid));

      // Clean up instructor diary notes
      const notesSnap = await db.collection("diary_notes").where("instructorId", "==", targetUid).get();
      notesSnap.forEach((doc) => batch.delete(doc.ref));

      // Clean up notifications
      const notifsSnap = await db.collection("notifications").where("targetUserId", "==", targetUid).get();
      notifsSnap.forEach((doc) => batch.delete(doc.ref));

      // Unassign trainees from this instructor
      const traineesSnap = await db.collection("trainees").where("instructorId", "==", targetUid).get();
      traineesSnap.forEach((doc) => {
        batch.update(doc.ref, {
          instructorId: "",
          instructorName: "Unassigned",
          updatedAt: Date.now(),
        });
      });
    } else if (role === "trainee") {
      batch.delete(db.collection("trainees").doc(targetUid));

      // Clean up trainee attendance
      const attSnap = await db.collection("attendance").where("traineeId", "==", targetUid).get();
      attSnap.forEach((doc) => batch.delete(doc.ref));
    } else if (role === "admin") {
      batch.delete(db.collection("admins").doc(targetUid));
    }

    await batch.commit();

    return {
      success: true,
      message: `User ${targetUid} permanently deleted from Firebase Auth and Firestore.`,
    };
  } catch (error) {
    console.error("Error executing deleteUserAccount:", error);
    throw new functions.https.HttpsError("internal", error.message);
  }
});

// Alias for deleteInstructor
exports.deleteInstructor = exports.deleteUserAccount;

/**
 * ---------------------------------------------------------------------------------
 * 2. FIRESTORE TRIGGER: onUserDeleted
 * Automatically deletes the Firebase Authentication record whenever a user document
 * is deleted in Firestore.
 * ---------------------------------------------------------------------------------
 */
exports.onUserDeleted = functions.firestore
  .document("users/{userId}")
  .onDelete(async (snap, context) => {
    const userId = context.params.userId;
    try {
      await admin.auth().deleteUser(userId);
      console.log(`[Firestore Trigger] Deleted user ${userId} from Firebase Auth on users doc deletion.`);
    } catch (error) {
      if (error.code !== "auth/user-not-found") {
        console.error(`[Firestore Trigger] Error deleting user ${userId} from Firebase Auth:`, error);
      }
    }
  });

/**
 * ---------------------------------------------------------------------------------
 * 3. FIRESTORE TRIGGER: onInstructorDeleted
 * Automatically deletes the Firebase Authentication record whenever an instructor document
 * is deleted in Firestore.
 * ---------------------------------------------------------------------------------
 */
exports.onInstructorDeleted = functions.firestore
  .document("instructors/{instructorId}")
  .onDelete(async (snap, context) => {
    const instructorId = context.params.instructorId;
    try {
      await admin.auth().deleteUser(instructorId);
      console.log(`[Firestore Trigger] Deleted instructor ${instructorId} from Firebase Auth.`);
    } catch (error) {
      if (error.code !== "auth/user-not-found") {
        console.error(`[Firestore Trigger] Error deleting instructor ${instructorId} from Firebase Auth:`, error);
      }
    }
  });

/**
 * ---------------------------------------------------------------------------------
 * 4. FIRESTORE TRIGGER: onDeletionRequest
 * Processes deletion requests created in the `deletion_requests` collection.
 * ---------------------------------------------------------------------------------
 */
exports.onDeletionRequest = functions.firestore
  .document("deletion_requests/{targetUid}")
  .onCreate(async (snap, context) => {
    const targetUid = context.params.targetUid;
    try {
      await admin.auth().deleteUser(targetUid);
      console.log(`[Deletion Request] Deleted user ${targetUid} from Firebase Auth.`);
    } catch (error) {
      if (error.code !== "auth/user-not-found") {
        console.error(`[Deletion Request] Error deleting user ${targetUid}:`, error);
      }
    }
    // Delete the request doc after processing
    try {
      await snap.ref.delete();
    } catch (_) {}
  });

/**
 * ---------------------------------------------------------------------------------
 * 5. SERVER-SIDE GPS ATTENDANCE VALIDATION
 * ---------------------------------------------------------------------------------
 */
exports.markAttendance = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError(
      "unauthenticated",
      "User must be authenticated."
    );
  }

  const traineeUid = context.auth.uid;
  const { latitude, longitude, isMockLocation, punchType } = data;

  if (typeof latitude !== "number" || typeof longitude !== "number") {
    throw new functions.https.HttpsError(
      "invalid-argument",
      "Valid GPS coordinates are required."
    );
  }

  if (isMockLocation) {
    throw new functions.https.HttpsError(
      "permission-denied",
      "Attendance rejected: Simulated / Mock GPS location detected."
    );
  }

  const traineeDoc = await db.collection("trainees").doc(traineeUid).get();
  if (!traineeDoc.exists) {
    throw new functions.https.HttpsError("not-found", "Trainee profile not found.");
  }
  const trainee = traineeDoc.data();
  if (trainee.status !== "approved") {
    throw new functions.https.HttpsError(
      "failed-precondition",
      "Trainee account is not approved by administration."
    );
  }

  const settingsDoc = await db.collection("instituteSettings").doc("current").get();
  let instituteLat = 33.7314;
  let instituteLng = 75.1487;
  let allowedRadius = 100.0;
  let lateThreshold = "09:15";

  if (settingsDoc.exists) {
    const s = settingsDoc.data();
    instituteLat = s.latitude || instituteLat;
    instituteLng = s.longitude || instituteLng;
    allowedRadius = s.radiusMeters || allowedRadius;
    lateThreshold = s.lateTimeThreshold || lateThreshold;
  }

  const distance = calculateHaversineDistance(
    latitude,
    longitude,
    instituteLat,
    instituteLng
  );

  if (distance > allowedRadius) {
    throw new functions.https.HttpsError(
      "permission-denied",
      `Location rejected: You are ${distance.toFixed(1)}m away from institute. Must be within ${allowedRadius}m.`
    );
  }

  const now = new Date();
  const dateStr = now.toISOString().split("T")[0];
  const recordId = `${traineeUid}_${dateStr}`;
  const attendanceRef = db.collection("attendance").doc(recordId);

  const existingDoc = await attendanceRef.get();

  if (punchType === "in") {
    if (existingDoc.exists && existingDoc.data().punchInTime) {
      throw new functions.https.HttpsError(
        "already-exists",
        "Trainee has already punched in today."
      );
    }

    const hours = now.getHours().toString().padStart(2, "0");
    const mins = now.getMinutes().toString().padStart(2, "0");
    const currentTimeStr = `${hours}:${mins}`;
    const status = currentTimeStr > lateThreshold ? "late" : "present";

    const record = {
      attendanceId: recordId,
      traineeId: traineeUid,
      traineeUniqueId: trainee.traineeId || "ITI-TRAINEE",
      traineeName: trainee.name,
      tradeId: trainee.tradeId,
      tradeName: trainee.tradeName,
      date: dateStr,
      punchInTime: admin.firestore.FieldValue.serverTimestamp(),
      punchOutTime: null,
      punchInLatitude: latitude,
      punchInLongitude: longitude,
      punchInDistance: distance,
      attendanceStatus: status,
      isManualCorrection: false,
      remarks: status === "late" ? `Late arrival at ${currentTimeStr}` : null,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    };

    await attendanceRef.set(record);
    return { success: true, status, distance, message: `Punched in successfully as ${status.toUpperCase()}.` };
  } else if (punchType === "out") {
    if (!existingDoc.exists || !existingDoc.data().punchInTime) {
      throw new functions.https.HttpsError(
        "failed-precondition",
        "Must punch in before punching out."
      );
    }
    if (existingDoc.data().punchOutTime) {
      throw new functions.https.HttpsError(
        "already-exists",
        "Trainee has already punched out today."
      );
    }

    await attendanceRef.update({
      punchOutTime: admin.firestore.FieldValue.serverTimestamp(),
      punchOutLatitude: latitude,
      punchOutLongitude: longitude,
      punchOutDistance: distance,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    return { success: true, message: "Punched out successfully." };
  }

  throw new functions.https.HttpsError("invalid-argument", "Invalid punchType.");
});
