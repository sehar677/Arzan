package com.example.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Utility for persisting acknowledged notification IDs so that popup windows are displayed strictly once.
 */
object NotificationPreferenceManager {
    private const val PREFS_NAME = "iti_notifications_acknowledged_prefs"
    private const val KEY_ACKNOWLEDGED_IDS = "acknowledged_notification_ids"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private fun getUserKey(userId: String?): String {
        return if (!userId.isNullOrBlank()) "${KEY_ACKNOWLEDGED_IDS}_$userId" else KEY_ACKNOWLEDGED_IDS
    }

    fun getAcknowledgedNotificationIds(context: Context, userId: String? = null): Set<String> {
        val prefs = getPrefs(context)
        val globalSet = prefs.getStringSet(KEY_ACKNOWLEDGED_IDS, emptySet()) ?: emptySet()
        if (!userId.isNullOrBlank()) {
            val userSet = prefs.getStringSet(getUserKey(userId), emptySet()) ?: emptySet()
            return globalSet + userSet
        }
        return globalSet
    }

    fun isNotificationAcknowledged(context: Context, notificationId: String, userId: String? = null): Boolean {
        val set = getAcknowledgedNotificationIds(context, userId)
        return set.contains(notificationId)
    }

    fun markNotificationAcknowledged(context: Context, notificationId: String, userId: String? = null) {
        val prefs = getPrefs(context)
        val globalSet = prefs.getStringSet(KEY_ACKNOWLEDGED_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        globalSet.add(notificationId)
        val editor = prefs.edit().putStringSet(KEY_ACKNOWLEDGED_IDS, globalSet)
        if (!userId.isNullOrBlank()) {
            val userKey = getUserKey(userId)
            val userSet = prefs.getStringSet(userKey, emptySet())?.toMutableSet() ?: mutableSetOf()
            userSet.add(notificationId)
            editor.putStringSet(userKey, userSet)
        }
        editor.apply()
    }

    fun markNotificationsAcknowledged(context: Context, notificationIds: List<String>, userId: String? = null) {
        if (notificationIds.isEmpty()) return
        val prefs = getPrefs(context)
        val globalSet = prefs.getStringSet(KEY_ACKNOWLEDGED_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        globalSet.addAll(notificationIds)
        val editor = prefs.edit().putStringSet(KEY_ACKNOWLEDGED_IDS, globalSet)
        if (!userId.isNullOrBlank()) {
            val userKey = getUserKey(userId)
            val userSet = prefs.getStringSet(userKey, emptySet())?.toMutableSet() ?: mutableSetOf()
            userSet.addAll(notificationIds)
            editor.putStringSet(userKey, userSet)
        }
        editor.apply()
    }
}

