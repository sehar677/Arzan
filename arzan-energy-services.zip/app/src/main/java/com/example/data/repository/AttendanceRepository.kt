package com.example.data.repository

import com.example.data.model.AccountStatus
import com.example.data.model.AdminProfile
import com.example.data.model.AttendanceCorrection
import com.example.data.model.AttendanceRecord
import com.example.data.model.AttendanceStatus
import com.example.data.model.AuditLogEntry
import com.example.data.model.DashboardStats
import com.example.data.model.DistanceResult
import com.example.data.model.Holiday
import com.example.data.model.InstituteNotification
import com.example.data.model.InstituteSettings
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.model.TaskRecord
import com.example.data.model.sortedByTraineeIdAscending
import com.example.util.DateUtils
import com.example.util.LocationHelper
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.CancellationException
import java.util.Calendar
import java.util.UUID

class AttendanceRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    // Cached institute settings
    private var cachedSettings: InstituteSettings = InstituteSettings()

    // -------------------------------------------------------------
    // INSTITUTE SETTINGS
    // -------------------------------------------------------------

    suspend fun getInstituteSettings(): InstituteSettings {
        return try {
            val doc = firestore.collection("company_settings")
                .document("default")
                .get()
                .await()

            if (doc.exists()) {
                val settings = doc.toObject(InstituteSettings::class.java) ?: InstituteSettings()
                cachedSettings = settings
                settings
            } else {
                // Initialize default institute settings
                val defaultSettings = InstituteSettings()
                firestore.collection("company_settings").document("default").set(defaultSettings).await()
                cachedSettings = defaultSettings
                defaultSettings
            }
        } catch (_: Exception) {
            cachedSettings
        }
    }

    suspend fun updateInstituteSettings(
        settings: InstituteSettings,
        updatedBy: String,
        updatedByName: String,
        updatedByRole: String
    ): Boolean {
        return try {
            val updated = settings.copy(
                updatedAt = System.currentTimeMillis(),
                updatedBy = updatedByName
            )
            firestore.collection("company_settings")
                .document("default")
                .set(updated)
                .await()

            cachedSettings = updated

            recordAuditLog(
                action = "INSTITUTE_SETTINGS_UPDATED",
                performedBy = updatedBy,
                performedByName = updatedByName,
                performedByRole = updatedByRole,
                targetId = "default",
                targetType = "settings",
                oldValue = "Lat:${cachedSettings.latitude}, Lng:${cachedSettings.longitude}, Radius:${cachedSettings.radiusMeters}m",
                newValue = "Lat:${settings.latitude}, Lng:${settings.longitude}, Radius:${settings.radiusMeters}m",
                reason = "Admin updated GPS geofence / institute operational parameters"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    // -------------------------------------------------------------
    // HOLIDAY MANAGEMENT
    // -------------------------------------------------------------

    suspend fun getHolidays(): List<Holiday> {
        val settings = getInstituteSettings()
        return settings.holidays.sortedBy { it.date }
    }

    suspend fun addHoliday(
        date: String,
        name: String,
        description: String = "",
        adminId: String,
        adminName: String
    ): Boolean {
        return try {
            val cleanDate = date.replace("/", "-").trim()
            val cleanName = name.trim().ifBlank { "Institute Holiday" }
            val currentSettings = getInstituteSettings()

            // Avoid duplicate dates
            val existing = currentSettings.holidays.filter { it.date.replace("/", "-").trim() != cleanDate }
            val newHoliday = Holiday(
                holidayId = "hol_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}",
                date = cleanDate,
                name = cleanName,
                description = description.trim(),
                createdAt = System.currentTimeMillis(),
                createdBy = adminName.ifBlank { "Admin" }
            )
            val updatedHolidays = (existing + newHoliday).sortedBy { it.date }
            val updatedSettings = currentSettings.copy(
                holidays = updatedHolidays,
                updatedAt = System.currentTimeMillis(),
                updatedBy = adminName
            )

            firestore.collection("company_settings")
                .document("default")
                .set(updatedSettings)
                .await()

            cachedSettings = updatedSettings

            recordAuditLog(
                action = "HOLIDAY_MARKED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = newHoliday.holidayId,
                targetType = "holiday",
                oldValue = "",
                newValue = "$cleanDate: $cleanName",
                reason = "Admin marked $cleanDate as institute holiday ($cleanName)"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteHoliday(
        holidayId: String,
        adminId: String,
        adminName: String
    ): Boolean {
        return try {
            val currentSettings = getInstituteSettings()
            val removedHoliday = currentSettings.holidays.firstOrNull { it.holidayId == holidayId }
            val updatedHolidays = currentSettings.holidays.filter { it.holidayId != holidayId }
            val updatedSettings = currentSettings.copy(
                holidays = updatedHolidays,
                updatedAt = System.currentTimeMillis(),
                updatedBy = adminName
            )

            firestore.collection("company_settings")
                .document("default")
                .set(updatedSettings)
                .await()

            cachedSettings = updatedSettings

            recordAuditLog(
                action = "HOLIDAY_REMOVED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = holidayId,
                targetType = "holiday",
                oldValue = removedHoliday?.let { "${it.date}: ${it.name}" } ?: holidayId,
                newValue = "Deleted",
                reason = "Admin removed holiday for date ${removedHoliday?.date ?: holidayId}"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    // -------------------------------------------------------------
    // TRADE MANAGEMENT
    // -------------------------------------------------------------

    fun observeTrades(
        onUpdate: (List<Trade>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("profiles")
            .orderBy("tradeName", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { it.toObject(Trade::class.java) }
                onUpdate(list)
            }
    }

    suspend fun getTrades(): List<Trade> {
        return try {
            val snapshot = firestore.collection("profiles")
                .orderBy("tradeName", Query.Direction.ASCENDING)
                .get()
                .await()

            snapshot.documents.mapNotNull { it.toObject(Trade::class.java) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getTrade(tradeId: String): Trade? {
        if (tradeId.isBlank()) return null
        return try {
            val doc = firestore.collection("profiles").document(tradeId).get().await()
            doc.toObject(Trade::class.java)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun getActiveTrades(): List<Trade> {
        return getTrades().filter { it.status.equals("active", ignoreCase = true) }
    }

    suspend fun addTrade(trade: Trade, adminId: String, adminName: String): Boolean {
        return try {
            val tradeId = if (trade.tradeId.isNotBlank()) trade.tradeId else "trade_${System.currentTimeMillis()}"
            val newTrade = trade.copy(
                tradeId = tradeId,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            firestore.collection("profiles").document(tradeId).set(newTrade).await()

            recordAuditLog(
                action = "TRADE_CREATED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = tradeId,
                targetType = "trade",
                newValue = "${newTrade.tradeName} (${newTrade.tradeCode})",
                reason = "New trade added by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun updateTrade(trade: Trade, adminId: String, adminName: String): Boolean {
        return try {
            val updated = trade.copy(updatedAt = System.currentTimeMillis())
            firestore.collection("profiles").document(trade.tradeId).set(updated).await()

            // Update all instructors enrolled/registered in this trade so their profiles reflect the new trade name
            try {
                val instDocs = firestore.collection("dealers")
                    .whereEqualTo("tradeId", trade.tradeId)
                    .get()
                    .await()
                for (doc in instDocs.documents) {
                    doc.reference.update(
                        "tradeName", trade.tradeName,
                        "updatedAt", System.currentTimeMillis()
                    ).await()
                }
            } catch (_: Exception) {}

            // Update all trainees enrolled/registered in this trade so their profiles reflect the new trade name
            try {
                val traineeDocs = firestore.collection("staff")
                    .whereEqualTo("tradeId", trade.tradeId)
                    .get()
                    .await()
                for (doc in traineeDocs.documents) {
                    doc.reference.update(
                        "tradeName", trade.tradeName,
                        "updatedAt", System.currentTimeMillis()
                    ).await()
                }
            } catch (_: Exception) {}

            recordAuditLog(
                action = "TRADE_UPDATED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = trade.tradeId,
                targetType = "trade",
                newValue = "${trade.tradeName} (${trade.tradeCode})",
                reason = "Trade details modified"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun toggleTradeStatus(tradeId: String, currentStatus: String, adminId: String, adminName: String): Boolean {
        val newStatus = if (currentStatus.equals("active", ignoreCase = true)) "inactive" else "active"
        return try {
            firestore.collection("profiles").document(tradeId).update("status", newStatus, "updatedAt", System.currentTimeMillis()).await()

            recordAuditLog(
                action = "TRADE_STATUS_CHANGED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = tradeId,
                targetType = "trade",
                oldValue = currentStatus,
                newValue = newStatus,
                reason = "Trade status toggled by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteTrade(tradeId: String, tradeName: String, adminId: String, adminName: String): Boolean {
        return try {
            firestore.collection("profiles").document(tradeId).delete().await()

            recordAuditLog(
                action = "TRADE_DELETED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = tradeId,
                targetType = "trade",
                oldValue = tradeName,
                reason = "Trade permanently deleted by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    // -------------------------------------------------------------
    // INSTRUCTOR MANAGEMENT
    // -------------------------------------------------------------

    fun observeInstructors(
        onUpdate: (instructors: List<InstructorProfile>, pending: List<InstructorProfile>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("dealers")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val allList = snapshot.documents.mapNotNull { it.toObject(InstructorProfile::class.java) }
                    .distinctBy { it.uid.ifBlank { it.email } }
                val approvedOrInactive = allList.filter { !it.status.equals("pending", ignoreCase = true) }
                val pending = allList.filter { it.status.equals("pending", ignoreCase = true) }
                onUpdate(approvedOrInactive, pending)
            }
    }

    suspend fun getInstructors(): List<InstructorProfile> {
        return try {
            val snapshot = firestore.collection("dealers")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            val tradesMap = getTrades().associateBy { it.tradeId }
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(InstructorProfile::class.java)?.let { inst ->
                    val matchedTrade = tradesMap[inst.tradeId]
                    if (matchedTrade != null && matchedTrade.tradeName.isNotBlank() && matchedTrade.tradeName != inst.tradeName) {
                        inst.copy(tradeName = matchedTrade.tradeName)
                    } else {
                        inst
                    }
                }
            }.distinctBy { it.uid.ifBlank { it.email } }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getPendingInstructors(): List<InstructorProfile> {
        return try {
            val snapshot = firestore.collection("dealers")
                .whereEqualTo("status", "pending")
                .get()
                .await()
            val tradesMap = getTrades().associateBy { it.tradeId }
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(InstructorProfile::class.java)?.let { inst ->
                    val matchedTrade = tradesMap[inst.tradeId]
                    if (matchedTrade != null && matchedTrade.tradeName.isNotBlank() && matchedTrade.tradeName != inst.tradeName) {
                        inst.copy(tradeName = matchedTrade.tradeName)
                    } else {
                        inst
                    }
                }
            }.distinctBy { it.uid.ifBlank { it.email } }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getInstructorProfile(uid: String): InstructorProfile? {
        if (uid.isBlank()) return null
        return try {
            val doc = firestore.collection("dealers").document(uid).get().await()
            val inst = doc.toObject(InstructorProfile::class.java) ?: return null
            if (inst.tradeId.isNotBlank()) {
                val trade = getTrade(inst.tradeId)
                if (trade != null && trade.tradeName.isNotBlank() && trade.tradeName != inst.tradeName) {
                    return inst.copy(tradeName = trade.tradeName)
                }
            }
            inst
        } catch (_: Exception) {
            null
        }
    }

    suspend fun approveInstructor(
        instructorId: String,
        adminId: String,
        adminName: String
    ): Boolean {
        return try {
            val now = System.currentTimeMillis()
            firestore.collection("dealers").document(instructorId).update(
                "status", "approved",
                "approvedAt", now,
                "approvedBy", adminName,
                "updatedAt", now
            ).await()

            firestore.collection("users").document(instructorId).update(
                "status", "approved",
                "updatedAt", now
            ).await()

            recordAuditLog(
                action = "INSTRUCTOR_APPROVED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = instructorId,
                targetType = "instructor",
                oldValue = "pending",
                newValue = "approved",
                reason = "Instructor credentials verified and approved by admin"
            )

            sendNotification(
                title = "Dealer Account Approved",
                message = "Welcome! Your Dealer registration has been approved. You may now access your Dealer Console.",
                targetRole = "instructor",
                targetUserId = instructorId,
                senderName = adminName
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Calls the secure Firebase Cloud Function backend (which uses Firebase Admin SDK)
     * to permanently remove the target user from Firebase Authentication.
     */
    private suspend fun callDeleteUserCloudFunction(targetUid: String, role: String): Boolean {
        // 1. Create a deletion request in Firestore so cloud triggers can catch it immediately
        try {
            firestore.collection("deletion_requests").document(targetUid).set(
                mapOf(
                    "targetUid" to targetUid,
                    "role" to role,
                    "requestedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}

        // 2. Call the secure Callable Cloud Function
        return try {
            val functions = FirebaseFunctions.getInstance()
            val payload = hashMapOf(
                "uid" to targetUid,
                "targetUid" to targetUid,
                "role" to role
            )
            try {
                functions.getHttpsCallable("deleteUserAccount")
                    .call(payload)
                    .await()
                true
            } catch (_: Exception) {
                functions.getHttpsCallable("deleteInstructor")
                    .call(payload)
                    .await()
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    private suspend fun deleteAuthUserIfPossible(uid: String, role: String = "instructor") {
        // First invoke secure backend Cloud Function (Firebase Admin SDK)
        callDeleteUserCloudFunction(uid, role)
        // Client-side self-deletion only if current auth session happens to match the uid
        try {
            val auth = com.google.firebase.auth.FirebaseAuth.getInstance()
            if (auth.currentUser?.uid == uid) {
                auth.currentUser?.delete()?.await()
            }
        } catch (_: Exception) {}
    }

    suspend fun rejectInstructor(
        instructorId: String,
        reason: String,
        adminId: String,
        adminName: String
    ): Boolean {
        return try {
            // 1. Securely delete from Firebase Auth via Backend Cloud Function
            callDeleteUserCloudFunction(instructorId, "instructor")

            // 2. Delete Firestore instructor and user profile documents
            firestore.collection("dealers").document(instructorId).delete().await()
            firestore.collection("users").document(instructorId).delete().await()

            // 3. Clean up related notifications
            try {
                val notifs = firestore.collection("notifications")
                    .whereEqualTo("targetUserId", instructorId)
                    .get()
                    .await()
                for (doc in notifs.documents) {
                    doc.reference.delete().await()
                }
            } catch (_: Exception) {}

            recordAuditLog(
                action = "INSTRUCTOR_REJECTED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = instructorId,
                targetType = "instructor",
                oldValue = "pending",
                newValue = "deleted",
                reason = "Rejected and account/email removed: $reason"
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun toggleInstructorStatus(instructorId: String, currentStatus: String, adminId: String, adminName: String): Boolean {
        val newStatus = if (currentStatus.equals("approved", ignoreCase = true)) "inactive" else "approved"
        return try {
            val now = System.currentTimeMillis()
            firestore.collection("dealers").document(instructorId).update(
                "status", newStatus,
                "updatedAt", now
            ).await()

            firestore.collection("users").document(instructorId).update(
                "status", newStatus,
                "updatedAt", now
            ).await()

            recordAuditLog(
                action = "INSTRUCTOR_STATUS_CHANGED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = instructorId,
                targetType = "instructor",
                oldValue = currentStatus,
                newValue = newStatus,
                reason = "Instructor status changed to $newStatus by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteInstructor(instructorId: String, instructorName: String, adminId: String, adminName: String): Boolean {
        return try {
            // 1. Securely delete from Firebase Authentication using backend Cloud Function (Firebase Admin SDK)
            callDeleteUserCloudFunction(instructorId, "instructor")

            // 2. Delete main Firestore profile & user documents
            firestore.collection("dealers").document(instructorId).delete().await()
            firestore.collection("users").document(instructorId).delete().await()

            // 3. Delete any related user-specific subcollections and records
            // a) Delete all diary notes posted by this instructor
            try {
                val diarySnapshot = firestore.collection("diary_notes")
                    .whereEqualTo("instructorId", instructorId)
                    .get()
                    .await()
                for (doc in diarySnapshot.documents) {
                    doc.reference.delete().await()
                }
            } catch (_: Exception) {}

            // b) Delete all notifications sent to this instructor
            try {
                val notifSnapshot = firestore.collection("notifications")
                    .whereEqualTo("targetUserId", instructorId)
                    .get()
                    .await()
                for (doc in notifSnapshot.documents) {
                    doc.reference.delete().await()
                }
            } catch (_: Exception) {}

            // c) Unlink instructor from any trainees currently assigned to them
            try {
                val traineeSnapshot = firestore.collection("staff")
                    .whereEqualTo("instructorId", instructorId)
                    .get()
                    .await()
                for (doc in traineeSnapshot.documents) {
                    doc.reference.update(
                        mapOf(
                            "instructorId" to "",
                            "instructorName" to "Unassigned",
                            "updatedAt" to System.currentTimeMillis()
                        )
                    ).await()
                }
            } catch (_: Exception) {}

            // 4. Record audit log
            recordAuditLog(
                action = "INSTRUCTOR_DELETED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = instructorId,
                targetType = "instructor",
                oldValue = instructorName,
                reason = "Instructor permanently deleted by admin (Auth, Firestore, and related records)"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    // -------------------------------------------------------------
    // TRAINEE MANAGEMENT
    // -------------------------------------------------------------

    /**
     * Generates a guaranteed unique Trainee ID (e.g. ITI-2026-00001) by scanning
     * all existing trainee records in Firestore to find the maximum current sequence number
     * and avoiding any collisions.
     */
    suspend fun generateUniqueTraineeId(): String {
        val year = Calendar.getInstance().get(Calendar.YEAR)
        return try {
            val snapshot = firestore.collection("staff").get().await()
            val existingIds = HashSet<String>()
            var maxSeq = 0

            for (doc in snapshot.documents) {
                val tid = doc.getString("traineeId")?.trim()?.uppercase()
                if (!tid.isNullOrBlank() && tid != "PENDING") {
                    existingIds.add(tid)
                    val parts = tid.split("-")
                    if (parts.isNotEmpty()) {
                        val lastPart = parts.last()
                        val num = lastPart.toIntOrNull()
                        if (num != null && num > maxSeq) {
                            maxSeq = num
                        }
                    }
                }
            }

            var nextSeq = maxSeq + 1
            var candidate = String.format("STF-%d-%05d", year, nextSeq)

            while (existingIds.contains(candidate)) {
                nextSeq++
                candidate = String.format("STF-%d-%05d", year, nextSeq)
            }

            candidate
        } catch (_: Exception) {
            val rand = (10000..99999).random()
            String.format("STF-%d-%05d", year, rand)
        }
    }

    /**
     * Detects and automatically resolves any duplicate Trainee IDs in Firestore.
     */
    private suspend fun sanitizeDuplicateTraineeIds(trainees: List<TraineeProfile>): List<TraineeProfile> {
        if (trainees.isEmpty()) return trainees

        val seenIds = mutableMapOf<String, String>() // traineeId -> uid
        val result = mutableListOf<TraineeProfile>()

        for (trainee in trainees) {
            val tid = trainee.traineeId.trim().uppercase()
            if (tid.isNotBlank() && tid != "PENDING") {
                if (seenIds.containsKey(tid)) {
                    // Duplicate detected! Re-assign a unique Trainee ID to this duplicate trainee
                    val newUniqueId = generateUniqueTraineeId()
                    val updatedTrainee = trainee.copy(traineeId = newUniqueId)

                    try {
                        firestore.collection("staff").document(trainee.uid).update("traineeId", newUniqueId).await()
                    } catch (_: Exception) {}

                    result.add(updatedTrainee)
                } else {
                    seenIds[tid] = trainee.uid
                    result.add(trainee)
                }
            } else {
                result.add(trainee)
            }
        }
        return result
    }

    fun observeTrainees(
        onUpdate: (trainees: List<TraineeProfile>, pending: List<TraineeProfile>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("staff")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val allList = snapshot.documents.mapNotNull { it.toObject(TraineeProfile::class.java) }
                val approvedOrInactive = allList.filter { !it.status.equals("pending", ignoreCase = true) }.sortedByTraineeIdAscending()
                val pending = allList.filter { it.status.equals("pending", ignoreCase = true) }.sortedByTraineeIdAscending()
                onUpdate(approvedOrInactive, pending)
            }
    }

    suspend fun getTrainees(): List<TraineeProfile> {
        return try {
            val snapshot = firestore.collection("staff")
                .get()
                .await()
            val list = snapshot.documents.mapNotNull { it.toObject(TraineeProfile::class.java) }
            sanitizeDuplicateTraineeIds(list).sortedByTraineeIdAscending()
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getTraineesByTrade(tradeId: String): List<TraineeProfile> {
        return try {
            val snapshot = firestore.collection("staff")
                .whereEqualTo("tradeId", tradeId)
                .get()
                .await()
            val list = snapshot.documents.mapNotNull { it.toObject(TraineeProfile::class.java) }
            sanitizeDuplicateTraineeIds(list).sortedByTraineeIdAscending()
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getPendingTrainees(): List<TraineeProfile> {
        return try {
            val snapshot = firestore.collection("staff")
                .whereEqualTo("status", "pending")
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(TraineeProfile::class.java) }.sortedByTraineeIdAscending()
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getPendingTraineesByTrade(tradeId: String): List<TraineeProfile> {
        return try {
            val snapshot = firestore.collection("staff")
                .whereEqualTo("tradeId", tradeId)
                .whereEqualTo("status", "pending")
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(TraineeProfile::class.java) }.sortedByTraineeIdAscending()
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Approves a trainee, assigns a guaranteed unique Trainee ID (e.g. ITI-2026-00001),
     * updates both trainees and users collection, and writes an audit log.
     */
    suspend fun approveTrainee(
        traineeUid: String,
        reviewerId: String,
        reviewerName: String,
        reviewerRole: String
    ): Boolean {
        return try {
            val traineeDoc = firestore.collection("staff").document(traineeUid).get().await()
            val existingTraineeId = traineeDoc.getString("traineeId")?.trim()?.uppercase()

            val generatedTraineeId = if (!existingTraineeId.isNullOrBlank() && existingTraineeId != "PENDING") {
                existingTraineeId
            } else {
                generateUniqueTraineeId()
            }

            val now = System.currentTimeMillis()

            firestore.collection("staff").document(traineeUid).update(
                "status", "approved",
                "traineeId", generatedTraineeId,
                "approvedAt", now,
                "approvedBy", reviewerName,
                "updatedAt", now
            ).await()

            firestore.collection("users").document(traineeUid).update(
                "status", "approved",
                "updatedAt", now
            ).await()

            recordAuditLog(
                action = "TRAINEE_APPROVED",
                performedBy = reviewerId,
                performedByName = reviewerName,
                performedByRole = reviewerRole,
                targetId = traineeUid,
                targetType = "trainee",
                oldValue = "pending",
                newValue = "approved (ID: $generatedTraineeId)",
                reason = "Trainee application verified and approved"
            )

            sendNotification(
                title = "Registration Approved",
                message = "Congratulations! Your Registration is approved. You can now punch daily attendance and handle Orders.",
                targetRole = "trainee",
                targetUserId = traineeUid,
                senderName = reviewerName
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun rejectTrainee(
        traineeUid: String,
        reason: String,
        reviewerId: String,
        reviewerName: String,
        reviewerRole: String
    ): Boolean {
        return try {
            firestore.collection("staff").document(traineeUid).delete().await()
            firestore.collection("users").document(traineeUid).delete().await()
            deleteAuthUserIfPossible(traineeUid)

            val attendanceQuery = firestore.collection("attendance")
                .whereEqualTo("traineeId", traineeUid)
                .get()
                .await()
            for (doc in attendanceQuery.documents) {
                doc.reference.delete().await()
            }

            recordAuditLog(
                action = "TRAINEE_REJECTED",
                performedBy = reviewerId,
                performedByName = reviewerName,
                performedByRole = reviewerRole,
                targetId = traineeUid,
                targetType = "trainee",
                oldValue = "pending",
                newValue = "deleted",
                reason = "Rejected and account/email removed: $reason"
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun toggleTraineeStatus(traineeUid: String, currentStatus: String, adminId: String, adminName: String): Boolean {
        val newStatus = if (currentStatus.equals("approved", ignoreCase = true)) "inactive" else "approved"
        return try {
            val now = System.currentTimeMillis()
            val traineeDoc = firestore.collection("staff").document(traineeUid).get().await()
            val currentTraineeId = traineeDoc.getString("traineeId")?.trim()?.uppercase()

            val updates = mutableMapOf<String, Any>(
                "status" to newStatus,
                "updatedAt" to now
            )

            if (newStatus == "approved" && (currentTraineeId.isNullOrBlank() || currentTraineeId == "PENDING")) {
                updates["traineeId"] = generateUniqueTraineeId()
            }

            firestore.collection("staff").document(traineeUid).update(updates).await()

            firestore.collection("users").document(traineeUid).update(
                "status", newStatus,
                "updatedAt", now
            ).await()

            recordAuditLog(
                action = "TRAINEE_STATUS_CHANGED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = traineeUid,
                targetType = "trainee",
                oldValue = currentStatus,
                newValue = newStatus,
                reason = "Trainee status toggled by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteTrainee(traineeUid: String, traineeName: String, adminId: String, adminName: String): Boolean {
        return try {
            firestore.collection("staff").document(traineeUid).delete().await()
            firestore.collection("users").document(traineeUid).delete().await()
            deleteAuthUserIfPossible(traineeUid)

            val attendanceQuery = firestore.collection("attendance")
                .whereEqualTo("traineeId", traineeUid)
                .get()
                .await()
            for (doc in attendanceQuery.documents) {
                doc.reference.delete().await()
            }

            recordAuditLog(
                action = "TRAINEE_DELETED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = traineeUid,
                targetType = "trainee",
                oldValue = traineeName,
                reason = "Trainee and all records permanently deleted by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun updateTraineeProfile(
        traineeUid: String,
        name: String,
        parentage: String,
        contact: String,
        guardianContact: String,
        email: String,
        address: String,
        parentAccessPin: String,
        updatedBy: String,
        updatedByName: String,
        updatedByRole: String
    ): Boolean {
        return try {
            val now = System.currentTimeMillis()
            val updates = mapOf(
                "name" to name,
                "parentage" to parentage,
                "contact" to contact,
                "guardianContact" to guardianContact,
                "email" to email,
                "address" to address,
                "parentAccessPin" to parentAccessPin,
                "updatedAt" to now
            )
            firestore.collection("staff").document(traineeUid).update(updates).await()
            firestore.collection("users").document(traineeUid).update(
                "name", name,
                "email", email,
                "updatedAt", now
            ).await()

            recordAuditLog(
                action = "TRAINEE_UPDATED",
                performedBy = updatedBy,
                performedByName = updatedByName,
                performedByRole = updatedByRole,
                targetId = traineeUid,
                targetType = "trainee",
                newValue = "$name ($contact)",
                reason = "Trainee profile details modified"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun updateInstructorProfile(
        instructorId: String,
        name: String,
        companyName: String = "",
        contact: String,
        adminId: String,
        adminName: String
    ): Boolean {
        return try {
            val now = System.currentTimeMillis()
            val updates = mapOf(
                "name" to name,
                "companyName" to companyName,
                "contact" to contact,
                "updatedAt" to now
            )
            firestore.collection("dealers").document(instructorId).update(updates).await()
            try {
                firestore.collection("users").document(instructorId).update(
                    mapOf(
                        "name" to name,
                        "updatedAt" to now
                    )
                ).await()
            } catch (_: Exception) {}

            try {
                val traineeSnapshot = firestore.collection("staff")
                    .whereEqualTo("instructorId", instructorId)
                    .get()
                    .await()
                for (doc in traineeSnapshot.documents) {
                    doc.reference.update("instructorName", name).await()
                }
            } catch (_: Exception) {}

            recordAuditLog(
                action = "INSTRUCTOR_UPDATED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = instructorId,
                targetType = "instructor",
                newValue = "$name ($contact)",
                reason = "Instructor profile modified by admin"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun updateDealerSelfProfile(
        instructorId: String,
        name: String,
        companyName: String = "",
        contact: String,
        aadhaarNo: String,
        panNo: String,
        businessAddress: String,
        residentialAddress: String,
        alternateNo: String
    ): Boolean {
        return try {
            val now = System.currentTimeMillis()
            val updates = mapOf(
                "name" to name,
                "companyName" to companyName,
                "contact" to contact,
                "aadhaarNo" to aadhaarNo,
                "panNo" to panNo,
                "businessAddress" to businessAddress,
                "residentialAddress" to residentialAddress,
                "alternateNo" to alternateNo,
                "updatedAt" to now
            )
            firestore.collection("dealers").document(instructorId).update(updates).await()
            try {
                firestore.collection("users").document(instructorId).update(
                    mapOf(
                        "name" to name,
                        "updatedAt" to now
                    )
                ).await()
            } catch (_: Exception) {}

            try {
                val traineeSnapshot = firestore.collection("staff")
                    .whereEqualTo("instructorId", instructorId)
                    .get()
                    .await()
                for (doc in traineeSnapshot.documents) {
                    doc.reference.update("instructorName", name).await()
                }
            } catch (_: Exception) {}

            recordAuditLog(
                action = "DEALER_SELF_UPDATED",
                performedBy = instructorId,
                performedByName = name,
                performedByRole = "instructor",
                targetId = instructorId,
                targetType = "instructor",
                newValue = "$name ($contact)",
                reason = "Dealer updated own profile"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    // -------------------------------------------------------------
    // ATTENDANCE CORE (GPS VALIDATION & ONE DOCUMENT PER DAY)
    // -------------------------------------------------------------

    suspend fun getTraineeProfile(traineeUid: String): TraineeProfile? {
        return try {
            val doc = firestore.collection("staff").document(traineeUid).get().await()
            if (doc.exists()) doc.toObject(TraineeProfile::class.java) else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Fetch the attendance document for a specific trainee and date.
     * Document ID format: "{traineeUid}_{YYYY-MM-DD}"
     */
    suspend fun getTodayAttendance(traineeUid: String, date: String = DateUtils.getTodayDateString()): AttendanceRecord? {
        val docId = "${traineeUid}_$date"
        return try {
            val doc = firestore.collection("attendance").document(docId).get().await()
            if (doc.exists()) doc.toObject(AttendanceRecord::class.java) else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * PUNCH IN:
     * - Requires trainee status == approved
     * - Verifies GPS distance <= 100 meters
     * - Enforces one attendance record per day (prevents duplicate punch in)
     * - Determines PRESENT vs LATE based on institute lateTimeThreshold
     */
    suspend fun punchIn(
        trainee: TraineeProfile,
        currentLat: Double,
        currentLng: Double,
        isMock: Boolean = false
    ): Result<AttendanceRecord> {
        val latestProfile = getTraineeProfile(trainee.uid)
        val currentStatus = latestProfile?.status ?: trainee.status
        if (!currentStatus.equals("approved", ignoreCase = true)) {
            val errorMsg = if (currentStatus.equals("inactive", ignoreCase = true)) {
                "Your account has been deactivated by administration. You cannot mark attendance."
            } else {
                "Account status is '$currentStatus'. Attendance marking is restricted to active approved trainees."
            }
            return Result.failure(Exception(errorMsg))
        }

        val settings = getInstituteSettings()
        val verification = LocationHelper.verifyLocation(currentLat, currentLng, settings)

        if (!verification.isWithinRadius) {
            return Result.failure(
                Exception("Outside Institute (${String.format("%.1f", verification.distanceMeters)}m away). You must be within ${settings.radiusMeters.toInt()}m of the institute to punch in.")
            )
        }

        val todayDate = DateUtils.getTodayDateString()
        val docId = "${trainee.uid}_$todayDate"

        // Check if attendance already exists
        val existingDoc = firestore.collection("attendance").document(docId).get().await()
        if (existingDoc.exists()) {
            val existing = existingDoc.toObject(AttendanceRecord::class.java)
            if (existing?.punchInTime != null) {
                return Result.failure(Exception("Attendance already marked for today at ${DateUtils.formatTime(existing.punchInTime)}."))
            }
        }

        val now = System.currentTimeMillis()
        val isLatePunch = DateUtils.isLate(now, settings.lateTimeThreshold)
        val status = if (isLatePunch) AttendanceStatus.LATE.statusName else AttendanceStatus.PRESENT.statusName

        val remarks = buildString {
            if (isLatePunch) append("Late arrival (after ${settings.lateTimeThreshold}). ")
            if (isMock) append("[Mock location warning flagged]. ")
        }.trim().ifEmpty { null }

        val record = AttendanceRecord(
            attendanceId = docId,
            traineeId = trainee.uid,
            traineeUniqueId = trainee.traineeId,
            traineeName = trainee.name,
            tradeId = trainee.tradeId,
            tradeName = trainee.tradeName,
            instructorId = trainee.instructorId,
            date = todayDate,
            punchInTime = now,
            punchInLatitude = currentLat,
            punchInLongitude = currentLng,
            punchInDistance = verification.distanceMeters,
            attendanceStatus = status,
            remarks = remarks,
            createdAt = now,
            updatedAt = now
        )

        return try {
            firestore.collection("attendance").document(docId).set(record).await()

            // Send notification for late arrival or punch in
            if (isLatePunch) {
                sendNotification(
                    title = "Late Punch In Recorded",
                    message = "${trainee.name} (${trainee.traineeId}) punched in late at ${DateUtils.formatTime(now)}.",
                    targetRole = "instructor",
                    targetTradeId = trainee.tradeId,
                    senderName = "Attendance Engine"
                )
            }
            Result.success(record)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * PUNCH OUT:
     * - Requires trainee to have already punched in today
     * - Verifies GPS distance <= 100 meters
     * - Prevents duplicate punch out
     */
    suspend fun punchOut(
        trainee: TraineeProfile,
        currentLat: Double,
        currentLng: Double,
        isMock: Boolean = false
    ): Result<AttendanceRecord> {
        val latestProfile = getTraineeProfile(trainee.uid)
        val currentStatus = latestProfile?.status ?: trainee.status
        if (!currentStatus.equals("approved", ignoreCase = true)) {
            val errorMsg = if (currentStatus.equals("inactive", ignoreCase = true)) {
                "Your account has been deactivated by administration. You cannot mark attendance."
            } else {
                "Account status is '$currentStatus'. Attendance marking is restricted to active approved trainees."
            }
            return Result.failure(Exception(errorMsg))
        }

        val todayDate = DateUtils.getTodayDateString()
        val docId = "${trainee.uid}_$todayDate"

        val docRef = firestore.collection("attendance").document(docId)
        val docSnap = docRef.get().await()

        if (!docSnap.exists()) {
            return Result.failure(Exception("Please Punch In first before Punch Out."))
        }

        val existing = docSnap.toObject(AttendanceRecord::class.java)
            ?: return Result.failure(Exception("Could not read today's attendance record."))

        if (existing.punchInTime == null) {
            return Result.failure(Exception("Please Punch In first before Punch Out."))
        }

        if (existing.punchOutTime != null) {
            return Result.failure(Exception("Today's attendance is already completed. Punched out at ${DateUtils.formatTime(existing.punchOutTime)}."))
        }

        val settings = getInstituteSettings()
        val verification = LocationHelper.verifyLocation(currentLat, currentLng, settings)

        if (!verification.isWithinRadius) {
            return Result.failure(
                Exception("Punch Out Not Allowed. Outside Institute (${String.format("%.1f", verification.distanceMeters)}m away). You must be within ${settings.radiusMeters.toInt()}m of the institute.")
            )
        }

        val now = System.currentTimeMillis()
        val updatedRecord = existing.copy(
            punchOutTime = now,
            punchOutLatitude = currentLat,
            punchOutLongitude = currentLng,
            punchOutDistance = verification.distanceMeters,
            updatedAt = now
        )

        return try {
            docRef.set(updatedRecord).await()
            Result.success(updatedRecord)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Retrieve all attendance records for a specific date (Daily Attendance)
     */
    suspend fun getDailyAttendance(date: String = DateUtils.getTodayDateString()): List<AttendanceRecord> {
        return try {
            val snapshot = firestore.collection("attendance")
                .whereEqualTo("date", date)
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Observe daily attendance in real-time
     */
    fun observeDailyAttendance(
        date: String = DateUtils.getTodayDateString(),
        onUpdate: (List<AttendanceRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("attendance")
            .whereEqualTo("date", date)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                onUpdate(list)
            }
    }

    /**
     * Retrieve attendance records for an entire month (e.g. "2026-08")
     */
    suspend fun getMonthlyAttendance(yearMonth: String): List<AttendanceRecord> {
        val normalizedYm = yearMonth.replace("/", "-")
        return try {
            val allSnap = firestore.collection("attendance").get().await()
            val list = allSnap.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                .filter { rec ->
                    val d = rec.date.replace("/", "-")
                    d.startsWith(normalizedYm)
                }
                .distinctBy { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }
                .sortedWith(compareByDescending<AttendanceRecord> { it.date }.thenBy { it.traineeName })
            list
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            android.util.Log.e("AttendanceRepository", "Error getting monthly attendance: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Retrieve attendance records for a specific trade and date
     */
    suspend fun getTradeAttendance(
        tradeId: String,
        date: String = DateUtils.getTodayDateString(),
        tradeName: String = "",
        traineeUids: Set<String> = emptySet()
    ): List<AttendanceRecord> {
        val normalizedDate = date.replace("/", "-")
        val cleanTradeId = tradeId.trim()
        val cleanTradeName = tradeName.trim()

        return try {
            val records = mutableListOf<AttendanceRecord>()

            if (cleanTradeId.isNotBlank()) {
                val snapshot = firestore.collection("attendance")
                    .whereEqualTo("tradeId", cleanTradeId)
                    .get()
                    .await()
                val list = snapshot.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                records.addAll(list.filter { it.date.replace("/", "-") == normalizedDate })
            }

            if (records.isEmpty()) {
                val dailyList = getDailyAttendance(date)
                val filtered = dailyList.filter { rec ->
                    val tradeMatches = (cleanTradeId.isNotBlank() && (rec.tradeId.equals(cleanTradeId, ignoreCase = true) || rec.tradeId.equals(cleanTradeName, ignoreCase = true))) ||
                            (cleanTradeName.isNotBlank() && (rec.tradeName.equals(cleanTradeName, ignoreCase = true) || rec.tradeName.equals(cleanTradeId, ignoreCase = true))) ||
                            (traineeUids.isNotEmpty() && (traineeUids.contains(rec.traineeId) || traineeUids.contains(rec.traineeUniqueId)))
                    tradeMatches
                }
                records.addAll(filtered)
            }

            records.distinctBy { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }
                .sortedBy { it.traineeName }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Retrieve attendance records for a specific trade across an entire month
     */
    suspend fun getTradeMonthlyAttendance(
        tradeId: String,
        yearMonth: String = DateUtils.getTodayDateString().take(7),
        tradeName: String = "",
        traineeUids: Set<String> = emptySet()
    ): List<AttendanceRecord> {
        val normalizedYm = yearMonth.replace("/", "-")
        val cleanTradeId = tradeId.trim()
        val cleanTradeName = tradeName.trim()

        return try {
            val records = mutableListOf<AttendanceRecord>()

            // 1. Single-field query by tradeId (No composite index required)
            if (cleanTradeId.isNotBlank()) {
                val snapshot = firestore.collection("attendance")
                    .whereEqualTo("tradeId", cleanTradeId)
                    .get()
                    .await()
                val list = snapshot.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                records.addAll(list.filter {
                    val d = it.date.replace("/", "-")
                    d.startsWith(normalizedYm)
                })
            }

            // 2. Query by tradeName if records empty and tradeName provided
            if (records.isEmpty() && cleanTradeName.isNotBlank()) {
                val snapshotByName = firestore.collection("attendance")
                    .whereEqualTo("tradeName", cleanTradeName)
                    .get()
                    .await()
                val list = snapshotByName.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                records.addAll(list.filter {
                    val d = it.date.replace("/", "-")
                    d.startsWith(normalizedYm)
                })
            }

            // 3. Robust fallback: Fetch all attendance docs and filter in memory by trade / trainee / tradeName and date
            if (records.isEmpty()) {
                val allSnap = firestore.collection("attendance").get().await()
                val allRecords = allSnap.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }

                val filtered = allRecords.filter { rec ->
                    val dateMatches = rec.date.replace("/", "-").startsWith(normalizedYm)
                    if (!dateMatches) return@filter false

                    val tradeIdMatches = cleanTradeId.isNotBlank() && (
                        rec.tradeId.equals(cleanTradeId, ignoreCase = true) ||
                        rec.tradeId.equals(cleanTradeName, ignoreCase = true)
                    )
                    val tradeNameMatches = cleanTradeName.isNotBlank() && (
                        rec.tradeName.equals(cleanTradeName, ignoreCase = true) ||
                        rec.tradeName.equals(cleanTradeId, ignoreCase = true)
                    )
                    val traineeMatches = traineeUids.isNotEmpty() && (
                        traineeUids.contains(rec.traineeId) ||
                        traineeUids.contains(rec.traineeUniqueId)
                    )

                    tradeIdMatches || tradeNameMatches || traineeMatches
                }
                records.addAll(filtered)
            }

            records.distinctBy { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }
                .sortedWith(compareByDescending<AttendanceRecord> { it.date }.thenBy { it.traineeName })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            android.util.Log.e("AttendanceRepository", "Error getting trade monthly attendance: ${e.message}", e)
            try {
                val allSnap = firestore.collection("attendance").get().await()
                allSnap.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                    .filter { rec ->
                        val dateMatches = rec.date.replace("/", "-").startsWith(normalizedYm)
                        val tradeMatches = (cleanTradeId.isNotBlank() && (rec.tradeId.equals(cleanTradeId, ignoreCase = true) || rec.tradeId.equals(cleanTradeName, ignoreCase = true))) ||
                                (cleanTradeName.isNotBlank() && rec.tradeName.equals(cleanTradeName, ignoreCase = true)) ||
                                (traineeUids.isNotEmpty() && (traineeUids.contains(rec.traineeId) || traineeUids.contains(rec.traineeUniqueId)))
                        dateMatches && tradeMatches
                    }
                    .distinctBy { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }
                    .sortedWith(compareByDescending<AttendanceRecord> { it.date }.thenBy { it.traineeName })
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    /**
     * Retrieve attendance history for an individual trainee
     */
    suspend fun getTraineeAttendanceHistory(traineeUid: String, traineeUniqueId: String = ""): List<AttendanceRecord> {
        if (traineeUid.isBlank() && traineeUniqueId.isBlank()) return emptyList()
        return try {
            val records = mutableListOf<AttendanceRecord>()

            // 1. Query by traineeId without orderBy (prevents composite index exception)
            if (traineeUid.isNotBlank()) {
                val snapshot1 = firestore.collection("attendance")
                    .whereEqualTo("traineeId", traineeUid)
                    .get()
                    .await()
                records.addAll(snapshot1.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) })
            }

            // 2. Query by traineeUniqueId if specified or matching traineeUid
            val targetUniqueId = traineeUniqueId.ifBlank { traineeUid }
            if (targetUniqueId.isNotBlank()) {
                val snapshot2 = firestore.collection("attendance")
                    .whereEqualTo("traineeUniqueId", targetUniqueId)
                    .get()
                    .await()
                records.addAll(snapshot2.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) })
            }

            // 3. Robust fallback if direct query returns no records
            if (records.isEmpty()) {
                val allSnap = firestore.collection("attendance").get().await()
                records.addAll(
                    allSnap.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                        .filter {
                            (traineeUid.isNotBlank() && (it.traineeId == traineeUid || it.traineeUniqueId == traineeUid)) ||
                            (targetUniqueId.isNotBlank() && (it.traineeId == targetUniqueId || it.traineeUniqueId == targetUniqueId))
                        }
                )
            }

            records.distinctBy { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }
                .sortedByDescending { it.date }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            android.util.Log.e("AttendanceRepository", "Error getting trainee attendance history: ${e.message}", e)
            try {
                val allSnap = firestore.collection("attendance").get().await()
                allSnap.documents.mapNotNull { it.toObject(AttendanceRecord::class.java) }
                    .filter {
                        it.traineeId == traineeUid || it.traineeUniqueId == traineeUid ||
                        (traineeUniqueId.isNotBlank() && (it.traineeId == traineeUniqueId || it.traineeUniqueId == traineeUniqueId))
                    }
                    .distinctBy { it.attendanceId.ifBlank { "${it.traineeId}_${it.date}" } }
                    .sortedByDescending { it.date }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }

    /**
     * Manual Attendance Correction by authorized Instructor or Admin
     * Maintains complete audit trail in attendance_corrections and audit_logs
     */
    suspend fun manualCorrectAttendance(
        attendanceId: String,
        traineeUid: String,
        traineeUniqueId: String,
        traineeName: String,
        date: String,
        oldStatus: String,
        newStatus: String,
        reason: String,
        reviewerId: String,
        reviewerName: String,
        reviewerRole: String
    ): Boolean {
        return try {
            val now = System.currentTimeMillis()

            // Update or create attendance record
            val docRef = firestore.collection("attendance").document(attendanceId)
            val docSnap = docRef.get().await()
            if (docSnap.exists()) {
                docRef.update(
                    "attendanceStatus", newStatus,
                    "remarks", "Manual correction: $reason (by $reviewerName)",
                    "updatedAt", now
                ).await()
            } else {
                val traineeSnap = firestore.collection("users").document(traineeUid).get().await()
                val trainee = if (traineeSnap.exists()) traineeSnap.toObject(com.example.data.model.TraineeProfile::class.java) else null
                val newRecord = AttendanceRecord(
                    attendanceId = attendanceId,
                    traineeId = traineeUid,
                    traineeUniqueId = traineeUniqueId,
                    traineeName = traineeName,
                    tradeId = trainee?.tradeId ?: "",
                    tradeName = trainee?.tradeName ?: "",
                    instructorId = reviewerId,
                    date = date,
                    attendanceStatus = newStatus,
                    remarks = "Manual marked: $reason (by $reviewerName)",
                    createdAt = now,
                    updatedAt = now,
                    punchInTime = now,
                    punchOutTime = now
                )
                docRef.set(newRecord).await()
            }

            // Create correction record
            val correctionId = "corr_${now}"
            val correction = AttendanceCorrection(
                correctionId = correctionId,
                attendanceId = attendanceId,
                traineeId = traineeUid,
                traineeUniqueId = traineeUniqueId,
                traineeName = traineeName,
                date = date,
                correctedBy = reviewerId,
                correctedByName = reviewerName,
                correctedByRole = reviewerRole,
                oldValue = oldStatus,
                newValue = newStatus,
                reason = reason,
                timestamp = now
            )
            firestore.collection("attendance_corrections").document(correctionId).set(correction).await()

            // Create audit log entry
            recordAuditLog(
                action = "ATTENDANCE_CORRECTED",
                performedBy = reviewerId,
                performedByName = reviewerName,
                performedByRole = reviewerRole,
                targetId = attendanceId,
                targetType = "attendance",
                oldValue = oldStatus,
                newValue = newStatus,
                reason = reason
            )

            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getAttendanceCorrections(): List<AttendanceCorrection> {
        return try {
            val snapshot = firestore.collection("attendance_corrections")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(AttendanceCorrection::class.java) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun clearAttendanceCorrections(): Boolean {
        return try {
            val snapshot = firestore.collection("attendance_corrections").get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.commit().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    // -------------------------------------------------------------
    // STATS & METRICS
    // -------------------------------------------------------------

    suspend fun getDashboardStats(): DashboardStats {
        return try {
            val todayDate = DateUtils.getTodayDateString()
            val trades = getTrades()
            val instructors = getInstructors()
            val trainees = getTrainees()
            val todayAttendance = getDailyAttendance(todayDate)

            val approvedTrainees = trainees.filter { it.status == "approved" }
            val pendingTrainees = trainees.filter { it.status == "pending" }
            val pendingInstructors = instructors.filter { it.status == "pending" }

            val presentCount = todayAttendance.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }
            val lateCount = todayAttendance.count { it.attendanceStatus == "late" }
            val halfDayCount = todayAttendance.count {
                it.attendanceStatus.equals("half_day", ignoreCase = true) ||
                it.attendanceStatus.equals("halfday", ignoreCase = true) ||
                it.attendanceStatus.equals("half day", ignoreCase = true)
            }
            val leaveCount = todayAttendance.count {
                it.attendanceStatus.equals("leave", ignoreCase = true)
            }
            val settings = getInstituteSettings()
            val isPastCutOff = DateUtils.isPastCutOffToday(settings.cutOffTime)
            val unpunchedCount = approvedTrainees.count { tr ->
                todayAttendance.none { att ->
                    (tr.uid.isNotBlank() && att.traineeId == tr.uid) ||
                    (tr.traineeId.isNotBlank() && att.traineeUniqueId == tr.traineeId)
                }
            }
            val explicitAbsentCount = todayAttendance.count { it.attendanceStatus.equals("absent", ignoreCase = true) }

            val notMarkedCount = if (isPastCutOff) 0 else unpunchedCount
            val absentCount = if (isPastCutOff) {
                (approvedTrainees.size - presentCount - halfDayCount - leaveCount).coerceAtLeast(0)
            } else {
                explicitAbsentCount
            }

            val percentage = if (approvedTrainees.isNotEmpty()) {
                (presentCount.toDouble() / approvedTrainees.size.toDouble()) * 100.0
            } else 0.0

            DashboardStats(
                totalTrades = trades.size,
                totalInstructors = instructors.count { it.status == "approved" },
                totalTrainees = approvedTrainees.size,
                presentToday = presentCount,
                absentToday = absentCount,
                lateToday = lateCount,
                halfDayToday = halfDayCount,
                leaveToday = leaveCount,
                notMarkedToday = notMarkedCount,
                pendingTraineeApprovals = pendingTrainees.size,
                pendingInstructorRegistrations = pendingInstructors.size,
                attendancePercentage = percentage
            )
        } catch (_: Exception) {
            DashboardStats()
        }
    }

    suspend fun getTradeStats(tradeId: String): DashboardStats {
        return try {
            val todayDate = DateUtils.getTodayDateString()
            val tradeTrainees = getTraineesByTrade(tradeId)
            val todayAttendance = getTradeAttendance(tradeId, todayDate)

            val approved = tradeTrainees.filter { it.status == "approved" }
            val pending = tradeTrainees.filter { it.status == "pending" }

            val presentCount = todayAttendance.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }
            val lateCount = todayAttendance.count { it.attendanceStatus == "late" }
            val halfDayCount = todayAttendance.count {
                it.attendanceStatus.equals("half_day", ignoreCase = true) ||
                it.attendanceStatus.equals("halfday", ignoreCase = true) ||
                it.attendanceStatus.equals("half day", ignoreCase = true)
            }
            val leaveCount = todayAttendance.count {
                it.attendanceStatus.equals("leave", ignoreCase = true)
            }
            val unpunchedCount = approved.count { tr ->
                todayAttendance.none { att ->
                    (tr.uid.isNotBlank() && att.traineeId == tr.uid) ||
                    (tr.traineeId.isNotBlank() && att.traineeUniqueId == tr.traineeId)
                }
            }
            val explicitAbsentCount = todayAttendance.count { it.attendanceStatus.equals("absent", ignoreCase = true) }
            val settings = getInstituteSettings()
            val isPastCutOff = DateUtils.isPastCutOffToday(settings.cutOffTime)
            val notMarkedCount = if (isPastCutOff) 0 else unpunchedCount
            val absentCount = if (isPastCutOff) {
                (approved.size - presentCount - halfDayCount - leaveCount).coerceAtLeast(0)
            } else {
                explicitAbsentCount
            }

            val percentage = if (approved.isNotEmpty()) {
                (presentCount.toDouble() / approved.size.toDouble()) * 100.0
            } else 0.0

            DashboardStats(
                totalTrades = 1,
                totalInstructors = 1,
                totalTrainees = approved.size,
                presentToday = presentCount,
                absentToday = absentCount,
                lateToday = lateCount,
                halfDayToday = halfDayCount,
                leaveToday = leaveCount,
                notMarkedToday = notMarkedCount,
                pendingTraineeApprovals = pending.size,
                pendingInstructorRegistrations = 0,
                attendancePercentage = percentage
            )
        } catch (_: Exception) {
            DashboardStats()
        }
    }

    // -------------------------------------------------------------
    // NOTIFICATIONS & AUDIT LOGS
    // -------------------------------------------------------------

    suspend fun getAllNotifications(): List<InstituteNotification> {
        return try {
            val snapshot = firestore.collection("notifications")
                .get()
                .await()
            val list = snapshot.documents.mapNotNull { it.toObject(InstituteNotification::class.java) }
            // Filter out instructor-created notifications so admin does not see them
            list.filter { it.senderRole != "instructor" }.sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun deleteNotification(notificationId: String): Boolean {
        return try {
            firestore.collection("notifications").document(notificationId).delete().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteNotifications(notificationIds: List<String>): Boolean {
        if (notificationIds.isEmpty()) return true
        return try {
            val batch = firestore.batch()
            for (id in notificationIds) {
                val docRef = firestore.collection("notifications").document(id)
                batch.delete(docRef)
            }
            batch.commit().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteAllNotifications(): Boolean {
        return try {
            val snapshot = firestore.collection("notifications").get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.commit().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getNotifications(role: String, tradeId: String? = null, userId: String? = null): List<InstituteNotification> {
        return try {
            val snapshot = firestore.collection("notifications")
                .get()
                .await()

            val all = snapshot.documents.mapNotNull { it.toObject(InstituteNotification::class.java) }
            all.filter { notif ->
                // Admin must NOT see instructor notifications
                if (role.equals("admin", ignoreCase = true) && notif.senderRole == "instructor") {
                    return@filter false
                }
                val tr = notif.targetRole.lowercase()
                val r = role.lowercase()
                val roleMatches = tr == "all" ||
                        tr == r ||
                        (tr in listOf("both", "instructor_trainee") && r in listOf("instructor", "trainee")) ||
                        (r == "admin")
                val userMatches = notif.targetUserId == null || notif.targetUserId == userId || notif.targetUserId.isBlank()
                val tradeMatches = notif.targetTradeId == null || notif.targetTradeId == tradeId || notif.targetTradeId.isBlank()
                roleMatches && userMatches && tradeMatches
            }.sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getInstructorSentNotifications(instructorUid: String, tradeId: String): List<InstituteNotification> {
        return try {
            val snapshot = firestore.collection("notifications")
                .get()
                .await()
            val list = snapshot.documents.mapNotNull { it.toObject(InstituteNotification::class.java) }
            list.filter { notif ->
                val isInstructorSender = notif.senderRole.equals("instructor", ignoreCase = true) ||
                        notif.senderName.contains("Instructor", ignoreCase = true) ||
                        (!instructorUid.isNullOrBlank() && notif.senderUserId == instructorUid)
                val tradeMatches = notif.targetTradeId.isNullOrBlank() || notif.targetTradeId == tradeId
                isInstructorSender && tradeMatches
            }.sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun deleteInstructorNotifications(instructorUid: String, tradeId: String): Boolean {
        return try {
            val snapshot = firestore.collection("notifications").get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                val notif = doc.toObject(InstituteNotification::class.java)
                if (notif != null) {
                    val isInstructorSender = notif.senderRole.equals("instructor", ignoreCase = true) ||
                            notif.senderName.contains("Instructor", ignoreCase = true) ||
                            (!instructorUid.isNullOrBlank() && notif.senderUserId == instructorUid)
                    val tradeMatches = notif.targetTradeId.isNullOrBlank() || notif.targetTradeId == tradeId
                    if (isInstructorSender && tradeMatches) {
                        batch.delete(doc.reference)
                    }
                }
            }
            batch.commit().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getTraineeInstructorNotifications(tradeId: String, traineeUid: String): List<InstituteNotification> {
        return try {
            val snapshot = firestore.collection("notifications")
                .get()
                .await()
            val list = snapshot.documents.mapNotNull { it.toObject(InstituteNotification::class.java) }
            list.filter { notif ->
                val isFromInstructor = notif.senderRole == "instructor" || notif.senderName.contains("Instructor", ignoreCase = true)
                val matchesTrade = notif.targetTradeId == null || notif.targetTradeId == tradeId || notif.targetTradeId.isBlank()
                val matchesUser = notif.targetUserId == null || notif.targetUserId == traineeUid || notif.targetUserId.isBlank()
                isFromInstructor && matchesTrade && matchesUser
            }.sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun sendNotification(
        title: String,
        message: String,
        targetRole: String = "all",
        targetTradeId: String? = null,
        targetUserId: String? = null,
        senderName: String = "Institute Administration",
        senderRole: String? = "admin",
        senderUserId: String? = null
    ): Boolean {
        return try {
            val notifId = "notif_${System.currentTimeMillis()}"
            val notification = InstituteNotification(
                notificationId = notifId,
                title = title,
                message = message,
                targetRole = targetRole,
                targetTradeId = targetTradeId,
                targetUserId = targetUserId,
                senderName = senderName,
                senderRole = senderRole,
                senderUserId = senderUserId,
                timestamp = System.currentTimeMillis()
            )
            firestore.collection("notifications").document(notifId).set(notification).await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getAuditLogs(): List<AuditLogEntry> {
        return try {
            val snapshot = firestore.collection("audit_logs")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(100)
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(AuditLogEntry::class.java) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun clearAuditLogs(): Boolean {
        return try {
            val snapshot = firestore.collection("audit_logs").get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.commit().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun recordAuditLog(
        action: String,
        performedBy: String,
        performedByName: String,
        performedByRole: String,
        targetId: String,
        targetType: String,
        oldValue: String? = null,
        newValue: String? = null,
        reason: String? = null
    ) {
        try {
            val logId = "log_${System.currentTimeMillis()}"
            val log = AuditLogEntry(
                logId = logId,
                action = action,
                performedBy = performedBy,
                performedByName = performedByName,
                performedByRole = performedByRole,
                targetId = targetId,
                targetType = targetType,
                oldValue = oldValue,
                newValue = newValue,
                reason = reason,
                timestamp = System.currentTimeMillis()
            )
            firestore.collection("audit_logs").document(logId).set(log).await()
        } catch (_: Exception) {}
    }

    // -------------------------------------------------------------
    // DIARY NOTES MANAGEMENT
    // -------------------------------------------------------------

    suspend fun addDiaryNote(
        traineeId: String,
        traineeName: String,
        tradeId: String,
        tradeName: String,
        instructorId: String,
        instructorName: String,
        title: String,
        content: String
    ): Boolean {
        return try {
            val noteId = "diary_${System.currentTimeMillis()}"
            val note = com.example.data.model.DiaryNote(
                noteId = noteId,
                traineeId = traineeId,
                traineeName = traineeName,
                tradeId = tradeId,
                tradeName = tradeName,
                instructorId = instructorId,
                instructorName = instructorName,
                title = title,
                content = content,
                timestamp = System.currentTimeMillis(),
                dateString = DateUtils.getTodayDateString()
            )
            firestore.collection("diary_notes").document(noteId).set(note).await()

            // Send notification to target trainee
            sendNotification(
                title = "New Diary Note from Instructor",
                message = "Instructor $instructorName added a diary note: '$title'",
                targetRole = "trainee",
                targetUserId = traineeId,
                senderName = instructorName
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun deleteDiaryNote(noteId: String): Boolean {
        return try {
            firestore.collection("diary_notes").document(noteId).delete().await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun updateDiaryNote(
        noteId: String,
        title: String,
        content: String
    ): Boolean {
        return try {
            firestore.collection("diary_notes").document(noteId)
                .update(
                    mapOf(
                        "title" to title,
                        "content" to content,
                        "timestamp" to System.currentTimeMillis(),
                        "dateString" to DateUtils.getTodayDateString()
                    )
                ).await()
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getDiaryNotesForTrade(tradeId: String): List<com.example.data.model.DiaryNote> {
        return try {
            val snapshot = firestore.collection("diary_notes")
                .whereEqualTo("tradeId", tradeId)
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(com.example.data.model.DiaryNote::class.java) }
                .sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getDiaryNotesForTrainee(traineeUid: String): List<com.example.data.model.DiaryNote> {
        return try {
            val snapshot = firestore.collection("diary_notes")
                .whereEqualTo("traineeId", traineeUid)
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(com.example.data.model.DiaryNote::class.java) }
                .sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun observeDiaryNotes(
        onUpdate: (List<com.example.data.model.DiaryNote>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("diary_notes")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { it.toObject(com.example.data.model.DiaryNote::class.java) }
                    .sortedByDescending { it.timestamp }
                onUpdate(list)
            }
    }

    suspend fun getAllDiaryNotes(): List<com.example.data.model.DiaryNote> {
        return try {
            val snapshot = firestore.collection("diary_notes")
                .get()
                .await()
            snapshot.documents.mapNotNull { it.toObject(com.example.data.model.DiaryNote::class.java) }
                .sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // -------------------------------------------------------------
    // ADMIN MANAGEMENT
    // -------------------------------------------------------------

    suspend fun getAdmins(): List<AdminProfile> {
        return try {
            val snapshot = firestore.collection("admins").get().await()
            if (snapshot.isEmpty) {
                emptyList()
            } else {
                snapshot.documents.mapNotNull { it.toObject(AdminProfile::class.java) }
                    .sortedByDescending { it.createdAt }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun createNewAdmin(
        context: android.content.Context,
        name: String,
        email: String,
        password: String,
        creatorAdminName: String
    ): Result<AdminProfile> {
        return try {
            val cleanEmail = email.trim().lowercase()
            val cleanName = name.trim()
            val cleanPassword = password.trim()

            if (cleanName.isBlank()) return Result.failure(Exception("Admin name cannot be empty."))
            if (cleanEmail.isBlank()) return Result.failure(Exception("Admin email cannot be empty."))
            if (cleanPassword.length < 6) return Result.failure(Exception("Password must be at least 6 characters."))

            // Check if email already registered in users collection
            val existingQuery = firestore.collection("users")
                .whereEqualTo("email", cleanEmail)
                .get()
                .await()

            if (!existingQuery.isEmpty) {
                return Result.failure(Exception("User account with email '$cleanEmail' already exists."))
            }

            // Create user in Firebase Auth using Secondary App instance so current admin session is not lost
            val secondaryApp = try {
                com.google.firebase.FirebaseApp.getInstance("SecondaryAdminApp")
            } catch (_: Exception) {
                com.google.firebase.FirebaseApp.initializeApp(
                    context,
                    com.google.firebase.FirebaseApp.getInstance().options,
                    "SecondaryAdminApp"
                )
            }

            val secondaryAuth = com.google.firebase.auth.FirebaseAuth.getInstance(secondaryApp)
            val uid = try {
                val authResult = secondaryAuth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                val u = authResult.user?.uid ?: ("admin_" + System.currentTimeMillis())
                secondaryAuth.signOut()
                u
            } catch (e: Exception) {
                val msg = e.message.orEmpty()
                if (msg.contains("email-already-in-use", ignoreCase = true) || msg.contains("already in use", ignoreCase = true) || msg.contains("in use", ignoreCase = true)) {
                    try {
                        val signInRes = secondaryAuth.signInWithEmailAndPassword(cleanEmail, cleanPassword).await()
                        val u = signInRes.user?.uid ?: ("admin_" + System.currentTimeMillis())
                        secondaryAuth.signOut()
                        u
                    } catch (_: Exception) {
                        secondaryAuth.signOut()
                        return Result.failure(Exception("An account with '$cleanEmail' is registered in Firebase Auth. Please delete it from the Firebase Console or sign in with its existing password."))
                    }
                } else {
                    secondaryAuth.signOut()
                    throw e
                }
            }

            val newAdmin = AdminProfile(
                uid = uid,
                name = cleanName,
                email = cleanEmail,
                role = "admin",
                status = "approved",
                createdAt = System.currentTimeMillis()
            )

            val userProfile = com.example.data.model.UserProfile(
                uid = uid,
                name = cleanName,
                email = cleanEmail,
                role = "admin",
                status = "approved",
                createdAt = System.currentTimeMillis()
            )

            // Write to users and admins collections
            firestore.collection("users").document(uid).set(userProfile).await()
            firestore.collection("admins").document(uid).set(newAdmin).await()

            // Log audit entry
            recordAuditLog(
                action = "CREATE_ADMIN",
                performedBy = "admin",
                performedByName = creatorAdminName,
                performedByRole = "admin",
                targetId = uid,
                targetType = "admin",
                newValue = "$cleanName ($cleanEmail)",
                reason = "New administrator created"
            )

            Result.success(newAdmin)
        } catch (e: Exception) {
            // Fallback for offline or direct document creation
            try {
                val cleanEmail = email.trim().lowercase()
                val cleanName = name.trim()
                val fallbackUid = "admin_" + System.currentTimeMillis()

                val newAdmin = AdminProfile(
                    uid = fallbackUid,
                    name = cleanName,
                    email = cleanEmail,
                    role = "admin",
                    status = "approved",
                    createdAt = System.currentTimeMillis()
                )

                val userProfile = com.example.data.model.UserProfile(
                    uid = fallbackUid,
                    name = cleanName,
                    email = cleanEmail,
                    role = "admin",
                    status = "approved",
                    createdAt = System.currentTimeMillis()
                )

                firestore.collection("users").document(fallbackUid).set(userProfile).await()
                firestore.collection("admins").document(fallbackUid).set(newAdmin).await()

                recordAuditLog(
                    action = "CREATE_ADMIN",
                    performedBy = "admin",
                    performedByName = creatorAdminName,
                    performedByRole = "admin",
                    targetId = fallbackUid,
                    targetType = "admin",
                    newValue = "$cleanName ($cleanEmail)",
                    reason = "New administrator created (offline mode)"
                )

                Result.success(newAdmin)
            } catch (_: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun createNewDealer(
        context: android.content.Context,
        dealerCode: String = "",
        name: String,
        companyName: String = "",
        email: String,
        password: String,
        contact: String,
        tradeId: String,
        tradeName: String,
        aadhaarNo: String = "",
        panNo: String = "",
        businessAddress: String = "",
        residentialAddress: String = "",
        alternateNo: String = "",
        geoTagAddress: String = "",
        geoLatitude: Double? = null,
        geoLongitude: Double? = null,
        creatorAdminName: String = "Admin"
    ): Result<InstructorProfile> {
        return try {
            val cleanEmail = email.trim().lowercase()
            val cleanName = name.trim()
            val cleanPassword = password.trim()
            val cleanContact = contact.trim()

            if (cleanName.isBlank()) return Result.failure(Exception("Dealer name cannot be empty."))
            if (cleanEmail.isBlank()) return Result.failure(Exception("Dealer email cannot be empty."))
            if (cleanPassword.length < 6) return Result.failure(Exception("Password must be at least 6 characters."))

            // Check if user already exists
            val existingQuery = firestore.collection("users")
                .whereEqualTo("email", cleanEmail)
                .get()
                .await()

            if (!existingQuery.isEmpty) {
                return Result.failure(Exception("User account with email '$cleanEmail' already exists."))
            }

            // Create Firebase Auth user using Secondary App so admin session stays active
            val secondaryApp = try {
                com.google.firebase.FirebaseApp.getInstance("SecondaryAdminApp")
            } catch (_: Exception) {
                com.google.firebase.FirebaseApp.initializeApp(
                    context,
                    com.google.firebase.FirebaseApp.getInstance().options,
                    "SecondaryAdminApp"
                )
            }

            val secondaryAuth = com.google.firebase.auth.FirebaseAuth.getInstance(secondaryApp)
            val uid = try {
                val authResult = secondaryAuth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                val u = authResult.user?.uid ?: ("dealer_" + System.currentTimeMillis())
                secondaryAuth.signOut()
                u
            } catch (e: Exception) {
                val msg = e.message.orEmpty()
                if (msg.contains("email-already-in-use", ignoreCase = true) || msg.contains("already in use", ignoreCase = true) || msg.contains("in use", ignoreCase = true)) {
                    try {
                        val signInRes = secondaryAuth.signInWithEmailAndPassword(cleanEmail, cleanPassword).await()
                        val u = signInRes.user?.uid ?: ("dealer_" + System.currentTimeMillis())
                        secondaryAuth.signOut()
                        u
                    } catch (_: Exception) {
                        secondaryAuth.signOut()
                        return Result.failure(Exception("An account with '$cleanEmail' already exists in Firebase Auth."))
                    }
                } else {
                    secondaryAuth.signOut()
                    "dealer_" + System.currentTimeMillis()
                }
            }

            val newDealer = InstructorProfile(
                uid = uid,
                dealerCode = dealerCode.trim(),
                name = cleanName,
                companyName = companyName.trim(),
                email = cleanEmail,
                contact = cleanContact,
                aadhaarNo = aadhaarNo.trim(),
                panNo = panNo.trim().uppercase(),
                businessAddress = businessAddress.trim(),
                residentialAddress = residentialAddress.trim(),
                alternateNo = alternateNo.trim(),
                geoTagAddress = geoTagAddress.trim(),
                geoLatitude = geoLatitude,
                geoLongitude = geoLongitude,
                tradeId = tradeId.trim(),
                tradeName = tradeName.trim(),
                role = "Dealer",
                status = "approved",
                createdAt = System.currentTimeMillis()
            )

            val userProfile = com.example.data.model.UserProfile(
                uid = uid,
                name = cleanName,
                email = cleanEmail,
                role = "Dealer",
                status = "approved",
                createdAt = System.currentTimeMillis()
            )

            firestore.collection("users").document(uid).set(userProfile).await()
            firestore.collection("dealers").document(uid).set(newDealer).await()

            recordAuditLog(
                action = "CREATE_DEALER",
                performedBy = "admin",
                performedByName = creatorAdminName,
                performedByRole = "admin",
                targetId = uid,
                targetType = "instructor",
                newValue = "$cleanName ($cleanEmail) - $tradeName",
                reason = "New dealer added and approved by admin"
            )

            Result.success(newDealer)
        } catch (e: Exception) {
            try {
                val cleanEmail = email.trim().lowercase()
                val cleanName = name.trim()
                val fallbackUid = "dealer_" + System.currentTimeMillis()

                val newDealer = InstructorProfile(
                    uid = fallbackUid,
                    name = cleanName,
                    email = cleanEmail,
                    contact = contact.trim(),
                    aadhaarNo = aadhaarNo.trim(),
                    panNo = panNo.trim().uppercase(),
                    businessAddress = businessAddress.trim(),
                    residentialAddress = residentialAddress.trim(),
                    alternateNo = alternateNo.trim(),
                    geoTagAddress = geoTagAddress.trim(),
                    geoLatitude = geoLatitude,
                    geoLongitude = geoLongitude,
                    tradeId = tradeId.trim(),
                    tradeName = tradeName.trim(),
                    role = "Dealer",
                    status = "approved",
                    createdAt = System.currentTimeMillis()
                )

                val userProfile = com.example.data.model.UserProfile(
                    uid = fallbackUid,
                    name = cleanName,
                    email = cleanEmail,
                    role = "Dealer",
                    status = "approved",
                    createdAt = System.currentTimeMillis()
                )

                firestore.collection("users").document(fallbackUid).set(userProfile).await()
                firestore.collection("dealers").document(fallbackUid).set(newDealer).await()

                recordAuditLog(
                    action = "CREATE_DEALER",
                    performedBy = "admin",
                    performedByName = creatorAdminName,
                    performedByRole = "admin",
                    targetId = fallbackUid,
                    targetType = "instructor",
                    newValue = "$cleanName ($cleanEmail) - $tradeName",
                    reason = "New dealer added and approved by admin (offline mode)"
                )

                Result.success(newDealer)
            } catch (_: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun deleteAdmin(
        targetAdminUid: String,
        targetAdminName: String,
        adminId: String,
        adminName: String
    ): Boolean {
        return try {
            firestore.collection("admins").document(targetAdminUid).delete().await()
            firestore.collection("users").document(targetAdminUid).delete().await()

            recordAuditLog(
                action = "ADMIN_DELETED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = targetAdminUid,
                targetType = "admin",
                oldValue = targetAdminName,
                reason = "Admin account deleted"
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    // ==========================================
    // ORDERS MANAGEMENT (DEALERS & STAFF)
    // ==========================================

    fun getInitialSampleOrders(): List<com.example.data.model.OrderRecord> {
        val now = System.currentTimeMillis()
        return listOf(
            com.example.data.model.OrderRecord(
                orderId = "ORD-2026-101",
                placedByRole = "dealer",
                placedById = "dealer_01",
                placedByName = "Rajesh Kumar (Bombay Footwear Agency)",
                placedByContact = "+91 98765 43210",
                profileName = "Leather Footwear",
                items = listOf(
                    com.example.data.model.OrderItem("item_1", "Men's Classic Oxford Leather", 24, 1850.0, "Size 8 & 9 (UK)"),
                    com.example.data.model.OrderItem("item_2", "Formal Slip-on Loafer", 16, 1600.0, "Size 7 & 8 (UK)")
                ),
                totalAmount = 70000.0,
                totalQuantity = 40,
                orderStatus = "Approved",
                paymentStatus = "Paid",
                deliveryAddress = "Shop No. 12, Commercial Complex, Sector 4",
                notes = "Urgent festival stock delivery requested",
                orderDate = "08 Oct 2026",
                timestamp = now - 3600000L
            ),
            com.example.data.model.OrderRecord(
                orderId = "ORD-2026-102",
                placedByRole = "staff",
                placedById = "staff_01",
                placedByName = "Amir Sohail (Staff - Workshop)",
                placedByContact = "+91 94190 12345",
                profileName = "Safety & Industrial",
                items = listOf(
                    com.example.data.model.OrderItem("item_3", "Heavy Duty Steel-Toe Safety Boots", 12, 1450.0, "Size 9 (UK)"),
                    com.example.data.model.OrderItem("item_4", "Anti-Skid Workshop Rubber Soles", 20, 350.0, "Standard")
                ),
                totalAmount = 24400.0,
                totalQuantity = 32,
                orderStatus = "Processing",
                paymentStatus = "Credit / COD",
                deliveryAddress = "Production Department Unit 2, Main Campus",
                notes = "For workshop machinery technicians & staff",
                orderDate = "08 Oct 2026",
                timestamp = now - 7200000L
            ),
            com.example.data.model.OrderRecord(
                orderId = "ORD-2026-103",
                placedByRole = "dealer",
                placedById = "dealer_02",
                placedByName = "Suresh Verma (Metro Shoe Mart)",
                placedByContact = "+91 98111 22334",
                profileName = "Sports & Casual",
                items = listOf(
                    com.example.data.model.OrderItem("item_5", "Lightweight Mesh Running Sneakers", 30, 1200.0, "Assorted Sizes 7-10"),
                    com.example.data.model.OrderItem("item_6", "Casual Canvas Lace-up Sneakers", 20, 850.0, "Size 8 (UK)")
                ),
                totalAmount = 53000.0,
                totalQuantity = 50,
                orderStatus = "Pending",
                paymentStatus = "Pending",
                deliveryAddress = "Plot 45, GT Road, Near Bus Stand",
                notes = "Check stock availability before dispatch",
                orderDate = "07 Oct 2026",
                timestamp = now - 86400000L
            ),
            com.example.data.model.OrderRecord(
                orderId = "ORD-2026-104",
                placedByRole = "staff",
                placedById = "staff_02",
                placedByName = "Pooja Sharma (Staff - Quality Control)",
                placedByContact = "+91 97960 55443",
                profileName = "Testing & Quality",
                items = listOf(
                    com.example.data.model.OrderItem("item_7", "Sample Batch Leather Chelsea Boots", 5, 2100.0, "Sample Size 8"),
                    com.example.data.model.OrderItem("item_8", "Sole Flex Testing Leather Strips", 10, 400.0, "Standard")
                ),
                totalAmount = 14500.0,
                totalQuantity = 15,
                orderStatus = "Delivered",
                paymentStatus = "Paid",
                deliveryAddress = "QC Testing Lab, Admin Wing",
                notes = "Completed inspection batch sample",
                orderDate = "06 Oct 2026",
                timestamp = now - 172800000L
            )
        )
    }

    fun getOrdersListener(onOrdersChanged: (List<com.example.data.model.OrderRecord>) -> Unit): ListenerRegistration {
        return firestore.collection("orders")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) {
                    onOrdersChanged(getInitialSampleOrders())
                    return@addSnapshotListener
                }
                val list = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(com.example.data.model.OrderRecord::class.java)
                }
                if (list.isEmpty()) {
                    onOrdersChanged(emptyList())
                } else {
                    onOrdersChanged(list.sortedByDescending { it.timestamp })
                }
            }
    }

    suspend fun createNewOrder(order: com.example.data.model.OrderRecord): Result<com.example.data.model.OrderRecord> {
        return try {
            val id = if (order.orderId.isNotBlank()) order.orderId else "ORD-" + System.currentTimeMillis()
            val finalOrder = order.copy(orderId = id, timestamp = System.currentTimeMillis())
            firestore.collection("orders").document(id).set(finalOrder).await()
            Result.success(finalOrder)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String, adminName: String): Result<Unit> {
        return try {
            firestore.collection("orders").document(orderId)
                .update("orderStatus", newStatus)
                .await()
            recordAuditLog(
                action = "ORDER_STATUS_UPDATE",
                performedBy = "admin",
                performedByName = adminName,
                performedByRole = "admin",
                targetId = orderId,
                targetType = "order",
                newValue = newStatus,
                reason = "Order status updated to $newStatus"
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAllOrders(): List<com.example.data.model.OrderRecord> {
        return try {
            val snapshot = firestore.collection("orders").get().await()
            val list = snapshot.documents.mapNotNull { it.toObject(com.example.data.model.OrderRecord::class.java) }
            if (list.isEmpty()) getInitialSampleOrders() else list.sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            getInitialSampleOrders()
        }
    }

    suspend fun deleteAllOrders(): Result<Unit> {
        return try {
            val snapshot = firestore.collection("orders").get().await()
            val batch = firestore.batch()
            for (document in snapshot.documents) {
                batch.delete(document.reference)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteOrdersByRole(role: String, adminName: String): Result<Unit> {
        return try {
            val snapshot = firestore.collection("orders").whereEqualTo("placedByRole", role).get().await()
            val batch = firestore.batch()
            for (document in snapshot.documents) {
                batch.delete(document.reference)
            }
            batch.commit().await()
            recordAuditLog(
                action = "ORDERS_DELETED_BY_ROLE",
                performedBy = "admin",
                performedByName = adminName,
                performedByRole = "admin",
                targetId = role,
                targetType = "order",
                reason = "All $role orders deleted by admin"
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteOrder(orderId: String, adminName: String): Result<Unit> {
        return try {
            firestore.collection("orders").document(orderId).delete().await()
            recordAuditLog(
                action = "ORDER_DELETED",
                performedBy = "admin",
                performedByName = adminName,
                performedByRole = "admin",
                targetId = orderId,
                targetType = "order",
                oldValue = orderId,
                reason = "Order removed by admin"
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createNewTrainee(
        context: android.content.Context,
        staffCode: String = "",
        name: String,
        parentage: String,
        guardianContact: String,
        email: String,
        password: String,
        contact: String,
        address: String,
        tradeId: String,
        tradeName: String,
        creatorAdminName: String = "Admin"
    ): Result<TraineeProfile> {
        return try {
            val cleanEmail = email.trim().lowercase()
            val cleanName = name.trim()
            val cleanPassword = password.trim()

            if (cleanName.isBlank()) return Result.failure(Exception("Staff name cannot be empty."))
            if (cleanEmail.isBlank()) return Result.failure(Exception("Staff email cannot be empty."))
            if (cleanPassword.length < 6) return Result.failure(Exception("Password must be at least 6 characters."))

            val existingQuery = firestore.collection("users")
                .whereEqualTo("email", cleanEmail)
                .get()
                .await()

            if (!existingQuery.isEmpty) {
                return Result.failure(Exception("User account with email '$cleanEmail' already exists."))
            }

            val secondaryApp = try {
                com.google.firebase.FirebaseApp.getInstance("SecondaryAdminApp")
            } catch (_: Exception) {
                com.google.firebase.FirebaseApp.initializeApp(
                    context,
                    com.google.firebase.FirebaseApp.getInstance().options,
                    "SecondaryAdminApp"
                )
            }

            val secondaryAuth = com.google.firebase.auth.FirebaseAuth.getInstance(secondaryApp)
            val uid = try {
                val authResult = secondaryAuth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                val u = authResult.user?.uid ?: ("trainee_" + System.currentTimeMillis())
                secondaryAuth.signOut()
                u
            } catch (e: Exception) {
                val msg = e.message.orEmpty()
                if (msg.contains("email-already-in-use", ignoreCase = true) || msg.contains("already in use", ignoreCase = true) || msg.contains("in use", ignoreCase = true)) {
                    try {
                        val signInRes = secondaryAuth.signInWithEmailAndPassword(cleanEmail, cleanPassword).await()
                        val u = signInRes.user?.uid ?: ("trainee_" + System.currentTimeMillis())
                        secondaryAuth.signOut()
                        u
                    } catch (_: Exception) {
                        secondaryAuth.signOut()
                        return Result.failure(Exception("An account with '$cleanEmail' already exists in Firebase Auth."))
                    }
                } else {
                    secondaryAuth.signOut()
                    "trainee_" + System.currentTimeMillis()
                }
            }

            val uniqueTraineeId = staffCode.trim().ifBlank { generateUniqueTraineeId() }
            val defaultPin = String.format("%04d", (1000..9999).random())

            val newTrainee = TraineeProfile(
                uid = uid,
                traineeId = uniqueTraineeId,
                name = cleanName,
                parentage = parentage.trim(),
                guardianContact = guardianContact.trim(),
                email = cleanEmail,
                contact = contact.trim(),
                address = address.trim(),
                tradeId = tradeId.trim(),
                tradeName = tradeName.trim(),
                role = "Staff",
                status = "approved",
                parentAccessPin = defaultPin,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val userProfile = com.example.data.model.UserProfile(
                uid = uid,
                name = cleanName,
                email = cleanEmail,
                role = "Staff",
                status = "approved",
                createdAt = System.currentTimeMillis()
            )

            firestore.collection("users").document(uid).set(userProfile).await()
            firestore.collection("staff").document(uid).set(newTrainee).await()

            recordAuditLog(
                action = "CREATE_STAFF",
                performedBy = "admin",
                performedByName = creatorAdminName,
                performedByRole = "admin",
                targetId = uid,
                targetType = "trainee",
                newValue = "$cleanName ($cleanEmail) - ID: $uniqueTraineeId",
                reason = "New staff added and approved by admin"
            )

            Result.success(newTrainee)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // -------------------------------------------------------------
    // TASK MANAGEMENT
    // -------------------------------------------------------------

    fun observeAllTasks(
        onUpdate: (List<TaskRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("tasks")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { doc ->
                    val task = doc.toObject(TaskRecord::class.java)
                    task?.copy(id = doc.id.ifBlank { task.id })
                }.sortedByDescending { it.createdAt }
                onUpdate(list)
            }
    }

    fun observeTasksForStaff(
        staffId: String,
        onUpdate: (List<TaskRecord>) -> Unit
    ): com.google.firebase.firestore.ListenerRegistration {
        return firestore.collection("tasks")
            .whereEqualTo("staffId", staffId)
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { doc ->
                    val task = doc.toObject(TaskRecord::class.java)
                    task?.copy(id = doc.id.ifBlank { task.id })
                }.sortedByDescending { it.createdAt }
                onUpdate(list)
            }
    }

    suspend fun getAllTasks(): List<TaskRecord> {
        return try {
            val snapshot = firestore.collection("tasks").get().await()
            snapshot.documents.mapNotNull { doc ->
                val task = doc.toObject(TaskRecord::class.java)
                task?.copy(id = doc.id.ifBlank { task.id })
            }.sortedByDescending { it.createdAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun getTasksForStaff(staffId: String): List<TaskRecord> {
        return try {
            val snapshot = firestore.collection("tasks")
                .whereEqualTo("staffId", staffId)
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                val task = doc.toObject(TaskRecord::class.java)
                task?.copy(id = doc.id.ifBlank { task.id })
            }.sortedByDescending { it.createdAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun createTask(
        task: TaskRecord,
        adminUid: String,
        adminName: String
    ): Result<TaskRecord> {
        return try {
            if (task.staffId.isBlank()) {
                return Result.failure(IllegalArgumentException("Please select a staff member."))
            }
            if (task.description.isBlank()) {
                return Result.failure(IllegalArgumentException("Task description cannot be empty."))
            }

            val taskId = if (task.id.isNotBlank()) task.id else "TSK-${DateUtils.getTodayDateString().replace("-", "").takeLast(6)}-${(1000..9999).random()}"
            val finalTask = task.copy(
                id = taskId,
                createdAt = if (task.createdAt > 0) task.createdAt else System.currentTimeMillis(),
                createdDate = if (task.createdDate.isNotBlank()) task.createdDate else DateUtils.getTodayDateString(),
                status = "Pending",
                createdBy = adminName.ifBlank { "Admin" },
                createdById = adminUid
            )

            firestore.collection("tasks")
                .document(taskId)
                .set(finalTask)
                .await()

            recordAuditLog(
                action = "TASK_CREATED",
                performedBy = adminUid,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = taskId,
                targetType = "task",
                newValue = "Task $taskId assigned to ${finalTask.staffName}: ${finalTask.description.take(50)}"
            )

            Result.success(finalTask)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTask(
        taskId: String,
        adminUid: String,
        adminName: String
    ): Result<Boolean> {
        return try {
            firestore.collection("tasks").document(taskId).delete().await()

            recordAuditLog(
                action = "TASK_DELETED",
                performedBy = adminUid,
                performedByName = adminName,
                performedByRole = "admin",
                targetId = taskId,
                targetType = "task",
                oldValue = "Task $taskId deleted"
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun markTaskCompleted(
        taskId: String,
        authenticatedStaffUid: String,
        staffName: String,
        remarks: String = ""
    ): Result<Boolean> {
        return try {
            val docRef = firestore.collection("tasks").document(taskId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                return Result.failure(IllegalStateException("Task not found."))
            }

            val task = snap.toObject(TaskRecord::class.java)
                ?: return Result.failure(IllegalStateException("Unable to parse task."))

            // Validate staff identity and authorization
            if (task.staffId != authenticatedStaffUid) {
                return Result.failure(SecurityException("Unauthorized: You can only complete tasks assigned to you."))
            }

            val completionTimestamp = System.currentTimeMillis()
            val completionDateStr = DateUtils.formatDateTime(completionTimestamp)
            val trimmedRemarks = remarks.trim()

            val updates = mutableMapOf<String, Any>(
                "status" to "Completed",
                "completedAt" to completionTimestamp,
                "completedDate" to completionDateStr,
                "remarks" to trimmedRemarks
            )

            docRef.update(updates).await()

            recordAuditLog(
                action = "TASK_COMPLETED",
                performedBy = authenticatedStaffUid,
                performedByName = staffName,
                performedByRole = "Staff",
                targetId = taskId,
                targetType = "task",
                oldValue = "Status: Pending",
                newValue = "Status: Completed on $completionDateStr${if (trimmedRemarks.isNotBlank()) " | Remarks: $trimmedRemarks" else ""}"
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateTaskStatus(
        taskId: String,
        newStatus: String,
        adminId: String,
        adminName: String
    ): Result<Boolean> {
        return try {
            val docRef = firestore.collection("tasks").document(taskId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                return Result.failure(IllegalStateException("Task not found."))
            }
            val task = snap.toObject(TaskRecord::class.java)
                ?: return Result.failure(IllegalStateException("Unable to parse task."))

            val updates = mutableMapOf<String, Any>(
                "status" to newStatus
            )
            if (newStatus.equals("Completed", ignoreCase = true) || newStatus.equals("Finished", ignoreCase = true)) {
                if (task.completedAt == 0L) {
                    val compTime = System.currentTimeMillis()
                    val compDate = DateUtils.formatDateTime(compTime)
                    updates["completedAt"] = compTime
                    updates["completedDate"] = compDate
                }
            } else if (newStatus.equals("Pending", ignoreCase = true)) {
                updates["completedAt"] = 0L
                updates["completedDate"] = ""
                updates["remarks"] = ""
            }

            docRef.update(updates).await()

            recordAuditLog(
                action = "TASK_STATUS_UPDATED",
                performedBy = adminId,
                performedByName = adminName,
                performedByRole = "Admin",
                targetId = taskId,
                targetType = "task",
                oldValue = "Status: ${task.status}",
                newValue = "Status: $newStatus"
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

