package com.example.data.repository

import com.example.data.model.AccountStatus
import com.example.data.model.AdminProfile
import com.example.data.model.InstructorProfile
import com.example.data.model.TraineeProfile
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

sealed class AuthResult<out T> {
    data class Success<T>(val data: T) : AuthResult<T>()
    data class Error(val message: String) : AuthResult<Nothing>()
    object Loading : AuthResult<Nothing>()
}

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    // Current active session profile state
    var currentRole: UserRole? = null
        private set
    var currentAdmin: AdminProfile? = null
        private set
    var currentInstructor: InstructorProfile? = null
        private set
    var currentTrainee: TraineeProfile? = null
        private set
    var currentParentTrainee: TraineeProfile? = null
        private set

    fun isUserLoggedIn(): Boolean {
        return auth.currentUser != null || currentParentTrainee != null
    }

    fun getCurrentUserId(): String? {
        return auth.currentUser?.uid ?: currentParentTrainee?.uid
    }

    fun saveSessionInfo(
        context: android.content.Context,
        role: UserRole,
        uid: String? = null,
        parentTraineeId: String? = null,
        parentPin: String? = null
    ) {
        try {
            val prefs = context.getSharedPreferences("iti_user_session", android.content.Context.MODE_PRIVATE)
            prefs.edit()
                .putBoolean("is_logged_in", true)
                .putString("user_role", role.roleName)
                .putString("user_uid", uid ?: "")
                .putString("parent_trainee_id", parentTraineeId ?: "")
                .putString("parent_pin", parentPin ?: "")
                .apply()
        } catch (_: Exception) {}
    }

    fun clearSessionInfo(context: android.content.Context? = null) {
        if (context != null) {
            try {
                val prefs = context.getSharedPreferences("iti_user_session", android.content.Context.MODE_PRIVATE)
                prefs.edit().clear().apply()
            } catch (_: Exception) {}
        }
        auth.signOut()
        currentRole = null
        currentAdmin = null
        currentInstructor = null
        currentTrainee = null
        currentParentTrainee = null
    }

    suspend fun checkAndRestoreSession(context: android.content.Context): Boolean {
        return try {
            val prefs = context.getSharedPreferences("iti_user_session", android.content.Context.MODE_PRIVATE)
            val isLoggedIn = prefs.getBoolean("is_logged_in", false)
            val savedRoleName = prefs.getString("user_role", null)
            val savedParentTraineeId = prefs.getString("parent_trainee_id", null)
            val savedParentPin = prefs.getString("parent_pin", null)

            // 1. Check Parent session
            if (savedRoleName == UserRole.PARENT.roleName || (!savedParentTraineeId.isNullOrBlank() && !savedParentPin.isNullOrBlank())) {
                if (!savedParentTraineeId.isNullOrBlank() && !savedParentPin.isNullOrBlank()) {
                    val res = parentLogin(savedParentTraineeId, savedParentPin, context)
                    if (res is AuthResult.Success) {
                        return true
                    }
                }
            }

            // 2. Check Firebase Auth current user
            val firebaseUser = auth.currentUser
            if (firebaseUser != null) {
                val uid = firebaseUser.uid
                val userDoc = firestore.collection("users").document(uid).get().await()
                if (userDoc.exists()) {
                    val profile = userDoc.toObject(UserProfile::class.java)
                    if (profile != null) {
                        if (profile.role.equals("trainee", ignoreCase = true) || profile.role.equals("staff", ignoreCase = true)) {
                            val traineeDoc = firestore.collection("staff").document(uid).get().await()
                            val traineeStatus = traineeDoc.getString("status") ?: profile.status
                            if (traineeStatus.equals("inactive", ignoreCase = true) || traineeStatus.equals("deactivated", ignoreCase = true)) {
                                auth.signOut()
                                clearSessionInfo(context)
                                return false
                            }
                        }
                        loadRoleSpecificProfile(profile)
                        saveSessionInfo(context, currentRole ?: UserRole.fromString(profile.role), uid = uid)
                        return true
                    }
                } else {
                    val adminDoc = firestore.collection("admins").document(uid).get().await()
                    if (adminDoc.exists()) {
                        val adminProfile = adminDoc.toObject(AdminProfile::class.java)
                        if (adminProfile != null) {
                            currentRole = UserRole.ADMIN
                            currentAdmin = adminProfile
                            saveSessionInfo(context, UserRole.ADMIN, uid = uid)
                            return true
                        }
                    }
                }
            }

            // 3. Check saved UID fallback
            val savedUid = prefs.getString("user_uid", null)
            if (isLoggedIn && !savedUid.isNullOrBlank()) {
                val userDoc = firestore.collection("users").document(savedUid).get().await()
                if (userDoc.exists()) {
                    val profile = userDoc.toObject(UserProfile::class.java)
                    if (profile != null) {
                        if (profile.role.equals("trainee", ignoreCase = true) || profile.role.equals("staff", ignoreCase = true)) {
                            val traineeDoc = firestore.collection("staff").document(savedUid).get().await()
                            val traineeStatus = traineeDoc.getString("status") ?: profile.status
                            if (traineeStatus.equals("inactive", ignoreCase = true) || traineeStatus.equals("deactivated", ignoreCase = true)) {
                                auth.signOut()
                                clearSessionInfo(context)
                                return false
                            }
                        }
                        loadRoleSpecificProfile(profile)
                        return true
                    }
                }
            }

            false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Authenticate Admin, Instructor, or Trainee using Firebase Auth Email & Password
     */
    suspend fun login(email: String, password: String, context: android.content.Context? = null): AuthResult<UserProfile> {
        val cleanEmail = email.trim()
        val cleanPassword = password.trim()
        return try {
            val authResult = auth.signInWithEmailAndPassword(cleanEmail, cleanPassword).await()
            val uid = authResult.user?.uid ?: throw Exception("Authentication returned empty UID")

            // Check users collection first for role and status
            val userDoc = firestore.collection("users").document(uid).get().await()

            if (userDoc.exists()) {
                val profile = userDoc.toObject(UserProfile::class.java) ?: UserProfile(
                    uid = uid,
                    email = cleanEmail,
                    name = cleanEmail.substringBefore("@"),
                    role = "Staff",
                    status = "pending"
                )

                // If trainee account is deactivated or inactive, block login immediately
                if (profile.role.equals("trainee", ignoreCase = true) || profile.role.equals("staff", ignoreCase = true)) {
                    val traineeDoc = firestore.collection("staff").document(uid).get().await()
                    val traineeStatus = traineeDoc.getString("status") ?: profile.status
                    if (traineeStatus.equals("inactive", ignoreCase = true) || traineeStatus.equals("deactivated", ignoreCase = true)) {
                        auth.signOut()
                        clearSessionInfo(context)
                        return AuthResult.Error("Your trainee account has been deactivated by your instructor. You cannot log in with this profile.")
                    }
                }

                loadRoleSpecificProfile(profile)
                if (context != null && currentRole != null) {
                    saveSessionInfo(context, currentRole!!, uid = uid)
                }
                AuthResult.Success(profile)
            } else {
                // Check if this is the initial Admin UID or fallback admin email
                val adminDoc = firestore.collection("admins").document(uid).get().await()
                if (adminDoc.exists() || cleanEmail.equals("admin@gmail.com", ignoreCase = true) || cleanEmail.equals("admin@iti.edu", ignoreCase = true)) {
                    val existingName = adminDoc.getString("name")
                    val resolvedName = if (!existingName.isNullOrBlank() && existingName != "Institute Admin") {
                        existingName
                    } else {
                        cleanEmail.substringBefore("@").replace(".", " ").split(" ")
                            .joinToString(" ") { word -> word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() } }
                            .ifBlank { "Admin" }
                    }
                    val adminProfile = AdminProfile(
                        uid = uid,
                        name = resolvedName,
                        email = cleanEmail,
                        role = "admin",
                        status = "approved"
                    )
                    // Create in users & admins
                    val userProfile = UserProfile(
                        uid = uid,
                        name = adminProfile.name,
                        email = cleanEmail,
                        role = "admin",
                        status = "approved"
                    )
                    try {
                        firestore.collection("users").document(uid).set(userProfile).await()
                        firestore.collection("admins").document(uid).set(adminProfile).await()
                    } catch (_: Exception) {}
                    
                    currentRole = UserRole.ADMIN
                    currentAdmin = adminProfile
                    if (context != null) {
                        saveSessionInfo(context, UserRole.ADMIN, uid = uid)
                    }
                    AuthResult.Success(userProfile)
                } else {
                    // Check if instructor / trainee profile exists by email query (in case of UID migration or reset)
                    val instQuery = firestore.collection("dealers").whereEqualTo("email", cleanEmail).get().await()
                    if (!instQuery.isEmpty) {
                        val inst = instQuery.documents.first().toObject(InstructorProfile::class.java)
                        if (inst != null) {
                            val userProfile = UserProfile(
                                uid = inst.uid.ifBlank { uid },
                                name = inst.name,
                                email = inst.email,
                                role = "Dealer",
                                status = inst.status
                            )
                            currentRole = UserRole.INSTRUCTOR
                            currentInstructor = inst
                            if (context != null) {
                                saveSessionInfo(context, UserRole.INSTRUCTOR, uid = userProfile.uid)
                            }
                            return AuthResult.Success(userProfile)
                        }
                    }

                    // This Auth account exists in Firebase Auth but has no database document (deleted by Admin)
                    // Auto-delete the orphaned Auth user so they can register fresh
                    try {
                        auth.currentUser?.delete()?.await()
                        AuthResult.Error("Your account was removed by the administrator. The email record has been cleaned up; you can now register a new account with this email.")
                    } catch (_: Exception) {
                        AuthResult.Error("User profile not found in Institute database. Please register a new account.")
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback check for mobile-reset or Firestore-registered credentials
            try {
                val instDocQuery = firestore.collection("dealers").whereEqualTo("email", cleanEmail).get().await()
                if (!instDocQuery.isEmpty) {
                    val doc = instDocQuery.documents.first()
                    val inst = doc.toObject(InstructorProfile::class.java)
                    val storedTempPass = doc.getString("tempPassword")
                    if (inst != null && !storedTempPass.isNullOrBlank() && storedTempPass == cleanPassword) {
                        val userProfile = UserProfile(
                            uid = inst.uid.ifBlank { doc.id },
                            name = inst.name,
                            email = inst.email,
                            role = "Dealer",
                            status = inst.status
                        )
                        currentRole = UserRole.INSTRUCTOR
                        currentInstructor = inst
                        if (context != null) {
                            saveSessionInfo(context, UserRole.INSTRUCTOR, uid = userProfile.uid)
                        }
                        return AuthResult.Success(userProfile)
                    }
                }
            } catch (_: Exception) {}

            try {
                val traineeDocQuery = firestore.collection("staff").whereEqualTo("email", cleanEmail).get().await()
                if (!traineeDocQuery.isEmpty) {
                    val doc = traineeDocQuery.documents.first()
                    val trainee = doc.toObject(TraineeProfile::class.java)
                    val storedTempPass = doc.getString("tempPassword")
                    if (trainee != null && !storedTempPass.isNullOrBlank() && storedTempPass == cleanPassword) {
                        val userProfile = UserProfile(
                            uid = trainee.uid.ifBlank { doc.id },
                            name = trainee.name,
                            email = trainee.email,
                            role = "Staff",
                            status = trainee.status
                        )
                        currentRole = UserRole.TRAINEE
                        currentTrainee = trainee
                        if (context != null) {
                            saveSessionInfo(context, UserRole.TRAINEE, uid = userProfile.uid)
                        }
                        return AuthResult.Success(userProfile)
                    }
                }
            } catch (_: Exception) {}

            val msg = parseFirebaseError(e)
            AuthResult.Error(msg)
        }
    }

    /**
     * Parent Login using Trainee ID + Parent Access PIN
     */
    suspend fun parentLogin(traineeId: String, pin: String, context: android.content.Context? = null): AuthResult<TraineeProfile> {
        return try {
            val formattedId = traineeId.trim().uppercase()
            val query = firestore.collection("staff")
                .whereEqualTo("traineeId", formattedId)
                .get()
                .await()

            if (query.isEmpty) {
                return AuthResult.Error("No trainee found with Trainee ID: $formattedId")
            }

            val doc = query.documents.first()
            val trainee = doc.toObject(TraineeProfile::class.java)
                ?: return AuthResult.Error("Could not parse trainee record.")

            if (trainee.status != AccountStatus.APPROVED.statusName) {
                return AuthResult.Error("Trainee account is currently '${trainee.status}'. Parent monitoring is available once approved.")
            }

            if (trainee.parentAccessPin != pin.trim()) {
                return AuthResult.Error("Invalid Parent Access PIN. Please enter the 4-digit PIN provided by the institute.")
            }

            currentRole = UserRole.PARENT
            currentParentTrainee = trainee
            if (context != null) {
                saveSessionInfo(context, UserRole.PARENT, uid = trainee.uid, parentTraineeId = trainee.traineeId, parentPin = pin.trim())
            }
            AuthResult.Success(trainee)
        } catch (e: Exception) {
            AuthResult.Error(parseFirebaseError(e))
        }
    }

    /**
     * Register a new Instructor (Initial status = pending)
     */
    suspend fun registerInstructor(
        name: String,
        email: String,
        password: String,
        contact: String,
        tradeId: String,
        tradeName: String,
        aadhaarNo: String = "",
        panNo: String = "",
        businessAddress: String = "",
        residentialAddress: String = "",
        alternateNo: String = "",
        geoTagAddress: String = "",
        geoLatitude: Double? = null,
        geoLongitude: Double? = null,
        context: android.content.Context? = null
    ): AuthResult<InstructorProfile> {
        val cleanEmail = email.trim()
        val cleanPassword = password.trim()
        return try {
            val uid = try {
                val authResult = auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                authResult.user?.uid ?: throw Exception("Failed to get UID from registration")
            } catch (e: Exception) {
                val errorMsg = e.message.orEmpty()
                if (errorMsg.contains("email-already-in-use", ignoreCase = true) || errorMsg.contains("already in use", ignoreCase = true) || errorMsg.contains("in use", ignoreCase = true) || errorMsg.contains("already exists", ignoreCase = true)) {
                    // Check if this user profile exists in Firestore
                    val existingQuery = firestore.collection("users").whereEqualTo("email", cleanEmail).get().await()
                    if (existingQuery.isEmpty) {
                        // Orphaned Auth user from previously deleted profile - try signing in to clean it up
                        val signedInUser = try {
                            val res = auth.signInWithEmailAndPassword(cleanEmail, cleanPassword).await()
                            res.user
                        } catch (signInErr: Exception) {
                            try {
                                auth.sendPasswordResetEmail(cleanEmail).await()
                            } catch (_: Exception) {}
                            throw Exception("This email belonged to a deleted account with a different password. A password reset email was sent to $cleanEmail. Check your inbox to reset your password, or use your previous password.")
                        }

                        if (signedInUser != null) {
                            // Purge old Auth user record from Firebase Auth Console
                            try {
                                signedInUser.delete().await()
                            } catch (_: Exception) {}
                            
                            // Re-create user cleanly in Firebase Auth with new password
                            val freshAuthResult = try {
                                auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                            } catch (_: Exception) {
                                null
                            }
                            freshAuthResult?.user?.uid ?: signedInUser.uid
                        } else {
                            throw e
                        }
                    } else {
                        throw Exception("An active account with email '$cleanEmail' already exists in the system.")
                    }
                } else {
                    throw e
                }
            }

            val instructor = InstructorProfile(
                uid = uid,
                name = name.trim(),
                email = cleanEmail,
                contact = contact.trim(),
                aadhaarNo = aadhaarNo.trim(),
                panNo = panNo.trim().uppercase(),
                businessAddress = businessAddress.trim(),
                residentialAddress = residentialAddress.trim(),
                alternateNo = alternateNo.trim(),
                geoTagAddress = geoTagAddress.trim(),
                geoLatitude = geoLatitude,
                geoLongitude = geoLongitude,
                tradeId = tradeId,
                tradeName = tradeName,
                role = "Dealer",
                status = "pending",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val userProfile = UserProfile(
                uid = uid,
                name = name.trim(),
                email = cleanEmail,
                role = "Dealer",
                status = "pending",
                createdAt = System.currentTimeMillis()
            )

            // Save both to users and instructors collections
            firestore.collection("users").document(uid).set(userProfile).await()
            firestore.collection("dealers").document(uid).set(instructor).await()

            currentRole = UserRole.INSTRUCTOR
            currentInstructor = instructor
            if (context != null) {
                saveSessionInfo(context, UserRole.INSTRUCTOR, uid = uid)
            }
            AuthResult.Success(instructor)
        } catch (e: Exception) {
            AuthResult.Error(parseFirebaseError(e))
        }
    }

    /**
     * Register a new Trainee (Initial status = pending)
     */
    suspend fun registerTrainee(
        name: String,
        parentage: String,
        guardianContact: String = "",
        email: String,
        password: String,
        contact: String,
        address: String,
        tradeId: String,
        tradeName: String,
        instructorId: String,
        instructorName: String,
        context: android.content.Context? = null
    ): AuthResult<TraineeProfile> {
        val cleanEmail = email.trim()
        val cleanPassword = password.trim()
        return try {
            val uid = try {
                val authResult = auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                authResult.user?.uid ?: throw Exception("Failed to get UID from registration")
            } catch (e: Exception) {
                val errorMsg = e.message.orEmpty()
                if (errorMsg.contains("email-already-in-use", ignoreCase = true) || errorMsg.contains("already in use", ignoreCase = true) || errorMsg.contains("in use", ignoreCase = true) || errorMsg.contains("already exists", ignoreCase = true)) {
                    // Check if this user profile exists in Firestore
                    val existingQuery = firestore.collection("users").whereEqualTo("email", cleanEmail).get().await()
                    if (existingQuery.isEmpty) {
                        // Orphaned Auth user from previously deleted profile - try signing in to clean it up
                        val signedInUser = try {
                            val res = auth.signInWithEmailAndPassword(cleanEmail, cleanPassword).await()
                            res.user
                        } catch (signInErr: Exception) {
                            try {
                                auth.sendPasswordResetEmail(cleanEmail).await()
                            } catch (_: Exception) {}
                            throw Exception("This email belonged to a deleted account with a different password. A password reset email was sent to $cleanEmail. Check your inbox to reset your password, or use your previous password.")
                        }

                        if (signedInUser != null) {
                            // Purge old Auth user record from Firebase Auth Console
                            try {
                                signedInUser.delete().await()
                            } catch (_: Exception) {}
                            
                            // Re-create user cleanly in Firebase Auth with new password
                            val freshAuthResult = try {
                                auth.createUserWithEmailAndPassword(cleanEmail, cleanPassword).await()
                            } catch (_: Exception) {
                                null
                            }
                            freshAuthResult?.user?.uid ?: signedInUser.uid
                        } else {
                            throw e
                        }
                    } else {
                        throw Exception("An active account with email '$cleanEmail' already exists in the system.")
                    }
                } else {
                    throw e
                }
            }

            // Generate unique random 4-digit parent PIN
            val defaultPin = String.format("%04d", (1000..9999).random())

            val trainee = TraineeProfile(
                uid = uid,
                traineeId = "PENDING", // Will be assigned on approval
                name = name.trim(),
                parentage = parentage.trim(),
                guardianContact = guardianContact.trim(),
                email = cleanEmail,
                contact = contact.trim(),
                address = address.trim(),
                tradeId = tradeId,
                tradeName = tradeName,
                instructorId = instructorId,
                instructorName = instructorName,
                role = "Staff",
                status = "pending",
                parentAccessPin = defaultPin,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val userProfile = UserProfile(
                uid = uid,
                name = name.trim(),
                email = cleanEmail,
                role = "Staff",
                status = "pending",
                createdAt = System.currentTimeMillis()
            )

            firestore.collection("users").document(uid).set(userProfile).await()
            firestore.collection("staff").document(uid).set(trainee).await()

            currentRole = UserRole.TRAINEE
            currentTrainee = trainee
            if (context != null) {
                saveSessionInfo(context, UserRole.TRAINEE, uid = uid)
            }
            AuthResult.Success(trainee)
        } catch (e: Exception) {
            AuthResult.Error(parseFirebaseError(e))
        }
    }

    /**
     * Loads the specific profile corresponding to user role
     */
    suspend fun loadRoleSpecificProfile(userProfile: UserProfile) {
        val uid = userProfile.uid
        val role = UserRole.fromString(userProfile.role)
        currentRole = role

        when (role) {
            UserRole.ADMIN -> {
                val doc = firestore.collection("admins").document(uid).get().await()
                val fetchedAdmin = doc.toObject(AdminProfile::class.java)
                val resolvedName = when {
                    fetchedAdmin != null && fetchedAdmin.name.isNotBlank() && fetchedAdmin.name != "Institute Admin" -> fetchedAdmin.name
                    userProfile.name.isNotBlank() && userProfile.name != "Institute Admin" -> userProfile.name
                    else -> {
                        userProfile.email.substringBefore("@").replace(".", " ").split(" ")
                            .joinToString(" ") { word -> word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() } }
                            .ifBlank { "Admin" }
                    }
                }
                currentAdmin = (fetchedAdmin ?: AdminProfile(uid = uid, email = userProfile.email)).copy(name = resolvedName)
            }
            UserRole.INSTRUCTOR -> {
                val doc = firestore.collection("dealers").document(uid).get().await()
                currentInstructor = doc.toObject(InstructorProfile::class.java)
            }
            UserRole.TRAINEE -> {
                val doc = firestore.collection("staff").document(uid).get().await()
                currentTrainee = doc.toObject(TraineeProfile::class.java)
            }
            UserRole.PARENT -> {
                // Parent session handled separately
            }
        }
    }

    /**
     * Refresh active profile data from Firestore
     */
    suspend fun refreshCurrentProfile(): Boolean {
        val uid = auth.currentUser?.uid ?: return false
        return try {
            val userDoc = firestore.collection("users").document(uid).get().await()
            if (userDoc.exists()) {
                val profile = userDoc.toObject(UserProfile::class.java)
                if (profile != null) {
                    loadRoleSpecificProfile(profile)
                    true
                } else false
            } else false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Send Password Reset Email with pre-validation and clear sender details
     */
    suspend fun sendPasswordReset(email: String): AuthResult<String> {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank()) return AuthResult.Error("Please enter your registered email address.")

        return try {
            // Check if user exists in database first
            val userQuery = firestore.collection("users").whereEqualTo("email", cleanEmail).get().await()
            val instQuery = if (userQuery.isEmpty) firestore.collection("dealers").whereEqualTo("email", cleanEmail).get().await() else userQuery
            val traineeQuery = if (instQuery.isEmpty) firestore.collection("staff").whereEqualTo("email", cleanEmail).get().await() else instQuery

            if (traineeQuery.isEmpty && !cleanEmail.equals("admin@iti.edu", ignoreCase = true)) {
                return AuthResult.Error("No account found registered with email '$cleanEmail'. Please check the email address or use Instant Reset with your mobile number.")
            }

            auth.sendPasswordResetEmail(cleanEmail).await()
            AuthResult.Success("Password reset link has been dispatched to $cleanEmail.\n\n⚠️ IMPORTANT: If not found in your inbox within 2 minutes, please check your SPAM / JUNK folder for emails from 'noreply@arzan-pro.firebaseapp.com'.")
        } catch (e: Exception) {
            AuthResult.Error(parseFirebaseError(e))
        }
    }

    /**
     * Reset Instructor Password directly via Registered Mobile Number verification
     */
    suspend fun resetInstructorPasswordWithMobile(
        email: String,
        contact: String,
        newPassword: String
    ): AuthResult<String> {
        val cleanEmail = email.trim()
        val cleanContact = contact.trim().filter { it.isDigit() }
        val cleanNewPassword = newPassword.trim()

        if (cleanEmail.isBlank()) return AuthResult.Error("Please enter your registered email address.")
        if (cleanContact.length < 10) return AuthResult.Error("Please enter a valid 10-digit registered mobile number.")
        if (cleanNewPassword.length < 6) return AuthResult.Error("New password must be at least 6 characters.")

        return try {
            val instQuery = firestore.collection("dealers")
                .whereEqualTo("email", cleanEmail)
                .get()
                .await()

            val doc = instQuery.documents.firstOrNull() ?: run {
                val userQuery = firestore.collection("users")
                    .whereEqualTo("email", cleanEmail)
                    .get()
                    .await()
                userQuery.documents.firstOrNull()
            }

            if (doc == null) {
                return AuthResult.Error("No registered instructor found with email '$cleanEmail'. Please check the email or register a new profile.")
            }

            val docContact = doc.getString("contact")?.filter { it.isDigit() }.orEmpty()
            if (docContact.isNotBlank() && !docContact.endsWith(cleanContact.takeLast(10))) {
                return AuthResult.Error("Mobile number does not match the registered instructor contact on record for $cleanEmail.")
            }

            val uid = doc.id.ifBlank { doc.getString("uid").orEmpty() }
            val updates = mapOf(
                "tempPassword" to cleanNewPassword,
                "updatedAt" to System.currentTimeMillis()
            )

            if (uid.isNotBlank()) {
                try {
                    firestore.collection("dealers").document(uid).update(updates).await()
                } catch (_: Exception) {}
                try {
                    firestore.collection("users").document(uid).update(updates).await()
                } catch (_: Exception) {}
            }

            // Attempt sending reset link as well
            try {
                auth.sendPasswordResetEmail(cleanEmail).await()
            } catch (_: Exception) {}

            AuthResult.Success("Password reset successfully! You can now log in with your new password.")
        } catch (e: Exception) {
            AuthResult.Error(parseFirebaseError(e))
        }
    }

    /**
     * Reset Trainee Password directly via Registered Mobile Number and 4-digit Parent Access PIN verification
     */
    suspend fun resetTraineePasswordWithMobileAndPin(
        email: String,
        contact: String,
        parentAccessPin: String,
        newPassword: String
    ): AuthResult<String> {
        val cleanEmail = email.trim()
        val cleanContact = contact.trim().filter { it.isDigit() }
        val cleanPin = parentAccessPin.trim()
        val cleanNewPassword = newPassword.trim()

        if (cleanEmail.isBlank()) return AuthResult.Error("Please enter your registered email address.")
        if (cleanContact.length < 10) return AuthResult.Error("Please enter a valid 10-digit registered mobile number.")
        if (cleanPin.length != 4) return AuthResult.Error("Please enter a valid 4-digit Parent Access PIN.")
        if (cleanNewPassword.length < 6) return AuthResult.Error("New password must be at least 6 characters.")

        return try {
            val traineeQuery = firestore.collection("staff")
                .whereEqualTo("email", cleanEmail)
                .get()
                .await()

            val doc = traineeQuery.documents.firstOrNull() ?: run {
                val userQuery = firestore.collection("users")
                    .whereEqualTo("email", cleanEmail)
                    .get()
                    .await()
                userQuery.documents.firstOrNull()
            }

            if (doc == null) {
                return AuthResult.Error("No registered trainee found with email '$cleanEmail'. Please check the email or register.")
            }

            // Verify parent access PIN
            val docPin = doc.getString("parentAccessPin") ?: "1234"
            if (docPin != cleanPin) {
                return AuthResult.Error("Invalid Parent Access PIN. Please verify the 4-digit Parent PIN provided by the institute.")
            }

            // Verify contact
            val docContact = (doc.getString("contact") ?: doc.getString("guardianContact")).orEmpty().filter { it.isDigit() }
            if (docContact.isNotBlank() && !docContact.endsWith(cleanContact.takeLast(10))) {
                return AuthResult.Error("Mobile number does not match the registered trainee contact on record for $cleanEmail.")
            }

            val uid = doc.id.ifBlank { doc.getString("uid").orEmpty() }
            val updates = mapOf(
                "tempPassword" to cleanNewPassword,
                "updatedAt" to System.currentTimeMillis()
            )

            if (uid.isNotBlank()) {
                try {
                    firestore.collection("staff").document(uid).update(updates).await()
                } catch (_: Exception) {}
                try {
                    firestore.collection("users").document(uid).update(updates).await()
                } catch (_: Exception) {}
            }

            // Attempt sending reset link as well
            try {
                auth.sendPasswordResetEmail(cleanEmail).await()
            } catch (_: Exception) {}

            AuthResult.Success("Password reset successfully! You can now log in with your new password.")
        } catch (e: Exception) {
            AuthResult.Error(parseFirebaseError(e))
        }
    }

    fun logout(context: android.content.Context? = null) {
        clearSessionInfo(context)
    }

    private fun parseFirebaseError(e: Exception): String {
        val msg = e.localizedMessage ?: e.message ?: "An unexpected error occurred."
        return when {
            msg.contains("user-disabled", ignoreCase = true) ||
            msg.contains("USER_DISABLED", ignoreCase = true) ||
            msg.contains("disabled by an administrator", ignoreCase = true) ->
                "This account has been disabled. Please contact the Institute administrator for assistance."

            msg.contains("user-not-found", ignoreCase = true) ||
            msg.contains("USER_NOT_FOUND", ignoreCase = true) -> "No account found with this email."

            msg.contains("wrong-password", ignoreCase = true) ||
            msg.contains("invalid-credential", ignoreCase = true) ||
            msg.contains("invalid credential", ignoreCase = true) ||
            msg.contains("auth credential", ignoreCase = true) ||
            msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
            msg.contains("malformed or has expired", ignoreCase = true) -> "Invalid email or password. Please check your login credentials."

            msg.contains("too-many-requests", ignoreCase = true) ||
            msg.contains("TOO_MANY_ATTEMPTS_TRY_LATER", ignoreCase = true) -> "Too many failed attempts. Please try again later."

            msg.contains("API_KEY_NOT_FOUND", ignoreCase = true) ||
            msg.contains("API key not found", ignoreCase = true) ||
            msg.contains("The given apiKey is not found", ignoreCase = true) ||
            msg.contains("API key not valid", ignoreCase = true) ||
            msg.contains("API_KEY_INVALID", ignoreCase = true) -> 
                "Firebase Auth is not enabled for your project (arzan-pro). Please open Firebase Console -> Authentication -> Get Started and enable 'Email/Password' provider."

            msg.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
            msg.contains("OPERATION_NOT_ALLOWED", ignoreCase = true) -> 
                "Email/Password sign-in is not enabled in Firebase Console. Please enable Email/Password provider under Authentication > Sign-in method."

            msg.contains("email-already-in-use", ignoreCase = true) ||
            msg.contains("already in use", ignoreCase = true) ||
            msg.contains("in use", ignoreCase = true) -> "This email is already registered."
            msg.contains("weak-password", ignoreCase = true) -> "Password should be at least 6 characters."
            msg.contains("network", ignoreCase = true) -> "Network unavailable. Please check your internet connection."
            msg.contains("PERMISSION_DENIED", ignoreCase = true) -> "Access denied by Institute security rules."
            else -> msg
        }
    }
}
