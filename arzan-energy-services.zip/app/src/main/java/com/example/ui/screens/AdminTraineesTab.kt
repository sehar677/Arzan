package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.TraineeProfile
import com.example.data.model.Trade
import com.example.data.model.InstructorProfile
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge

@Composable
fun AdminTraineesTab(
    trainees: List<TraineeProfile>,
    pending: List<TraineeProfile>,
    trades: List<Trade> = emptyList(),
    instructors: List<InstructorProfile> = emptyList(),
    searchQuery: String,
    selectedTradeFilter: String?,
    onSearchChange: (String) -> Unit,
    onFilterChange: (String?) -> Unit,
    onApprove: (String) -> Unit,
    onReject: (String) -> Unit,
    onToggleStatus: (String, String) -> Unit,
    onDeleteTrainee: (TraineeProfile) -> Unit,
    onAddDiaryNote: (TraineeProfile) -> Unit = {},
    onModifyTrainee: (TraineeProfile) -> Unit = {},
    onAddStaff: (staffCode: String, name: String, parentage: String, guardianContact: String, email: String, pass: String, contact: String, address: String, tradeId: String, tradeName: String, onSuccess: () -> Unit) -> Unit
) {
    var isAddingStaff by remember { mutableStateOf(false) }
    var subTab by remember { mutableStateOf(0) }
    var localSearchQuery by remember { mutableStateOf(searchQuery) }

    if (isAddingStaff) {
        BackHandler { isAddingStaff = false }
        AdminAddStaffView(
            trades = trades,
            onBack = { isAddingStaff = false },
            onSubmit = { staffCode, name, parentage, guardianContact, email, pass, contact, address, tradeId, tradeName, onSuccess ->
                onAddStaff(staffCode, name, parentage, guardianContact, email, pass, contact, address, tradeId, tradeName) {
                    onSuccess()
                }
            }
        )
        return
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Top Header Row with title and +Add Staff button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Staff (${trainees.count { it.status == "approved" || it.status == "inactive" }})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Manage registered staff members & profiles",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = { isAddingStaff = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_add_staff")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("+Add Staff", fontWeight = FontWeight.Bold)
            }
        }

        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("Approved (${trainees.count { it.status == "approved" || it.status == "inactive" }})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_approved_staff")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Pending (${pending.size})", maxLines = 1, softWrap = false) },
                modifier = Modifier.testTag("tab_pending_staff")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = localSearchQuery,
            onValueChange = {
                localSearchQuery = it
                onSearchChange(it)
            },
            placeholder = { Text("Search by Name, Staff ID, or Email...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().testTag("input_search_staff"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        val baseList = (if (subTab == 0) {
            trainees.filter { it.status == "approved" || it.status == "inactive" }
        } else {
            pending
        }).distinctBy { it.uid }

        val filteredList = baseList.filter { staff ->
            localSearchQuery.isBlank() ||
                    staff.name.contains(localSearchQuery, ignoreCase = true) ||
                    staff.traineeId.contains(localSearchQuery, ignoreCase = true) ||
                    staff.email.contains(localSearchQuery, ignoreCase = true) ||
                    staff.contact.contains(localSearchQuery, ignoreCase = true)
        }.distinctBy { it.uid }

        if (filteredList.isEmpty()) {
            EmptyStateView(
                icon = Icons.Default.School,
                title = if (subTab == 0) "No Staff Members Found" else "No Pending Staff Registrations",
                subtitle = if (subTab == 0) "Try adjusting your search query." else "All staff registrations are reviewed."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(filteredList, key = { index, staff ->
                    if (staff.uid.isNotBlank()) "${staff.uid}_$index" else "staff_$index"
                }) { _, staff ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("staff_item_${staff.uid}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(staff.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    if (staff.traineeId.isNotBlank()) {
                                        Text("Staff Code: ${staff.traineeId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                    }
                                    Text(staff.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusBadge(status = staff.status)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            if (staff.tradeName.isNotBlank()) {
                                Text("Profile: ${staff.tradeName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            }

                            val dealer = instructors.firstOrNull { 
                                (it.uid.isNotBlank() && it.uid == staff.instructorId) ||
                                (it.name.isNotBlank() && it.name.equals(staff.instructorName, ignoreCase = true)) ||
                                (it.tradeId.isNotBlank() && it.tradeId == staff.tradeId)
                            }
                            val dealerName = dealer?.name?.ifBlank { staff.instructorName } ?: staff.instructorName
                            val dealerCode = dealer?.dealerCode.orEmpty()

                            if (dealerName.isNotBlank() || dealerCode.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f, fill = false)) {
                                            Text(
                                                text = "Dealer Name",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = dealerName.ifBlank { "Unassigned" },
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        if (dealerCode.isNotBlank()) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = "Dealer Code",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Text(
                                                    text = dealerCode,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Contact: ${staff.contact}", style = MaterialTheme.typography.bodySmall)
                            if (staff.address.isNotBlank()) {
                                Text("Address: ${staff.address}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            if (subTab == 0) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    OutlinedButton(
                                        onClick = { onToggleStatus(staff.uid, staff.status) },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .height(34.dp)
                                            .testTag("btn_toggle_staff_${staff.uid}")
                                    ) {
                                        Text(
                                            text = if (staff.status.equals("approved", ignoreCase = true)) "Deactivate" else "Activate",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.Top,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { onModifyTrainee(staff) },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier
                                                .height(34.dp)
                                                .testTag("btn_modify_staff_${staff.uid}")
                                        ) {
                                            Icon(
                                                Icons.Default.Edit,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "Modify",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeleteTrainee(staff) },
                                            modifier = Modifier
                                                .size(34.dp)
                                                .testTag("btn_delete_staff_${staff.uid}")
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete Staff",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            } else if (subTab == 1) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedButton(
                                        onClick = { onReject(staff.uid) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(36.dp).testTag("btn_reject_staff_${staff.uid}")
                                    ) {
                                        Text("Reject", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { onApprove(staff.uid) },
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(36.dp).testTag("btn_approve_staff_${staff.uid}")
                                    ) {
                                        Text("Approve & Assign ID", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
