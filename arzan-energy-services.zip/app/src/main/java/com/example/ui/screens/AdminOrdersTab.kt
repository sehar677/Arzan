package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InstructorProfile
import com.example.data.model.OrderItem
import com.example.data.model.OrderRecord
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminOrdersTab(
    orders: List<OrderRecord>,
    targetRole: String = "dealer", // "dealer" or "staff"
    instructors: List<InstructorProfile> = emptyList(),
    trainees: List<TraineeProfile> = emptyList(),
    trades: List<Trade> = emptyList(),
    adminName: String = "Admin",
    onUpdateOrderStatus: (orderId: String, newStatus: String, adminName: String) -> Unit,
    onCreateOrder: (OrderRecord) -> Unit,
    onDeleteOrder: (orderId: String, adminName: String) -> Unit,
    onDeleteAllOrders: () -> Unit,
    isDealerConsole: Boolean = false
) {
    var subTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<String?>(null) }
    var showCreateOrderDialog by remember { mutableStateOf(false) }
    var showOrderCreatedDialog by remember { mutableStateOf(false) }
    var orderToDelete by remember { mutableStateOf<OrderRecord?>(null) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }

    val isDealerMode = targetRole.equals("dealer", ignoreCase = true)
    val roleOrders = remember(orders, targetRole) {
        if (isDealerMode) {
            orders.filter { it.placedByRole.equals("dealer", ignoreCase = true) || it.placedByRole.isBlank() }
        } else {
            orders.filter { it.placedByRole.equals("staff", ignoreCase = true) }
        }
    }

    val pendingOrders = remember(roleOrders) {
        roleOrders.filter { it.orderStatus.equals("pending", ignoreCase = true) }
    }
    val processingOrders = remember(roleOrders) {
        roleOrders.filter { it.orderStatus.equals("processing", ignoreCase = true) }
    }
    val dispatchedOrders = remember(roleOrders) {
        roleOrders.filter { it.orderStatus.equals("dispatched", ignoreCase = true) }
    }
    val deliveredOrders = remember(roleOrders) {
        roleOrders.filter { it.orderStatus.equals("delivered", ignoreCase = true) }
    }
    val cancelledOrders = remember(roleOrders) {
        roleOrders.filter { it.orderStatus.equals("cancelled", ignoreCase = true) }
    }

    val baseList = when (subTab) {
        1 -> pendingOrders
        2 -> dispatchedOrders
        3 -> deliveredOrders
        4 -> cancelledOrders
        else -> roleOrders
    }

    val filteredOrders = remember(baseList, searchQuery, selectedStatusFilter) {
        baseList.filter { order ->
            val matchesSearch = searchQuery.isBlank() ||
                    order.orderId.contains(searchQuery, ignoreCase = true) ||
                    order.placedByName.contains(searchQuery, ignoreCase = true) ||
                    order.placedByContact.contains(searchQuery, ignoreCase = true) ||
                    order.profileName.contains(searchQuery, ignoreCase = true) ||
                    order.items.any { it.itemName.contains(searchQuery, ignoreCase = true) }

            val matchesStatus = selectedStatusFilter == null ||
                    order.orderStatus.equals(selectedStatusFilter, ignoreCase = true)

            matchesSearch && matchesStatus
        }
    }

    val totalOrdersValue = remember(roleOrders) {
        roleOrders.sumOf { it.totalAmount }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag(if (isDealerMode) "admin_dealer_orders_tab" else "admin_staff_orders_tab")
    ) {
        // Top Header Row with Title and '+ New Order' button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isDealerMode) "Dealer Orders (${roleOrders.size})" else "Staff Orders (${roleOrders.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { showCreateOrderDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("btn_create_order")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Create Order", fontWeight = FontWeight.Bold)
            }
            
            if (roleOrders.isNotEmpty()) {
                IconButton(
                    onClick = { showDeleteAllDialog = true },
                    modifier = Modifier.testTag("btn_delete_all_orders")
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Delete All Orders", tint = MaterialTheme.colorScheme.error)
                }
            }
        }

        // SubTabs Row
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 8.dp,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(10.dp)),
            divider = {}
        ) {
            Tab(
                selected = subTab == 0,
                onClick = { subTab = 0 },
                text = { Text("All (${roleOrders.size})", maxLines = 1) },
                modifier = Modifier.testTag("tab_orders_all")
            )
            Tab(
                selected = subTab == 1,
                onClick = { subTab = 1 },
                text = { Text("Pending (${pendingOrders.size})", maxLines = 1) },
                modifier = Modifier.testTag("tab_orders_pending")
            )
            Tab(
                selected = subTab == 2,
                onClick = { subTab = 2 },
                text = { Text("Dispatched (${dispatchedOrders.size})", maxLines = 1) },
                modifier = Modifier.testTag("tab_orders_dispatched")
            )
            Tab(
                selected = subTab == 3,
                onClick = { subTab = 3 },
                text = { Text("Delivered (${deliveredOrders.size})", maxLines = 1) },
                modifier = Modifier.testTag("tab_orders_delivered")
            )
            Tab(
                selected = subTab == 4,
                onClick = { subTab = 4 },
                text = { Text("Cancelled (${cancelledOrders.size})", maxLines = 1) },
                modifier = Modifier.testTag("tab_orders_cancelled")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { 
                Text(
                    text = if (isDealerMode) "Search by Order ID, Dealer, Profile, or Item..." else "Search by Order ID, Staff, Department, or Item...",
                    style = MaterialTheme.typography.bodySmall
                ) 
            },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search", modifier = Modifier.size(16.dp))
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_search_orders")
        )

        Spacer(modifier = Modifier.height(8.dp))



        Spacer(modifier = Modifier.height(10.dp))

        // Orders List
        if (filteredOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "No Orders Found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (searchQuery.isNotBlank() || selectedStatusFilter != null) 
                            "Try adjusting your search or filters." 
                        else if (isDealerMode) 
                            "No dealer orders recorded yet. Click 'Create Order' to place an order." 
                        else 
                            "No staff orders recorded yet. Click 'Create Order' to place an order.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredOrders, key = { it.orderId }) { order ->
                    OrderCard(
                        order = order,
                        adminName = adminName,
                        onUpdateStatus = { newStatus -> onUpdateOrderStatus(order.orderId, newStatus, adminName) },
                        onDelete = { orderToDelete = order }
                    )
                }
            }
        }
    }

    // Delete Confirmation Dialog
    if (orderToDelete != null) {
        val targetOrder = orderToDelete!!
        AlertDialog(
            onDismissRequest = { orderToDelete = null },
            icon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Order ${targetOrder.orderId}?") },
            text = { Text("Are you sure you want to delete this order placed by '${targetOrder.placedByName}'? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteOrder(targetOrder.orderId, adminName)
                        orderToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete All Confirmation Dialog
    if (showDeleteAllDialog) {
        val roleTitle = if (isDealerMode) "Dealer" else "Staff"
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            icon = { Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete All $roleTitle Orders?") },
            text = { Text("Are you sure you want to delete ALL $roleTitle orders? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAllOrders()
                        showDeleteAllDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Create Order Dialog
    if (showCreateOrderDialog) {
        CreateOrderDialog(
            initialRole = targetRole,
            instructors = instructors,
            trainees = trainees,
            trades = trades,
            onDismiss = { showCreateOrderDialog = false },
            onSubmit = { newOrder ->
                onCreateOrder(newOrder)
                showCreateOrderDialog = false
                showOrderCreatedDialog = true
            }
        )
    }
    if (showOrderCreatedDialog) {
        AlertDialog(
            onDismissRequest = { showOrderCreatedDialog = false },
            title = { Text("Success") },
            text = { Text("Order created successfully!") },
            confirmButton = {
                TextButton(onClick = { showOrderCreatedDialog = false }) { Text("OK") }
            }
        )
    }
}

@Composable
fun OrderMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = color
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun OrderCard(
    order: OrderRecord,
    adminName: String,
    onUpdateStatus: (String) -> Unit,
    onDelete: () -> Unit
) {
    var expandedItems by remember { mutableStateOf(false) }
    var showStatusMenu by remember { mutableStateOf(false) }
    var statusToConfirm by remember { mutableStateOf<String?>(null) }

    val isDealer = order.placedByRole.equals("dealer", ignoreCase = true)
    val roleBadgeColor = if (isDealer) ItiTertiary else ItiOrangeSecondary
    val roleBadgeLabel = if (isDealer) "DEALER ORDER" else "STAFF ORDER"
    val roleIcon = if (isDealer) Icons.Default.Badge else Icons.Default.School

    val (statusBg, statusFg) = when (order.orderStatus.lowercase()) {
        "pending" -> StatusLateOrange.copy(alpha = 0.15f) to StatusLateOrange
        "approved" -> Color(0xFF00796B).copy(alpha = 0.15f) to Color(0xFF00796B)
        "processing" -> ItiNavyPrimary.copy(alpha = 0.15f) to ItiNavyPrimary
        "dispatched" -> Color(0xFF5E35B1).copy(alpha = 0.15f) to Color(0xFF5E35B1)
        "delivered" -> StatusPresentGreen.copy(alpha = 0.15f) to StatusPresentGreen
        "cancelled" -> StatusAbsentRed.copy(alpha = 0.15f) to StatusAbsentRed
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("order_card_${order.orderId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Order ID, Role Badge, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = order.orderId,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        color = roleBadgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Icon(roleIcon, contentDescription = null, modifier = Modifier.size(12.dp), tint = roleBadgeColor)
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = roleBadgeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = roleBadgeColor,
                                fontSize = 10.sp
                            )
                        }
                    }
                }

                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = order.orderStatus,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = statusFg,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Placed By Information
            Text(
                text = order.placedByName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            if (order.profileName.isNotBlank()) {
                Text(
                    text = "Profile: ${order.profileName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (order.placedByContact.isNotBlank()) {
                Text(
                    text = "Contact: ${order.placedByContact}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (order.deliveryAddress.isNotBlank()) {
                Text(
                    text = "Delivery: ${order.deliveryAddress}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (order.orderDate.isNotBlank()) {
                Text(
                    text = "Date: ${order.orderDate}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Order Total Summary Banner
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${order.totalQuantity} items (${order.items.size} line items)",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                        Surface(
                            color = if (order.paymentStatus.equals("paid", ignoreCase = true)) StatusPresentGreen.copy(alpha = 0.15f) else StatusLateOrange.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = order.paymentStatus,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (order.paymentStatus.equals("paid", ignoreCase = true)) StatusPresentGreen else StatusLateOrange,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (order.totalAmount > 0.0) {
                        Text(
                            text = "₹${String.format("%,.2f", order.totalAmount)}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        Text(
                            text = "${order.totalQuantity} Items",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Expandable Items List
            if (order.items.isNotEmpty()) {
                TextButton(
                    onClick = { expandedItems = !expandedItems },
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(
                        imageVector = if (expandedItems) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (expandedItems) "Hide Items" else "View ${order.items.size} Ordered Items",
                        style = MaterialTheme.typography.labelMedium
                    )
                }

                if (expandedItems) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        order.items.forEachIndexed { idx, item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${idx + 1}. ${item.itemName}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (item.sizeOrVariant.isNotBlank()) {
                                        Text(
                                            text = item.sizeOrVariant,
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text(
                                    text = if (item.unitPrice > 0.0) 
                                        "${item.quantity} x ₹${String.format("%.0f", item.unitPrice)} = ₹${String.format("%.2f", item.subtotal)}"
                                    else 
                                        "Qty: ${item.quantity}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (idx < order.items.size - 1) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            }
                        }
                    }
                }
            }

            if (order.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Notes: ${order.notes}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Admin Action Row: Update Status & Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    OutlinedButton(
                        onClick = { showStatusMenu = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(36.dp).fillMaxWidth().testTag("btn_status_menu_${order.orderId}")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Status: ${order.orderStatus}",
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(14.dp))
                    }

                    DropdownMenu(
                        expanded = showStatusMenu,
                        onDismissRequest = { showStatusMenu = false }
                    ) {
                        listOf("Pending", "Processing", "Dispatched", "Delivered", "Cancelled").forEach { st ->
                            DropdownMenuItem(
                                text = { Text(st, fontWeight = if (order.orderStatus.equals(st, ignoreCase = true)) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    showStatusMenu = false
                                    statusToConfirm = st
                                }
                            )
                        }
                    }
                }
                if (statusToConfirm != null) {
                    AlertDialog(
                        onDismissRequest = { statusToConfirm = null },
                        title = { Text("Confirm Status Change") },
                        text = { Text("Are you sure you want to change order status to ${statusToConfirm}?") },
                        confirmButton = {
                            Button(onClick = {
                                onUpdateStatus(statusToConfirm!!)
                                statusToConfirm = null
                            }) { Text("Confirm") }
                        },
                        dismissButton = {
                            TextButton(onClick = { statusToConfirm = null }) { Text("Cancel") }
                        }
                    )
                }
                
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (order.orderStatus.equals("cancelled", ignoreCase = true)) {
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(34.dp).testTag("btn_delete_order_${order.orderId}")
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete Order",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// Active item model for order creation
data class ActiveOrderItem(
    val id: String = UUID.randomUUID().toString(),
    val itemName: String,
    val qty: String,
    val unit: String,
    val remarks: String
)

@Composable
fun CreateOrderDialog(
    initialRole: String = "dealer",
    instructors: List<InstructorProfile>,
    trainees: List<TraineeProfile>,
    trades: List<Trade>,
    onDismiss: () -> Unit,
    onSubmit: (OrderRecord) -> Unit
) {
    val generatedOrderId = remember {
        "ORD-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())}"
    }

    val isSingleDealer = instructors.size == 1 && initialRole.equals("dealer", ignoreCase = true)

    var placedByRole by remember { mutableStateOf(initialRole) } // "dealer" or "staff"
    var selectedPersonId by remember { mutableStateOf(if (isSingleDealer) instructors[0].uid else "") }
    var personName by remember { mutableStateOf(if (isSingleDealer) instructors[0].name else "") }
    var personContact by remember { mutableStateOf(if (isSingleDealer) instructors[0].contact else "") }
    var profileName by remember { mutableStateOf(if (isSingleDealer) instructors[0].tradeName else "") }
    var deliveryAddress by remember { mutableStateOf(if (isSingleDealer) (instructors[0].businessAddress.ifBlank { instructors[0].residentialAddress }) else "") }
    var notes by remember { mutableStateOf("") }

    // Item input states for adding items to Active list
    var currentItemName by remember { mutableStateOf("") }
    var currentQty by remember { mutableStateOf("1") }
    var currentUnit by remember { mutableStateOf("") }
    var currentRemarks by remember { mutableStateOf("") }

    // Active list
    val activeItems = remember { mutableStateListOf<ActiveOrderItem>() }

    var itemInputError by remember { mutableStateOf<String?>(null) }
    var validationError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Create Order",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = generatedOrderId,
                    onValueChange = {},
                    label = { Text("Order ID") },
                    leadingIcon = { Icon(Icons.Default.Receipt, contentDescription = null) },
                    enabled = false,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_order_id")
                )

                if (!isSingleDealer) {
                    // Placed by Role Segment
                    Text("Order Placed By:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = placedByRole == "dealer",
                            onClick = {
                                placedByRole = "dealer"
                                personName = ""
                                personContact = ""
                                deliveryAddress = ""
                            },
                            label = { Text("Dealer") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = placedByRole == "staff",
                            onClick = {
                                placedByRole = "staff"
                                personName = ""
                                personContact = ""
                                deliveryAddress = ""
                            },
                            label = { Text("Staff") },
                            leadingIcon = { Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(14.dp)) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }


                // 6. Select from list and set delivery address to selected existing customer
                if (placedByRole == "staff" && trainees.isNotEmpty()) {
                    var staffDropdownOpen by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { staffDropdownOpen = true },
                            modifier = Modifier.fillMaxWidth().testTag("btn_select_existing_staff")
                        ) {
                            Text(
                                text = personName.ifBlank { "Select Existing Staff Member" },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        DropdownMenu(
                            expanded = staffDropdownOpen,
                            onDismissRequest = { staffDropdownOpen = false }
                        ) {
                            trainees.filter { it.status == "approved" }.take(50).forEach { tr ->
                                DropdownMenuItem(
                                    text = { Text("${tr.name} (${tr.traineeId}) • ${tr.tradeName}") },
                                    onClick = {
                                        selectedPersonId = tr.uid
                                        personName = "${tr.name} (${tr.traineeId})"
                                        personContact = tr.contact
                                        profileName = tr.tradeName
                                        // 6. Set delivery address to selected existing customer/staff
                                        deliveryAddress = tr.address
                                        staffDropdownOpen = false
                                        validationError = null
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = personName,
                    onValueChange = { if (placedByRole != "dealer") { personName = it; validationError = null } },
                    label = { Text("Company Name *") },
                    enabled = placedByRole != "dealer",
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_customer_name")
                )

                if (placedByRole != "dealer") {
                    OutlinedTextField(
                        value = personContact,
                        onValueChange = { personContact = it },
                        label = { Text("Contact Phone / Email") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth().testTag("input_contact_phone")
                    )
                }

                // 5. Move 'Delivery Address' after 'Contact Phone' field box
                OutlinedTextField(
                    value = deliveryAddress,
                    onValueChange = { if (placedByRole != "dealer") { deliveryAddress = it } },
                    label = { Text("Delivery Address") },
                    placeholder = { Text("Shop / Business delivery address") },
                    enabled = placedByRole != "dealer",
                    modifier = Modifier.fillMaxWidth().testTag("input_delivery_address")
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 7. Add '+Add Item' button before Item name field
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Add Item Details",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // 1. Rename 'Order Item 1' field to 'Item Name'
                OutlinedTextField(
                    value = currentItemName,
                    onValueChange = { currentItemName = it; itemInputError = null },
                    label = { Text("Item Name *") },
                    placeholder = { Text("e.g. Classic Oxford Shoes, Rubber Soles") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_item_name")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = currentQty,
                        onValueChange = { currentQty = it },
                        label = { Text("Qnty") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_item_qnty")
                    )
                    OutlinedTextField(
                        value = currentUnit,
                        onValueChange = { currentUnit = it },
                        label = { Text("Unit") },
                        placeholder = { Text("Pairs / Pcs / Boxes") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("input_item_unit")
                    )
                }

                OutlinedTextField(
                    value = currentRemarks,
                    onValueChange = { currentRemarks = it },
                    label = { Text("Remarks") },
                    placeholder = { Text("Sizes, colors, specifications") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_item_remarks")
                )

                Button(
                    onClick = {
                        if (currentItemName.isBlank()) {
                            itemInputError = "Please enter an Item Name"
                        } else {
                            activeItems.add(
                                ActiveOrderItem(
                                    id = UUID.randomUUID().toString(),
                                    itemName = currentItemName.trim(),
                                    qty = currentQty.ifBlank { "1" }.trim(),
                                    unit = currentUnit.trim(),
                                    remarks = currentRemarks.trim()
                                )
                            )
                            currentItemName = ""
                            currentQty = "1"
                            currentUnit = ""
                            currentRemarks = ""
                            itemInputError = null
                            validationError = null
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_add_item")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("ADD ITEM", fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                // 7. Create Active list below the add item button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Active List (${activeItems.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (activeItems.isNotEmpty()) {
                        Text(
                            text = "Total Qty: ${activeItems.sumOf { it.qty.toIntOrNull() ?: 1 }}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (activeItems.isEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.ShoppingCart,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "No items in Active List yet.",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Enter Item Name, Qnty, Unit, Remarks and click '+ Add Item' above.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth().testTag("active_items_list"),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        activeItems.forEachIndexed { index, item ->
                            Card(
                                shape = RoundedCornerShape(8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("active_item_row_$index")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${index + 1}. ${item.itemName}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Qnty: ${item.qty}${if (item.unit.isNotBlank()) " ${item.unit}" else ""}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            if (item.remarks.isNotBlank()) {
                                                Text(
                                                    text = "• ${item.remarks}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }

                                    // 4/8. Add 'Delete' Action button against each item in the active list
                                    IconButton(
                                        onClick = { activeItems.removeAt(index) },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("btn_delete_active_item_$index")
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete item",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                        // Total Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Total Quantity",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${activeItems.sumOf { it.qty.toIntOrNull() ?: 0 }}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Order Notes / Instructions (Optional)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_order_notes")
                )

                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (personName.isBlank()) {
                        validationError = "Please enter the person or enterprise name."
                        return@Button
                    }
                    if (activeItems.isEmpty()) {
                        if (currentItemName.isNotBlank()) {
                            activeItems.add(
                                ActiveOrderItem(
                                    id = UUID.randomUUID().toString(),
                                    itemName = currentItemName.trim(),
                                    qty = currentQty.ifBlank { "1" }.trim(),
                                    unit = currentUnit.trim(),
                                    remarks = currentRemarks.trim()
                                )
                            )
                        } else {
                            validationError = "Please add at least one item to the Active List."
                            return@Button
                        }
                    }

                    val itemsList = activeItems.map { item ->
                        OrderItem(
                            itemId = item.id,
                            itemName = item.itemName,
                            quantity = item.qty.toIntOrNull() ?: 1,
                            unitPrice = 0.0,
                            sizeOrVariant = listOf(item.unit, item.remarks).filter { it.isNotBlank() }.joinToString(" • ")
                        )
                    }

                    val totalQty = itemsList.sumOf { it.quantity }
                    val dateFormatted = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                    val generatedOrderId = "ORD-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(Date())}"

                    val newRecord = OrderRecord(
                        orderId = generatedOrderId,
                        placedByRole = placedByRole,
                        placedById = selectedPersonId,
                        placedByName = personName.trim(),
                        placedByContact = personContact.trim(),
                        profileName = profileName.trim(),
                        items = itemsList,
                        totalAmount = 0.0,
                        totalQuantity = totalQty,
                        orderStatus = "Pending",
                        paymentStatus = "Pending",
                        deliveryAddress = deliveryAddress.trim(),
                        notes = notes.trim(),
                        orderDate = dateFormatted,
                        timestamp = System.currentTimeMillis()
                    )

                    onSubmit(newRecord)
                },
                modifier = Modifier.testTag("btn_place_order")
            ) {
                Text("Place Order", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, modifier = Modifier.testTag("btn_cancel_order")) {
                Text("Cancel")
            }
        }
    )
}
