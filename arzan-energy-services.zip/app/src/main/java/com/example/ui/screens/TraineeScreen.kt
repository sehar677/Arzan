package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountStatus
import com.example.data.model.AttendanceStatus
import com.example.data.model.InstituteNotification
import com.example.data.model.TraineeProfile
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodels.TraineeViewModel
import com.example.util.DateUtils
import com.example.util.NotificationPreferenceManager

enum class TraineeTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    ATTENDANCE("Attendance", Icons.Default.Checklist),
    TASKS("Tasks", Icons.Default.Assignment),
    NOTIFICATIONS("Notifications", Icons.Default.Campaign)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TraineeScreen(
    trainee: TraineeProfile,
    viewModel: TraineeViewModel,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(TraineeTab.ATTENDANCE) }

    var acknowledgedNotifIds by remember(trainee.uid) {
        mutableStateOf(NotificationPreferenceManager.getAcknowledgedNotificationIds(context, trainee.uid))
    }
    var showNotifHistoryDialog by remember { mutableStateOf(false) }
    val unacknowledgedNotifs = remember(uiState.notifications, acknowledgedNotifIds) {
        uiState.notifications.filter { it.notificationId !in acknowledgedNotifIds }
    }

    LaunchedEffect(trainee) {
        viewModel.setTrainee(trainee)
        // Automatically check GPS on launch
        viewModel.checkCurrentLocation(context)
    }

    Scaffold(
        topBar = {
            Column {
                ItiTopAppBar(
                    title = "Welcome, ${trainee.name}",
                    subtitle = "Trade: ${trainee.tradeName}",
                    roleLabel = "Staff",
                    notificationCount = uiState.notifications.size,
                    onNotificationClick = { selectedTab = TraineeTab.NOTIFICATIONS },
                    onRefresh = {
                        viewModel.loadTraineeData(trainee)
                        viewModel.checkCurrentLocation(context)
                    },
                    onLogout = onLogout
                )
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    shadowElevation = 3.dp
                ) {
                    TabRow(
                        selectedTabIndex = TraineeTab.entries.indexOf(selectedTab).coerceAtLeast(0),
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary,
                        divider = { HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)) }
                    ) {
                        TraineeTab.entries.forEach { tab ->
                            val isSelected = selectedTab == tab
                            Tab(
                                selected = isSelected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.title,
                                        modifier = Modifier.size(20.dp),
                                        tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                text = {
                                    Text(
                                        text = tab.title,
                                        maxLines = 1,
                                        softWrap = false,
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                },
                                modifier = Modifier.testTag("nav_trainee_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        androidx.activity.compose.BackHandler(enabled = selectedTab != TraineeTab.ATTENDANCE) {
            selectedTab = TraineeTab.ATTENDANCE
        }

        when (selectedTab) {
            TraineeTab.ATTENDANCE -> TraineeAttendanceTab(
                trainee = trainee,
                uiState = uiState,
                viewModel = viewModel,
                clipboardManager = clipboardManager,
                context = context,
                paddingValues = paddingValues
            )
            TraineeTab.TASKS -> StaffTasksTab(
                trainee = trainee,
                viewModel = viewModel,
                paddingValues = paddingValues
            )
            TraineeTab.NOTIFICATIONS -> TraineeNotificationsTab(
                trainee = trainee,
                notifications = uiState.notifications,
                onDeleteNotification = { viewModel.deleteNotification(it) },
                paddingValues = paddingValues
            )
        }
    }

    // High-Priority Institute Pop-up Window Dialog on Login / New Announcement
    if (unacknowledgedNotifs.isNotEmpty()) {
        InstituteNotificationPopupDialog(
            notifications = unacknowledgedNotifs,
            onDismiss = { ids ->
                NotificationPreferenceManager.markNotificationsAcknowledged(context, ids, trainee.uid)
                acknowledgedNotifIds = NotificationPreferenceManager.getAcknowledgedNotificationIds(context, trainee.uid)
            }
        )
    }

    // Historical Notifications List Dialog
    if (showNotifHistoryDialog) {
        NotificationHistoryDialog(
            notifications = uiState.notifications,
            onDismiss = { showNotifHistoryDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TraineeAttendanceTab(
    trainee: TraineeProfile,
    uiState: com.example.ui.viewmodels.TraineeUiState,
    viewModel: TraineeViewModel,
    clipboardManager: androidx.compose.ui.platform.ClipboardManager,
    context: android.content.Context,
    paddingValues: PaddingValues
) {
    var showPunchInConfirm by remember { mutableStateOf(false) }
    var showPunchOutConfirm by remember { mutableStateOf(false) }

    val formattedStaffId = remember(trainee.traineeId) {
        var id = trainee.traineeId
        if (id.startsWith("ITI-", ignoreCase = true)) {
            id = id.replaceFirst("ITI-", "STF-", ignoreCase = true)
        }
        val parts = id.split("-")
        if (parts.size == 3 && parts[0].equals("STF", ignoreCase = true)) {
            val seq = parts[2].padStart(5, '0')
            id = "STF-${parts[1]}-$seq"
        }
        id
    }

    // Month Selector for Recent Attendance Timeline (Defaults to current month)
    val currentMonthKey = remember {
        val today = DateUtils.getTodayDateString().replace("/", "-")
        val parts = today.split("-")
        if (parts.size >= 2) "${parts[0]}-${parts[1].padStart(2, '0')}" else today
    }
    var selectedMonthKey by remember { mutableStateOf(currentMonthKey) }
    var selectedDateForPicker by remember { mutableStateOf(DateUtils.getTodayDateString()) }
    var showMonthDatePickerDialog by remember { mutableStateOf(false) }

    // Filter attendance records by selected month
    val monthlyTimelineRecords = remember(uiState.attendanceHistory, selectedMonthKey) {
        uiState.attendanceHistory.filter { rec ->
            val recNorm = rec.date.replace("/", "-").trim()
            val parts = recNorm.split("-")
            val recMonth = if (parts.size >= 2) "${parts[0]}-${parts[1].padStart(2, '0')}" else recNorm
            recMonth == selectedMonthKey
        }.sortedByDescending { it.date }
    }

    // Material 3 Date Picker Dialog for Selecting Attendance Month
    if (showMonthDatePickerDialog) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                sdf.parse(selectedDateForPicker.replace("/", "-"))?.time
            } catch (_: Exception) { null }
        )
        DatePickerDialog(
            onDismissRequest = { showMonthDatePickerDialog = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedMillis = datePickerState.selectedDateMillis
                        if (selectedMillis != null) {
                            val pickedDate = DateUtils.formatUtcMillisToDate(selectedMillis)
                            selectedDateForPicker = pickedDate
                            val parts = pickedDate.split("-")
                            if (parts.size >= 2) {
                                selectedMonthKey = "${parts[0]}-${parts[1].padStart(2, '0')}"
                            }
                        }
                        showMonthDatePickerDialog = false
                    },
                    modifier = Modifier.testTag("btn_confirm_trainee_date_picker")
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showMonthDatePickerDialog = false },
                    modifier = Modifier.testTag("btn_cancel_trainee_date_picker")
                ) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Popup Window Dialog for Punch In / Punch Out Success
    if (uiState.message != null) {
        val isPunchInMessage = uiState.message?.contains("Punch In", ignoreCase = true) == true
        val isPunchOutMessage = uiState.message?.contains("Punch Out", ignoreCase = true) == true
        AlertDialog(
            onDismissRequest = { viewModel.clearMessages() },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Success",
                    tint = StatusPresentGreen,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = when {
                        isPunchInMessage -> "Punch In Successful"
                        isPunchOutMessage -> "Punch Out Successful"
                        else -> "Attendance Update"
                    },
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = uiState.message ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearMessages() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_dismiss_punch_dialog")
                ) {
                    Text("OK", fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // Confirmation Dialog for Punch In
    if (showPunchInConfirm) {
        AlertDialog(
            onDismissRequest = { showPunchInConfirm = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Login,
                    contentDescription = "Punch In Confirmation",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "Punch In Confirmation",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to punch in for today's attendance?",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPunchInConfirm = false
                        viewModel.punchIn(context)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_confirm_punch_in")
                ) {
                    Text("Punch In", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showPunchInConfirm = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_cancel_punch_in")
                ) {
                    Text("Cancel", fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    // Confirmation Dialog for Punch Out
    if (showPunchOutConfirm) {
        AlertDialog(
            onDismissRequest = { showPunchOutConfirm = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Logout,
                    contentDescription = "Punch Out Confirmation",
                    tint = StatusAbsentRed,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "Punch Out Confirmation",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to punch out? This action will finalize your daily attendance.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPunchOutConfirm = false
                        viewModel.punchOut(context)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAbsentRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_confirm_punch_out")
                ) {
                    Text("Punch Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = { showPunchOutConfirm = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("btn_cancel_punch_out")
                ) {
                    Text("Cancel", fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Trainee Identity Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("trainee_identity_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Staff Console",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = trainee.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Father: ${trainee.parentage}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusBadge(status = trainee.status)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Chips Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "ID: $formattedStaffId",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(formattedStaffId))
                                            Toast.makeText(context, "Staff ID copied: $formattedStaffId", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(16.dp).testTag("btn_copy_trainee_id")
                                    ) {
                                        Icon(
                                            Icons.Default.ContentCopy,
                                            contentDescription = "Copy Staff ID",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }

                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Text(
                                    text = trainee.tradeName,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Text(
                                text = "Parent PIN: ${trainee.parentAccessPin}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Alerts
            if (uiState.message != null) {
                item {
                    Surface(
                        color = StatusPresentGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(uiState.message ?: "", style = MaterialTheme.typography.bodySmall, color = StatusPresentGreen, fontWeight = FontWeight.Medium)
                            IconButton(onClick = { viewModel.clearMessages() }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusPresentGreen)
                            }
                        }
                    }
                }
            }

            if (uiState.error != null) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(uiState.error ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Medium)
                            IconButton(onClick = { viewModel.clearMessages() }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }
            }

            // Pending Approval Banner
            if (trainee.status != AccountStatus.APPROVED.statusName) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.PendingActions, contentDescription = null, tint = ItiOrangeSecondary, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Account Status: ${trainee.status.uppercase()}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = when (trainee.status.lowercase()) {
                                    "rejected" -> "Your admission was rejected: ${trainee.rejectionReason ?: "Please contact institute administration."}"
                                    "inactive" -> "Your account has been deactivated by the ITI Administration. Attendance marking is disabled."
                                    else -> "Your trainee registration is awaiting verification by the ITI Administration / Instructor. GPS Attendance punching will unlock upon approval."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }

            // GPS Geofence Status Card
            item {
                GeofenceDistanceCard(
                    distanceMeters = uiState.distanceResult?.distanceMeters,
                    isWithinRadius = uiState.distanceResult?.isWithinRadius,
                    radiusMeters = uiState.instituteSettings.radiusMeters,
                    isChecking = uiState.isLocationChecking,
                    onCheckGps = { viewModel.checkCurrentLocation(context) }
                )
            }

            // Today's Punch Action Card
            val isApproved = trainee.status == AccountStatus.APPROVED.statusName
            val isInsideRadius = uiState.distanceResult?.isWithinRadius == true
            val hasPunchedIn = uiState.todayAttendance?.punchInTime != null
            val hasPunchedOut = uiState.todayAttendance?.punchOutTime != null

            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("punch_actions_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "TODAY'S ATTENDANCE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = DateUtils.formatDateForDisplay(DateUtils.getTodayDateString()),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            StatusBadge(status = uiState.todayAttendance?.attendanceStatus ?: "not_marked")
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Status Info
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Punch In", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(DateUtils.formatTime(uiState.todayAttendance?.punchInTime), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                }
                                VerticalDivider(modifier = Modifier.height(28.dp), color = MaterialTheme.colorScheme.outlineVariant)
                                Column {
                                    Text("Punch Out", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(DateUtils.formatTime(uiState.todayAttendance?.punchOutTime), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Big Action Buttons
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            // PUNCH IN BUTTON (Natural Forest Green)
                            Button(
                                onClick = { showPunchInConfirm = true },
                                enabled = isApproved && isInsideRadius && !hasPunchedIn && !uiState.isLoading,
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary,
                                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(60.dp)
                                    .testTag("btn_punch_in")
                            ) {
                                if (uiState.isLoading && !hasPunchedIn) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                                } else {
                                    Icon(Icons.Default.Login, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("PUNCH IN", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                            }

                            // PUNCH OUT BUTTON (Organic Outline / Neutral Container)
                            Button(
                                onClick = { showPunchOutConfirm = true },
                                enabled = isApproved && isInsideRadius && hasPunchedIn && !hasPunchedOut && !uiState.isLoading,
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(60.dp)
                                    .testTag("btn_punch_out")
                            ) {
                                if (uiState.isLoading && hasPunchedIn && !hasPunchedOut) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.primary)
                                } else {
                                    Icon(Icons.Default.Logout, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("PUNCH OUT", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                            }
                        }

                        if (!isInsideRadius) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "⚠️ You must be within ${uiState.instituteSettings.radiusMeters.toInt()}m of the ITI campus to punch attendance.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusAbsentRed,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Attendance Statistics Summary - 3 Column Natural Cards
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("trainee_stats_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "ATTENDANCE SUMMARY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // 4-Metric Cards Row: Working Days, Present, Absent, Rate
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            // Present Working Days Card (Total Working Days)
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        "WORKING DAYS",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.5.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${uiState.totalDays}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text("Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                                }
                            }

                            // Present Days
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        "PRESENT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.5.sp,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${uiState.presentDays}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusPresentGreen
                                    )
                                    Text("Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                                }
                            }

                            // Absent Days
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        "ABSENT",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.5.sp,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${uiState.absentDays}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = StatusAbsentRed
                                    )
                                    Text("Days", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                                }
                            }

                            // Rate Card (Accent Primary)
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        "RATE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.5.sp,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${String.format("%.0f", uiState.attendancePercentage)}%",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Text("Overall", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f), fontSize = 10.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        LinearProgressIndicator(
                            progress = { (uiState.attendancePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = if (uiState.attendancePercentage >= 75.0) StatusPresentGreen else StatusLateOrange,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Enrolled Days: ${uiState.totalDays}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Late Arrivals: ${uiState.lateDays}", style = MaterialTheme.typography.bodySmall, color = StatusLateOrange, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }


            // Attendance History Section with Month-Wise Date Picker Filter
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Recent Attendance Timeline", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Showing month: ${DateUtils.formatYearMonthForDisplay(selectedMonthKey)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (selectedMonthKey != currentMonthKey) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "Filtered",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Month Date Picker Control Card
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth().testTag("card_trainee_month_filter")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                    shape = CircleShape,
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Default.CalendarMonth,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = DateUtils.formatYearMonthForDisplay(selectedMonthKey),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (selectedMonthKey == currentMonthKey) "Current Active Month" else "Selected via Date Picker",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            FilledTonalButton(
                                onClick = { showMonthDatePickerDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("btn_pick_trainee_attendance_date")
                            ) {
                                Icon(Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Select Date")
                            }
                        }

                        if (selectedMonthKey != currentMonthKey) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = {
                                        selectedMonthKey = currentMonthKey
                                        selectedDateForPicker = DateUtils.getTodayDateString()
                                    },
                                    modifier = Modifier.testTag("btn_reset_current_month")
                                ) {
                                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reset to Current Month")
                                }
                            }
                        }

                        // Summary chips for selected month
                        if (monthlyTimelineRecords.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            val monthPresent = monthlyTimelineRecords.count { it.attendanceStatus.equals("present", true) }
                            val monthLate = monthlyTimelineRecords.count { it.attendanceStatus.equals("late", true) }
                            val monthAbsent = monthlyTimelineRecords.count { it.attendanceStatus.equals("absent", true) }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Total", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${monthlyTimelineRecords.size}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Surface(
                                    color = StatusPresentGreen.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Present", style = MaterialTheme.typography.labelSmall, color = StatusPresentGreen, fontWeight = FontWeight.SemiBold)
                                        Text("$monthPresent", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StatusPresentGreen)
                                    }
                                }
                                Surface(
                                    color = StatusLateOrange.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Late", style = MaterialTheme.typography.labelSmall, color = StatusLateOrange, fontWeight = FontWeight.SemiBold)
                                        Text("$monthLate", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StatusLateOrange)
                                    }
                                }
                                Surface(
                                    color = StatusAbsentRed.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Absent", style = MaterialTheme.typography.labelSmall, color = StatusAbsentRed, fontWeight = FontWeight.SemiBold)
                                        Text("$monthAbsent", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = StatusAbsentRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (monthlyTimelineRecords.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth().testTag("empty_trainee_month_records")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Default.EventBusy,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = "No Records for ${DateUtils.formatYearMonthForDisplay(selectedMonthKey)}",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "There are no attendance records logged for this month.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                textAlign = TextAlign.Center
                            )
                            if (selectedMonthKey != currentMonthKey) {
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedButton(
                                    onClick = {
                                        selectedMonthKey = currentMonthKey
                                        selectedDateForPicker = DateUtils.getTodayDateString()
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.Today, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Show Current Month")
                                }
                            }
                        }
                    }
                }
            } else {
                items(monthlyTimelineRecords, key = { it.date }) { rec ->
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth().testTag("history_item_${rec.date}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(DateUtils.formatDateForDisplay(rec.date), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text("In: ${DateUtils.formatTime(rec.punchInTime)} • Out: ${DateUtils.formatTime(rec.punchOutTime)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                if (rec.remarks != null) {
                                    Text(rec.remarks, style = MaterialTheme.typography.labelSmall, color = StatusLateOrange)
                                }
                            }
                            StatusBadge(status = rec.attendanceStatus)
                        }
                    }
                }
            }

            // Developer Credit
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp, bottom = 16.dp, end = 4.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Developed By: V/I NAJEEB REHMAN :   Principal: Er. BILAL AHMAD WANI",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("developer_credit_trainee")
                    )
                }
            }
        }
    }

@Composable
fun TraineeNotificationsTab(
    trainee: TraineeProfile,
    notifications: List<InstituteNotification>,
    onDeleteNotification: (String) -> Unit,
    paddingValues: PaddingValues
) {
    var notifToDelete by remember { mutableStateOf<InstituteNotification?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Announcements & Notices (${notifications.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Broadcasts and alerts from administration and your trade instructor",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (notifications.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.NotificationsNone,
                    title = "No Announcements",
                    subtitle = "Broadcasts and notifications from administration and your trade instructor will appear here."
                )
            }
        } else {
            items(notifications, key = { it.notificationId }) { notif ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("card_trainee_notif_${notif.notificationId}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        val displayTitle = when {
                            notif.title.equals("Institute Announcement", ignoreCase = true) -> "Announcement"
                            notif.title.equals("Trade Registration Approved", ignoreCase = true) ||
                            notif.title.equals("Trainee Registration Approved", ignoreCase = true) -> "Registration Approved"
                            else -> notif.title
                        }
                        val displayMessage = if (notif.message.contains("Your trainee admission is approved", ignoreCase = true)) {
                            "Congratulations! Your Registration is approved. You can now punch daily attendance and handle Orders."
                        } else {
                            notif.message
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = displayTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${notif.senderName} • ${DateUtils.formatDateTime(notif.timestamp)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    color = if (notif.targetUserId == null) StatusPresentGreen.copy(alpha = 0.15f) else StatusLateOrange.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = if (notif.targetUserId == null) "ANNOUNCEMENT" else "PERSONAL ALERT",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (notif.targetUserId == null) StatusPresentGreen else StatusLateOrange,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = { notifToDelete = notif },
                                    modifier = Modifier.size(32.dp).testTag("btn_delete_trainee_notif_${notif.notificationId}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete Notification",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = displayMessage,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    if (notifToDelete != null) {
        val targetNotif = notifToDelete!!
        AlertDialog(
            onDismissRequest = { notifToDelete = null },
            icon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Delete Notification?") },
            text = { Text("Are you sure you want to delete this notification?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteNotification(targetNotif.notificationId)
                        notifToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { notifToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
