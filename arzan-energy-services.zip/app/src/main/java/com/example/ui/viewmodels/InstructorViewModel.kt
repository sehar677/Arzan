package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AttendanceRecord
import com.example.data.model.DashboardStats
import com.example.data.model.InstituteNotification
import com.example.data.model.DiaryNote
import com.example.data.model.InstructorProfile
import com.example.data.model.InstituteSettings
import com.example.data.model.OrderRecord
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.repository.AttendanceRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

data class TraineeAttendanceStat(
    val trainee: TraineeProfile,
    val presentDays: Int,
    val totalDays: Int,
    val percentage: Double
)

data class InstructorUiState(
    val isLoading: Boolean = false,
    val instructorProfile: InstructorProfile? = null,
    val currentTrade: Trade? = null,
    val stats: DashboardStats = DashboardStats(),
    val myTrainees: List<TraineeProfile> = emptyList(),
    val pendingTrainees: List<TraineeProfile> = emptyList(),
    val todayAttendance: List<AttendanceRecord> = emptyList(),
    val selectedDate: String = DateUtils.getTodayDateString(),
    val notifications: List<InstituteNotification> = emptyList(),
    val receivedAdminNotifications: List<InstituteNotification> = emptyList(),
    val diaryNotes: List<DiaryNote> = emptyList(),
    val searchQuery: String = "",
    val filterStatus: String = "all", // all, present, absent, late, pending
    val goodAttendanceCount: Int = 0,
    val poorAttendanceCount: Int = 0,
    val monthlyTraineeStats: List<TraineeAttendanceStat> = emptyList(),
    val monthlyTradeAttendancePercentage: Double = 0.0,
    val monthlyRecordedDaysCount: Int = 0,
    val message: String? = null,
    val error: String? = null,
    val selectedTraineeForHistory: TraineeProfile? = null,
    val traineeHistory: List<AttendanceRecord> = emptyList(),
    val instituteSettings: InstituteSettings = InstituteSettings(),
    val orders: List<OrderRecord> = emptyList()
)

class InstructorViewModel(
    private val repo: AttendanceRepository = AttendanceRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(InstructorUiState())
    val uiState: StateFlow<InstructorUiState> = _uiState.asStateFlow()

    fun setInstructor(instructor: InstructorProfile) {
        _uiState.update { it.copy(instructorProfile = instructor) }
        loadInstructorData(instructor.tradeId)
    }

    fun loadInstructorData(tradeId: String = "") {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            // Fetch everything in parallel using async
            val currentMonthStr = DateUtils.getTodayDateString().take(7)
            val instructorUid = _uiState.value.instructorProfile?.uid
            val effectiveTradeId = tradeId.ifBlank { _uiState.value.instructorProfile?.tradeId ?: "" }

            val profileDeferred = async { if (!instructorUid.isNullOrBlank()) repo.getInstructorProfile(instructorUid) else null }
            val tradeDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getTrade(effectiveTradeId) else null }
            val statsDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getTradeStats(effectiveTradeId) else DashboardStats() }
            val traineesDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getTraineesByTrade(effectiveTradeId) else emptyList() }
            val pendingDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getPendingTraineesByTrade(effectiveTradeId) else emptyList() }
            val attendanceDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getTradeAttendance(effectiveTradeId, _uiState.value.selectedDate) else emptyList() }
            val monthlyAttendanceDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getTradeMonthlyAttendance(effectiveTradeId, currentMonthStr) else emptyList() }
            val notifsDeferred = async { repo.getInstructorSentNotifications(instructorUid = instructorUid ?: "", tradeId = effectiveTradeId) }
            val adminNotifsDeferred = async { repo.getAllNotifications() }
            val diaryDeferred = async { if (effectiveTradeId.isNotBlank()) repo.getDiaryNotesForTrade(effectiveTradeId) else emptyList() }
            val settingsDeferred = async { repo.getInstituteSettings() }
            val ordersDeferred = async { repo.getAllOrders() }

            // Await all results simultaneously
            val freshProfile = profileDeferred.await()
            val currentTrade = tradeDeferred.await()
            val stats = statsDeferred.await()
            val trainees = traineesDeferred.await()
            val pending = pendingDeferred.await()
            val attendance = attendanceDeferred.await()
            val monthlyAttendance = monthlyAttendanceDeferred.await()
            val notifs = notifsDeferred.await()
            val allInstituteNotifs = adminNotifsDeferred.await()
            val instituteSettings = settingsDeferred.await()
            val orders = ordersDeferred.await()
            val adminNotifs = allInstituteNotifs.filter { notif ->
                val sr = (notif.senderRole ?: "").trim().lowercase()
                val isNotFromCurrentInstructor = (instructorUid.isNullOrBlank() || notif.senderUserId != instructorUid) &&
                        sr != "instructor" && sr != "dealer"

                val isNotEngine = notif.senderName != "Attendance Engine" &&
                        !notif.senderName.contains("Engine", ignoreCase = true) &&
                        sr != "system" &&
                        !notif.title.contains("Late Punch", ignoreCase = true) &&
                        !notif.title.contains("Punch In", ignoreCase = true) &&
                        !notif.title.contains("Punch Out", ignoreCase = true)

                isNotFromCurrentInstructor && isNotEngine
            }
            val diary = diaryDeferred.await()

            val approvedTrainees = trainees.filter { it.status == "approved" }
            val distinctRecordedDates = monthlyAttendance.map { it.date }.distinct()
            val totalRecordedDays = distinctRecordedDates.size

            var goodCount = 0
            var poorCount = 0
            var totalPresentOrLateSum = 0
            var totalPossiblePunches = 0
            val traineeStatsList = mutableListOf<TraineeAttendanceStat>()

            if (approvedTrainees.isNotEmpty() && totalRecordedDays > 0) {
                approvedTrainees.forEach { trainee ->
                    val traineeRecords = monthlyAttendance.filter { it.traineeId == trainee.uid }
                    val presentDays = traineeRecords.count { it.attendanceStatus == "present" || it.attendanceStatus == "late" }
                    totalPresentOrLateSum += presentDays
                    val rate = (presentDays.toDouble() / totalRecordedDays.toDouble()) * 100.0
                    if (rate >= 80.0) {
                        goodCount++
                    }
                    if (rate <= 60.0) {
                        poorCount++
                    }
                    traineeStatsList.add(
                        TraineeAttendanceStat(
                            trainee = trainee,
                            presentDays = presentDays,
                            totalDays = totalRecordedDays,
                            percentage = rate
                        )
                    )
                }
                totalPossiblePunches = approvedTrainees.size * totalRecordedDays
            } else if (approvedTrainees.isNotEmpty()) {
                approvedTrainees.forEach { trainee ->
                    traineeStatsList.add(
                        TraineeAttendanceStat(
                            trainee = trainee,
                            presentDays = 0,
                            totalDays = 0,
                            percentage = 0.0
                        )
                    )
                }
            }

            val monthlyTradePct = if (totalPossiblePunches > 0) {
                (totalPresentOrLateSum.toDouble() / totalPossiblePunches.toDouble()) * 100.0
            } else 0.0

            val resolvedTradeName = currentTrade?.tradeName?.ifBlank { null }
                ?: freshProfile?.tradeName?.ifBlank { null }
                ?: _uiState.value.instructorProfile?.tradeName ?: ""

            val updatedProfile = (freshProfile ?: _uiState.value.instructorProfile)?.copy(
                tradeName = resolvedTradeName
            )

            _uiState.update {
                it.copy(
                    isLoading = false,
                    instructorProfile = updatedProfile,
                    currentTrade = currentTrade,
                    stats = stats,
                    myTrainees = trainees,
                    pendingTrainees = pending,
                    todayAttendance = attendance,
                    goodAttendanceCount = goodCount,
                    poorAttendanceCount = poorCount,
                    monthlyTraineeStats = traineeStatsList,
                    monthlyTradeAttendancePercentage = monthlyTradePct,
                    monthlyRecordedDaysCount = totalRecordedDays,
                    notifications = notifs,
                    receivedAdminNotifications = adminNotifs,
                    diaryNotes = diary,
                    instituteSettings = instituteSettings,
                    orders = orders
                )
            }
        }
    }

    fun addDiaryNote(traineeId: String, traineeName: String, title: String, content: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        val currentTradeName = _uiState.value.currentTrade?.tradeName?.ifBlank { null } ?: instructor.tradeName
        if (title.isBlank() || content.isBlank() || traineeId.isBlank()) {
            _uiState.update { it.copy(error = "Trainee, Title, and Content are required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.addDiaryNote(
                traineeId = traineeId,
                traineeName = traineeName,
                tradeId = instructor.tradeId,
                tradeName = currentTradeName,
                instructorId = instructor.uid,
                instructorName = instructor.name,
                title = title,
                content = content
            )
            if (success) {
                _uiState.update { it.copy(message = "Diary note added successfully.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to add diary note.") }
            }
        }
    }

    fun deleteDiaryNote(noteId: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteDiaryNote(noteId)
            if (success) {
                _uiState.update { it.copy(message = "Diary note deleted successfully.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete diary note.") }
            }
        }
    }

    fun updateDiaryNote(noteId: String, title: String, content: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        if (title.isBlank() || content.isBlank() || noteId.isBlank()) {
            _uiState.update { it.copy(error = "Title and Content are required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateDiaryNote(noteId, title, content)
            if (success) {
                _uiState.update { it.copy(message = "Diary note updated successfully.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update diary note.") }
            }
        }
    }

    fun selectDate(date: String) {
        val tradeId = _uiState.value.instructorProfile?.tradeId ?: return
        viewModelScope.launch {
            val records = repo.getTradeAttendance(tradeId, date)
            _uiState.update { it.copy(selectedDate = date, todayAttendance = records) }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setFilterStatus(status: String) {
        _uiState.update { it.copy(filterStatus = status) }
    }

    fun approveTrainee(traineeUid: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.approveTrainee(traineeUid, instructor.uid, instructor.name, "instructor")
            if (success) {
                _uiState.update { it.copy(message = "Trainee approved and assigned unique Trainee ID.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to approve trainee.") }
            }
        }
    }

    fun rejectTrainee(traineeUid: String, reason: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.rejectTrainee(traineeUid, reason, instructor.uid, instructor.name, "instructor")
            if (success) {
                _uiState.update { it.copy(message = "Trainee application rejected.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to reject trainee.") }
            }
        }
    }

    fun correctAttendance(
        record: AttendanceRecord,
        newStatus: String,
        reason: String
    ) {
        val instructor = _uiState.value.instructorProfile ?: return
        if (reason.isBlank()) {
            _uiState.update { it.copy(error = "Correction reason is mandatory for the audit log.") }
            return
        }

        viewModelScope.launch {
            val success = repo.manualCorrectAttendance(
                attendanceId = record.attendanceId,
                traineeUid = record.traineeId,
                traineeUniqueId = record.traineeUniqueId,
                traineeName = record.traineeName,
                date = record.date,
                oldStatus = record.attendanceStatus,
                newStatus = newStatus,
                reason = reason,
                reviewerId = instructor.uid,
                reviewerName = instructor.name,
                reviewerRole = "instructor"
            )
            if (success) {
                _uiState.update { it.copy(message = "Attendance corrected and logged in audit trail.") }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(error = "Failed to update attendance correction.") }
            }
        }
    }

    fun viewTraineeHistory(trainee: TraineeProfile) {
        viewModelScope.launch {
            _uiState.update { it.copy(selectedTraineeForHistory = trainee, isLoading = true) }
            val history = repo.getTraineeAttendanceHistory(trainee.uid, trainee.traineeId)
            _uiState.update { it.copy(traineeHistory = history, isLoading = false) }
        }
    }

    fun clearTraineeHistorySelection() {
        _uiState.update { it.copy(selectedTraineeForHistory = null, traineeHistory = emptyList()) }
    }

    fun updateTraineeDetails(
        traineeUid: String,
        name: String,
        parentage: String,
        contact: String,
        guardianContact: String,
        address: String,
        onSuccess: (() -> Unit)? = null
    ) {
        val instructor = _uiState.value.instructorProfile ?: return
        val existingTrainee = _uiState.value.myTrainees.find { it.uid == traineeUid }
        val email = existingTrainee?.email ?: ""
        val parentAccessPin = existingTrainee?.parentAccessPin ?: "1234"

        if (name.isBlank()) {
            _uiState.update { it.copy(error = "Trainee name is required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.updateTraineeProfile(
                traineeUid = traineeUid,
                name = name,
                parentage = parentage,
                contact = contact,
                guardianContact = guardianContact,
                email = email,
                address = address,
                parentAccessPin = parentAccessPin,
                updatedBy = instructor.uid,
                updatedByName = instructor.name,
                updatedByRole = "instructor"
            )
            if (success) {
                _uiState.update { it.copy(message = "Trainee details updated successfully.") }
                loadInstructorData(instructor.tradeId)
                onSuccess?.invoke()
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update trainee details.") }
            }
        }
    }

    fun toggleTraineeStatus(traineeUid: String, currentStatus: String, onSuccess: (() -> Unit)? = null) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.toggleTraineeStatus(
                traineeUid = traineeUid,
                currentStatus = currentStatus,
                adminId = instructor.uid,
                adminName = instructor.name
            )
            if (success) {
                val newStatus = if (currentStatus.equals("approved", ignoreCase = true)) "inactive" else "approved"
                val actionWord = if (newStatus == "approved") "activated" else "deactivated"
                _uiState.update { state ->
                    val updatedList = state.myTrainees.map {
                        if (it.uid == traineeUid) it.copy(status = newStatus) else it
                    }
                    state.copy(
                        isLoading = false,
                        myTrainees = updatedList,
                        message = "Trainee $actionWord successfully."
                    )
                }
                onSuccess?.invoke()
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update trainee status.") }
            }
        }
    }

    suspend fun getAttendanceForDate(date: String): List<AttendanceRecord> {
        val instructor = _uiState.value.instructorProfile ?: return emptyList()
        val tradeId = instructor.tradeId
        val tradeName = _uiState.value.currentTrade?.tradeName?.ifBlank { null } ?: instructor.tradeName
        val traineeUids = _uiState.value.myTrainees.map { it.uid }.toSet() + _uiState.value.myTrainees.map { it.traineeId }.toSet()
        return repo.getTradeAttendance(
            tradeId = tradeId,
            date = date,
            tradeName = tradeName,
            traineeUids = traineeUids
        )
    }

    suspend fun getMonthlyAttendance(yearMonth: String): List<AttendanceRecord> {
        val instructor = _uiState.value.instructorProfile ?: return emptyList()
        val tradeId = instructor.tradeId
        val tradeName = _uiState.value.currentTrade?.tradeName?.ifBlank { null } ?: instructor.tradeName
        val traineeUids = _uiState.value.myTrainees.map { it.uid }.toSet() + _uiState.value.myTrainees.map { it.traineeId }.toSet()
        return repo.getTradeMonthlyAttendance(
            tradeId = tradeId,
            yearMonth = yearMonth,
            tradeName = tradeName,
            traineeUids = traineeUids
        )
    }

    fun sendTradeBroadcastNotification(
        title: String,
        message: String,
        targetUserId: String? = null,
        onSuccess: (() -> Unit)? = null
    ) {
        val instructor = _uiState.value.instructorProfile ?: return
        if (title.isBlank() || message.isBlank()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val senderLabel = "Instructor ${instructor.name} (${instructor.tradeName})"
            val success = repo.sendNotification(
                title = title,
                message = message,
                targetRole = "trainee",
                targetTradeId = instructor.tradeId,
                targetUserId = targetUserId,
                senderName = senderLabel,
                senderRole = "instructor",
                senderUserId = instructor.uid
            )
            if (success) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        message = "Broadcast notification sent successfully!"
                    )
                }
                onSuccess?.invoke()
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to send broadcast notification.") }
            }
        }
    }

    fun deleteNotification(notificationId: String) {
        val instructor = _uiState.value.instructorProfile
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteNotification(notificationId)
            if (success) {
                _uiState.update { state ->
                    val updatedNotifs = state.notifications.filter { it.notificationId != notificationId }
                    val updatedAdminNotifs = state.receivedAdminNotifications.filter { it.notificationId != notificationId }
                    state.copy(isLoading = false, notifications = updatedNotifs, receivedAdminNotifications = updatedAdminNotifs, message = "Notification deleted successfully.")
                }
                loadInstructorData(instructor?.tradeId ?: "")
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notification.") }
            }
        }
    }

    fun deleteNotifications(notificationIds: List<String>) {
        if (notificationIds.isEmpty()) return
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteNotifications(notificationIds)
            if (success) {
                _uiState.update { state ->
                    val updatedNotifs = state.notifications.filter { it.notificationId !in notificationIds }
                    state.copy(isLoading = false, notifications = updatedNotifs, message = "Notifications deleted successfully.")
                }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notifications.") }
            }
        }
    }

    fun deleteAllNotifications() {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val success = repo.deleteInstructorNotifications(instructor.uid, instructor.tradeId)
            if (success) {
                _uiState.update { state ->
                    state.copy(isLoading = false, notifications = emptyList(), message = "All sent notifications deleted.")
                }
                loadInstructorData(instructor.tradeId)
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete notifications.") }
            }
        }
    }

    fun updateDealerProfile(
        name: String,
        contact: String,
        aadhaarNo: String,
        panNo: String,
        businessAddress: String,
        residentialAddress: String,
        alternateNo: String
    ) {
        val instructor = _uiState.value.instructorProfile
        if (instructor == null || instructor.uid.isBlank()) {
            _uiState.update { it.copy(error = "Dealer profile not loaded.") }
            return
        }
        if (name.isBlank()) {
            _uiState.update { it.copy(error = "Dealer name is required.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val success = repo.updateDealerSelfProfile(
                instructorId = instructor.uid,
                name = name.trim(),
                contact = contact.trim(),
                aadhaarNo = aadhaarNo.trim(),
                panNo = panNo.trim(),
                businessAddress = businessAddress.trim(),
                residentialAddress = residentialAddress.trim(),
                alternateNo = alternateNo.trim()
            )
            if (success) {
                val refreshed = repo.getInstructorProfile(instructor.uid)
                val updated = refreshed ?: instructor.copy(
                    name = name.trim(),
                    contact = contact.trim(),
                    aadhaarNo = aadhaarNo.trim(),
                    panNo = panNo.trim(),
                    businessAddress = businessAddress.trim(),
                    residentialAddress = residentialAddress.trim(),
                    alternateNo = alternateNo.trim()
                )
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        instructorProfile = updated,
                        message = "Dealer profile updated successfully."
                    )
                }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update dealer profile.") }
            }
        }
    }

    fun createOrder(order: OrderRecord) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = repo.createNewOrder(order)
            if (result.isSuccess) {
                val updatedOrders = repo.getAllOrders()
                _uiState.update { it.copy(isLoading = false, orders = updatedOrders, message = "Order created successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to create order.") }
            }
        }
    }

    fun updateOrderStatus(orderId: String, status: String, userName: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = repo.updateOrderStatus(orderId, status, userName)
            if (result.isSuccess) {
                val updatedOrders = repo.getAllOrders()
                _uiState.update { it.copy(isLoading = false, orders = updatedOrders, message = "Order status updated.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to update order status.") }
            }
        }
    }

    fun deleteOrder(orderId: String, userName: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val result = repo.deleteOrder(orderId, userName)
            if (result.isSuccess) {
                val updatedOrders = repo.getAllOrders()
                _uiState.update { it.copy(isLoading = false, orders = updatedOrders, message = "Order deleted successfully.") }
            } else {
                _uiState.update { it.copy(isLoading = false, error = "Failed to delete order.") }
            }
        }
    }

    fun deleteDealerOrders(dealerId: String) {
        val instructor = _uiState.value.instructorProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val ordersList = _uiState.value.orders.filter { it.placedById == dealerId }
            var success = true
            for (ord in ordersList) {
                val res = repo.deleteOrder(ord.orderId, instructor.name)
                if (res.isFailure) success = false
            }
            val updatedOrders = repo.getAllOrders()
            if (success) {
                _uiState.update { it.copy(isLoading = false, orders = updatedOrders, message = "Dealer orders deleted.") }
            } else {
                _uiState.update { it.copy(isLoading = false, orders = updatedOrders, error = "Some orders could not be deleted.") }
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(message = null, error = null) }
    }
}
