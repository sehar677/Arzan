package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AdminProfile
import com.example.data.model.TaskRecord
import com.example.data.model.TraineeProfile
import com.example.ui.viewmodels.AdminViewModel
import com.example.util.DateUtils
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTasksTab(
    admin: AdminProfile,
    viewModel: AdminViewModel,
    paddingValues: PaddingValues = PaddingValues(0.dp),
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var showAddTaskDialog by remember { mutableStateOf(false) }
    var taskToDelete by remember { mutableStateOf<TaskRecord?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") } // "All", "Pending", "Completed", "Finished"
    var successDialogMessage by remember { mutableStateOf<String?>(null) }

    // Listen to ViewModel messages and errors
    LaunchedEffect(uiState.message) {
        uiState.message?.let {
            snackbarHostState.showSnackbar(it)
        }
    }
    LaunchedEffect(uiState.error) {
        uiState.error?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    // Filter tasks
    val filteredTasks = remember(uiState.tasks, searchQuery, selectedFilter) {
        uiState.tasks.filter { task ->
            val matchesFilter = when (selectedFilter) {
                "Pending" -> task.status.equals("Pending", ignoreCase = true)
                "Processing" -> task.status.equals("Processing", ignoreCase = true) || task.status.equals("In Progress", ignoreCase = true) || task.status.equals("Active", ignoreCase = true)
                "Completed" -> task.status.equals("Completed", ignoreCase = true)
                "Finished" -> task.status.equals("Finished", ignoreCase = true) || task.status.equals("Completed", ignoreCase = true)
                else -> true
            }
            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                task.id.lowercase().contains(q) ||
                task.staffName.lowercase().contains(q) ||
                task.staffUniqueId.lowercase().contains(q) ||
                task.description.lowercase().contains(q) ||
                task.createdDate.lowercase().contains(q)
            matchesFilter && matchesQuery
        }
    }

    val pendingCount = remember(uiState.tasks) {
        uiState.tasks.count { it.status.equals("Pending", ignoreCase = true) }
    }
    val processingCount = remember(uiState.tasks) {
        uiState.tasks.count { it.status.equals("Processing", ignoreCase = true) || it.status.equals("In Progress", ignoreCase = true) || it.status.equals("Active", ignoreCase = true) }
    }
    val completedCount = remember(uiState.tasks) {
        uiState.tasks.count { it.status.equals("Completed", ignoreCase = true) }
    }
    val finishedCount = remember(uiState.tasks) {
        uiState.tasks.count { it.status.equals("Finished", ignoreCase = true) || it.status.equals("Completed", ignoreCase = true) }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(paddingValues)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Assignment,
                                        contentDescription = "Tasks",
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "Active Tasks",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    Text(
                                        text = "Assign and track staff tasks with real-time sync",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }

                            IconButton(
                                onClick = { showAddTaskDialog = true },
                                modifier = Modifier.testTag("admin_add_task_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddTask,
                                    contentDescription = "Add Task",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        // Search and Filter Bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search by Task ID, Staff, Description...", style = MaterialTheme.typography.bodySmall) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Clear",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodySmall,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("admin_tasks_search_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surface,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surface
                            )
                        )

                        // Filter Chips
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = selectedFilter == "All",
                                onClick = { selectedFilter = "All" },
                                label = { Text("All (${uiState.tasks.size})", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 0.dp)) },
                                modifier = Modifier.height(30.dp),
                                leadingIcon = {
                                    if (selectedFilter == "All") {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    }
                                }
                            )
                            FilterChip(
                                selected = selectedFilter == "Pending",
                                onClick = { selectedFilter = "Pending" },
                                label = { Text("Pending ($pendingCount)", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 0.dp)) },
                                modifier = Modifier.height(30.dp),
                                leadingIcon = {
                                    if (selectedFilter == "Pending") {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    }
                                }
                            )
                            FilterChip(
                                selected = selectedFilter == "Processing",
                                onClick = { selectedFilter = "Processing" },
                                label = { Text("Processing ($processingCount)", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 0.dp)) },
                                modifier = Modifier.height(30.dp),
                                leadingIcon = {
                                    if (selectedFilter == "Processing") {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    }
                                }
                            )
                            FilterChip(
                                selected = selectedFilter == "Completed",
                                onClick = { selectedFilter = "Completed" },
                                label = { Text("Completed ($completedCount)", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 0.dp)) },
                                modifier = Modifier.height(30.dp),
                                leadingIcon = {
                                    if (selectedFilter == "Completed") {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    }
                                }
                            )
                            FilterChip(
                                selected = selectedFilter == "Finished",
                                onClick = { selectedFilter = "Finished" },
                                label = { Text("Finished ($finishedCount)", style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 0.dp)) },
                                modifier = Modifier.height(30.dp),
                                leadingIcon = {
                                    if (selectedFilter == "Finished") {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Tasks List
            if (uiState.isTasksLoading && uiState.tasks.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(36.dp))
                    }
                }
            } else if (filteredTasks.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AssignmentLate,
                                contentDescription = null,
                                modifier = Modifier.size(54.dp),
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                            )
                            Text(
                                text = if (searchQuery.isNotEmpty() || selectedFilter != "All") "No matching tasks found" else "No Active Tasks",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = if (searchQuery.isNotEmpty() || selectedFilter != "All") "Try adjusting your search query or filter" else "Click '+Task' above to assign a new task to staff.",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            )
                        }
                    }
                }
            } else {
                items(filteredTasks, key = { it.id }) { task ->
                    AdminTaskItemCard(
                        task = task,
                        onDeleteClick = { taskToDelete = task },
                        onStatusChange = { newStatus ->
                            viewModel.updateTaskStatus(
                                taskId = task.id,
                                newStatus = newStatus,
                                adminId = admin.uid,
                                adminName = admin.name
                            ) { success, msg ->
                                if (success) {
                                    successDialogMessage = "Task status successfully updated to $newStatus."
                                } else {
                                    scope.launch {
                                        snackbarHostState.showSnackbar(msg)
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )

        // Success Dialog for Status Change
        successDialogMessage?.let { msg ->
            AlertDialog(
                onDismissRequest = { successDialogMessage = null },
                title = { Text("Success") },
                text = { Text(msg) },
                confirmButton = {
                    Button(
                        onClick = { successDialogMessage = null },
                        modifier = Modifier.testTag("status_success_ok_btn")
                    ) {
                        Text("OK")
                    }
                }
            )
        }
    }

    // Add Task Dialog
    if (showAddTaskDialog) {
        AdminAddTaskDialog(
            admin = admin,
            staffList = uiState.trainees,
            isSaving = uiState.isTaskSaving,
            onDismiss = { showAddTaskDialog = false },
            onSaveTask = { staff, description ->
                viewModel.assignTask(
                    staffId = staff.uid,
                    staffName = staff.name,
                    staffUniqueId = staff.traineeId,
                    description = description,
                    adminId = admin.uid,
                    adminName = admin.name
                ) { success, msg ->
                    if (success) {
                        showAddTaskDialog = false
                    }
                    scope.launch {
                        snackbarHostState.showSnackbar(msg)
                    }
                }
            }
        )
    }

    // Delete Confirmation Dialog
    taskToDelete?.let { task ->
        AlertDialog(
            onDismissRequest = { taskToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Delete Task?",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Are you sure you want to delete this task?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Task ID: ${task.id}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Staff: ${task.staffName}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                text = "Description: ${task.description}",
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    Text(
                        text = "This operation will permanently remove the task from both admin and staff consoles.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.error
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val idToDelete = task.id
                        taskToDelete = null
                        viewModel.deleteTask(idToDelete, admin.uid, admin.name) { success, msg ->
                            scope.launch {
                                snackbarHostState.showSnackbar(msg)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.testTag("confirm_delete_task_btn")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { taskToDelete = null },
                    modifier = Modifier.testTag("cancel_delete_task_btn")
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AdminTaskItemCard(
    task: TaskRecord,
    onDeleteClick: () -> Unit,
    onStatusChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isCompleted = task.status.equals("Completed", ignoreCase = true) || task.status.equals("Finished", ignoreCase = true)
    val isProcessing = task.status.equals("Processing", ignoreCase = true) || task.status.equals("In Progress", ignoreCase = true)

    val badgeBgColor = when {
        isCompleted -> Color(0xFFE8F5E9)
        isProcessing -> Color(0xFFE3F2FD)
        else -> Color(0xFFFFF3E0)
    }
    val badgeBorderColor = when {
        isCompleted -> Color(0xFF81C784)
        isProcessing -> Color(0xFF64B5F6)
        else -> Color(0xFFFFB74D)
    }
    val badgeIcon = when {
        isCompleted -> Icons.Default.CheckCircle
        isProcessing -> Icons.Default.Sync
        else -> Icons.Default.HourglassTop
    }
    val badgeIconTint = when {
        isCompleted -> Color(0xFF2E7D32)
        isProcessing -> Color(0xFF1976D2)
        else -> Color(0xFFE65100)
    }
    val badgeText = when {
        isCompleted -> "Finished"
        isProcessing -> "Processing"
        else -> "Pending"
    }
    val badgeTextColor = when {
        isCompleted -> Color(0xFF1B5E20)
        isProcessing -> Color(0xFF0D47A1)
        else -> Color(0xFFBF360C)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(
            1.dp,
            when {
                isCompleted -> Color(0xFF2E7D32).copy(alpha = 0.35f)
                isProcessing -> Color(0xFF1976D2).copy(alpha = 0.35f)
                else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Row 1: Task ID, Created Date, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = task.id,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        )
                    }

                    Text(
                        text = "•  ${DateUtils.formatDateForDisplay(task.createdDate.ifBlank { "Today" })}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }

                // Status Badge
                Surface(
                    color = badgeBgColor,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, badgeBorderColor)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = badgeIcon,
                            contentDescription = task.status,
                            tint = badgeIconTint,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = badgeText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = badgeTextColor
                            )
                        )
                    }
                }
            }

            // Row 2: Staff Name and Staff ID
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Staff: ",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
                Text(
                    text = task.staffName,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold
                    )
                )
                if (task.staffUniqueId.isNotBlank()) {
                    Text(
                        text = "(${task.staffUniqueId})",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }

            // Row 3: Task Description
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Description:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            // Staff Remarks (if completed with remarks)
            if (task.remarks.isNotBlank()) {
                Surface(
                    color = Color(0xFFE8F5E9).copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFF81C784).copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Staff Remarks:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1B5E20)
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = task.remarks,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // Row 4: Completion Info, Status Dropdown & Delete Action Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isCompleted && !task.completedDate.isNullOrBlank()) {
                    Text(
                        text = "Completed: ${task.completedDate}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.Medium
                        )
                    )
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Status Dropdown Box
                    Box(
                        modifier = Modifier.wrapContentSize(Alignment.TopStart)
                    ) {
                        var statusDropdownExpanded by remember { mutableStateOf(false) }
                        val currentStatusDisplay = when {
                            task.status.equals("Finished", ignoreCase = true) || isCompleted -> "Finished"
                            task.status.equals("Processing", ignoreCase = true) || task.status.equals("In Progress", ignoreCase = true) -> "Processing"
                            else -> "Pending"
                        }

                        OutlinedButton(
                            onClick = { statusDropdownExpanded = true },
                            modifier = Modifier.testTag("status_dropdown_btn_${task.id}"),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Status: $currentStatusDisplay",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = statusDropdownExpanded,
                            onDismissRequest = { statusDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Pending") },
                                onClick = {
                                    statusDropdownExpanded = false
                                    onStatusChange("Pending")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Processing") },
                                onClick = {
                                    statusDropdownExpanded = false
                                    onStatusChange("Processing")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Finished") },
                                onClick = {
                                    statusDropdownExpanded = false
                                    onStatusChange("Finished")
                                }
                            )
                        }
                    }

                    // Delete Icon Button
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_task_btn_${task.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete Task",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAddTaskDialog(
    admin: AdminProfile,
    staffList: List<TraineeProfile>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSaveTask: (TraineeProfile, String) -> Unit
) {
    val autoGeneratedTaskId = remember {
        val datePart = DateUtils.getTodayDateString().replace("-", "").takeLast(6)
        val rand = (1000..9999).random()
        "TSK-$datePart-$rand"
    }
    val todayDateFormatted = remember {
        DateUtils.formatDateForDisplay(DateUtils.getTodayDateString())
    }

    var selectedStaff by remember { mutableStateOf<TraineeProfile?>(null) }
    var staffDropdownExpanded by remember { mutableStateOf(false) }
    var taskDescription by remember { mutableStateOf("") }

    var staffError by remember { mutableStateOf<String?>(null) }
    var descriptionError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = { if (!isSaving) onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("add_task_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Dialog Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddTask,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Assign New Task",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        enabled = !isSaving
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                // Auto-generated Task ID (read-only display)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Task ID",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = autoGeneratedTaskId,
                        onValueChange = {},
                        readOnly = true,
                        leadingIcon = {
                            Icon(Icons.Default.Tag, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("task_id_field"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    )
                }

                // 1. Select Staff Dropdown
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Select Staff *",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    ExposedDropdownMenuBox(
                        expanded = staffDropdownExpanded,
                        onExpandedChange = { if (!isSaving) staffDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedStaff?.let {
                                "${it.name}${if (it.traineeId.isNotBlank()) " (${it.traineeId})" else ""}"
                            } ?: "",
                            onValueChange = {},
                            readOnly = true,
                            placeholder = { Text("Choose a staff member") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = staffDropdownExpanded)
                            },
                            isError = staffError != null,
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .testTag("select_staff_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        ExposedDropdownMenu(
                            expanded = staffDropdownExpanded,
                            onDismissRequest = { staffDropdownExpanded = false }
                        ) {
                            if (staffList.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("No staff records found in system") },
                                    onClick = { staffDropdownExpanded = false },
                                    enabled = false
                                )
                            } else {
                                staffList.forEach { staff ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(
                                                    text = staff.name,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = if (staff.traineeId.isNotBlank()) "ID: ${staff.traineeId}" else "Email: ${staff.email}",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedStaff = staff
                                            staffError = null
                                            staffDropdownExpanded = false
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Default.AccountCircle, contentDescription = null)
                                        }
                                    )
                                }
                            }
                        }
                    }

                    if (staffError != null) {
                        Text(
                            text = staffError!!,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }

                // 2. Task Description Text Area
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Task Description *",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = taskDescription,
                        onValueChange = {
                            taskDescription = it
                            if (it.isNotBlank()) descriptionError = null
                        },
                        placeholder = { Text("Enter task details, instructions, or deliverables...") },
                        isError = descriptionError != null,
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("task_description_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    if (descriptionError != null) {
                        Text(
                            text = descriptionError!!,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.error
                            ),
                            modifier = Modifier.padding(start = 4.dp)
                        )
                    }
                }

                // 3. Task Created Date
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Task Created Date",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    OutlinedTextField(
                        value = todayDateFormatted,
                        onValueChange = {},
                        readOnly = true,
                        leadingIcon = {
                            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("task_created_date_field"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = onDismiss,
                        enabled = !isSaving,
                        modifier = Modifier.testTag("cancel_add_task_btn")
                    ) {
                        Text("Cancel")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            var hasError = false
                            if (selectedStaff == null) {
                                staffError = "Please select a staff member."
                                hasError = true
                            }
                            if (taskDescription.trim().isEmpty()) {
                                descriptionError = "Task description cannot be empty."
                                hasError = true
                            }
                            if (!hasError && selectedStaff != null) {
                                onSaveTask(selectedStaff!!, taskDescription.trim())
                            }
                        },
                        enabled = !isSaving,
                        modifier = Modifier.testTag("admin_save_task_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Saving...")
                        } else {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save Task")
                        }
                    }
                }
            }
        }
    }
}
