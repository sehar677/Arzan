package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.InstructorProfile
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.util.PrintTableUtils
import com.example.util.TradePrintItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeViewAndPrintSection(
    trades: List<Trade>,
    instructors: List<InstructorProfile>,
    trainees: List<TraineeProfile>
) {
    val context = LocalContext.current

    var selectedTradeId by remember { mutableStateOf<String?>(null) }
    val selectedTrade = remember(trades, selectedTradeId) {
        trades.find { it.tradeId == selectedTradeId }
    }
    val currentTradeName = selectedTrade?.tradeName ?: "All Profiles"
    var tradeDropdownExpanded by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }

    // Active approved/inactive instructors
    val approvedInstructors = remember(instructors) {
        instructors.filter { it.status == "approved" || it.status == "inactive" }
    }

    // Helper to find incharge instructor for a trade
    fun findInchargeInstructor(trade: Trade): InstructorProfile? {
        return approvedInstructors.firstOrNull { inst ->
            (inst.tradeId.isNotBlank() && inst.tradeId == trade.tradeId) ||
            (trade.tradeName.isNotBlank() && inst.tradeName.equals(trade.tradeName, ignoreCase = true))
        }
    }

    // Helper to count trainees in a trade
    fun getTraineeCountForTrade(trade: Trade): Int {
        val tId = trade.tradeId
        val tName = trade.tradeName
        return trainees.count { trainee ->
            (tId.isNotBlank() && trainee.tradeId == tId) ||
            (tName.isNotBlank() && trainee.tradeName.equals(tName, ignoreCase = true))
        }
    }

    // Filter trades based on selected profile and search query
    val printItems = remember(trades, approvedInstructors, trainees, selectedTradeId, selectedTrade, searchQuery) {
        // Map all trades to TradePrintItem
        val allTradeItems = trades.map { trade ->
            val incharge = findInchargeInstructor(trade)
            TradePrintItem(
                trade = trade,
                inchargeInstructorName = incharge?.name?.ifBlank { "Unassigned" } ?: "Unassigned",
                email = incharge?.email ?: "-",
                contactNo = incharge?.contact ?: "-",
                traineesCount = getTraineeCountForTrade(trade),
                instructorId = incharge?.uid ?: ""
            )
        }

        // Filter by selected profile if any
        val tradeFiltered = if (selectedTradeId == null) {
            allTradeItems
        } else {
            allTradeItems.filter { item -> item.trade.tradeId == selectedTradeId }
        }

        // Filter by search query
        if (searchQuery.isBlank()) {
            tradeFiltered.sortedBy { it.trade.tradeName.lowercase() }
        } else {
            val q = searchQuery.trim()
            tradeFiltered.filter { item ->
                item.trade.tradeName.contains(q, ignoreCase = true) ||
                item.trade.tradeCode.contains(q, ignoreCase = true) ||
                item.trade.duration.contains(q, ignoreCase = true) ||
                item.inchargeInstructorName.contains(q, ignoreCase = true) ||
                item.email.contains(q, ignoreCase = true) ||
                item.contactNo.contains(q, ignoreCase = true)
            }.sortedBy { it.trade.tradeName.lowercase() }
        }
    }

    val tableScrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Filter Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Row with 'Select Profile' dropdown filter and compact Action Buttons (PDF & Print)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Select Profile Dropdown Filter
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedCard(
                            onClick = { tradeDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("select_profile_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Icon(
                                        if (selectedTradeId == null) Icons.Default.Apps else Icons.Default.AccountBox,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text("Select Profile", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = if (selectedTradeId == null) "All Profiles (${trades.size})" else "$currentTradeName (${printItems.size})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (selectedTradeId != null) {
                                        IconButton(
                                            onClick = { selectedTradeId = null },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear profile filter", modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Icon(if (tradeDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = tradeDropdownExpanded,
                            onDismissRequest = { tradeDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Profiles (${trades.size})", fontWeight = if (selectedTradeId == null) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedTradeId = null
                                    tradeDropdownExpanded = false
                                },
                                leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null) },
                                modifier = Modifier.testTag("menu_item_all_profiles")
                            )
                            trades.forEach { trade ->
                                val count = getTraineeCountForTrade(trade)
                                DropdownMenuItem(
                                    text = { Text("${trade.tradeName} ($count Staff)", fontWeight = if (selectedTradeId == trade.tradeId) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedTradeId = trade.tradeId
                                        tradeDropdownExpanded = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.AccountBox, contentDescription = null) },
                                    modifier = Modifier.testTag("menu_item_profile_${trade.tradeId}")
                                )
                            }
                        }
                    }

                    // Save PDF Button (Compact)
                    OutlinedButton(
                        onClick = {
                            if (printItems.isEmpty()) {
                                Toast.makeText(context, "No profiles to save", Toast.LENGTH_SHORT).show()
                            } else {
                                val success = PrintTableUtils.saveTradesPdfToDownloads(
                                    context = context,
                                    items = printItems,
                                    instructorFilterName = currentTradeName
                                )
                                if (success) {
                                    Toast.makeText(context, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save PDF", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_save_trades_pdf")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF")
                    }

                    // Print Button (Compact)
                    Button(
                        onClick = {
                            if (printItems.isEmpty()) {
                                Toast.makeText(context, "No profiles to print", Toast.LENGTH_SHORT).show()
                            } else {
                                PrintTableUtils.printTradesTable(
                                    context = context,
                                    items = printItems,
                                    instructorFilterName = currentTradeName
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_print_trades_table")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Print", fontWeight = FontWeight.Bold)
                    }
                }

                // Quick Profile Filter Chips
                if (trades.isNotEmpty()) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            FilterChip(
                                selected = selectedTradeId == null,
                                onClick = { selectedTradeId = null },
                                label = { Text("All Profiles", style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = {
                                    Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp))
                                },
                                modifier = Modifier.testTag("chip_trade_all")
                            )
                        }
                        items(trades, key = { it.tradeId }) { trade ->
                            FilterChip(
                                selected = selectedTradeId == trade.tradeId,
                                onClick = {
                                    selectedTradeId = if (selectedTradeId == trade.tradeId) null else trade.tradeId
                                },
                                label = { Text(trade.tradeName, style = MaterialTheme.typography.labelSmall) },
                                leadingIcon = if (selectedTradeId == trade.tradeId) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                } else null,
                                modifier = Modifier.testTag("chip_trade_${trade.tradeId}")
                            )
                        }
                    }
                }

                // Compact Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search profile, code, dealer...", style = MaterialTheme.typography.bodySmall) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search", modifier = Modifier.size(14.dp))
                            }
                        }
                    },
                    textStyle = MaterialTheme.typography.bodySmall,
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("input_search_trades_table")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Table Content
        if (printItems.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.TableChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No profiles found for the selected dealer / search.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            // Horizontal scrollable table container
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
            ) {
                // Fixed column widths for consistent table styling
                val snoWidth = 50.dp
                val tradeWidth = 180.dp
                val tradeCodeWidth = 110.dp
                val durationWidth = 130.dp
                val inchargeWidth = 170.dp
                val emailWidth = 190.dp
                val contactWidth = 130.dp
                val traineesCountWidth = 135.dp
                val totalTableWidth = snoWidth + tradeWidth + tradeCodeWidth + durationWidth + inchargeWidth + emailWidth + contactWidth + traineesCountWidth

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(tableScrollState)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxHeight()) {
                        // Header Row
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                tonalElevation = 3.dp,
                                modifier = Modifier.width(totalTableWidth)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Sno",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )
                                    Text(
                                        text = "Profile",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(tradeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Profile Code",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(tradeCodeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Description",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(durationWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Incharge Dealer",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(inchargeWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Email",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(emailWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Contact No",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(contactWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "No. Of Staff",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(traineesCountWidth).padding(horizontal = 6.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }

                        // Table Body Rows
                        items(printItems.size) { index ->
                            val item = printItems[index]
                            val isEven = index % 2 == 0
                            val rowColor = if (isEven) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            }

                            Surface(
                                color = rowColor,
                                modifier = Modifier.width(totalTableWidth)
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Sno
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )

                                    // Trade
                                    Text(
                                        text = item.trade.tradeName.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .width(tradeWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Trade Code
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier
                                            .width(tradeCodeWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Text(
                                            text = item.trade.tradeCode.ifBlank { "-" },
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            textAlign = TextAlign.Center,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }

                                    // Description
                                    Text(
                                        text = item.trade.scheme.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(durationWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Incharge Instructor
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier
                                            .width(inchargeWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        if (item.inchargeInstructorName != "Unassigned") {
                                            Icon(
                                                Icons.Default.AccountCircle,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Text(
                                            text = item.inchargeInstructorName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (item.inchargeInstructorName != "Unassigned") FontWeight.SemiBold else FontWeight.Normal,
                                            color = if (item.inchargeInstructorName != "Unassigned") MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                        )
                                    }

                                    // Email
                                    Text(
                                        text = item.email,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .width(emailWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Contact No
                                    Text(
                                        text = item.contactNo,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(contactWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // No. Of Trainees
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .width(traineesCountWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Badge(
                                            containerColor = if (item.traineesCount > 0) {
                                                MaterialTheme.colorScheme.primaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (item.traineesCount > 0) {
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        ) {
                                            Text(
                                                text = "${item.traineesCount} Trainees",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }
    }
}
