package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.Trade
import com.example.data.model.TraineeProfile
import com.example.data.model.sortedByTraineeIdAscending
import com.example.ui.theme.ItiNavyPrimary
import com.example.util.PrintTableUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TraineeViewAndPrintSection(
    trainees: List<TraineeProfile>,
    trades: List<Trade> = emptyList(),
    fixedTradeName: String? = null,
    lockToOwnTrade: Boolean = false
) {
    val context = LocalContext.current

    var selectedTradeId by remember { mutableStateOf<String?>(null) }
    val selectedTrade = remember(trades, selectedTradeId) {
        trades.find { it.tradeId == selectedTradeId }
    }
    val currentTradeName = if (lockToOwnTrade) {
        fixedTradeName ?: trainees.firstOrNull()?.tradeName?.ifBlank { null } ?: "My Trade"
    } else {
        selectedTrade?.tradeName ?: "All Trades"
    }
    var tradeDropdownExpanded by remember { mutableStateOf(false) }

    var selectedTraineeUid by remember { mutableStateOf<String?>(null) }
    var traineeDropdownExpanded by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }

    // Filter trainees by selected trade, selected trainee filter, and optional search query
    val filteredTrainees = remember(trainees, selectedTradeId, selectedTrade, selectedTraineeUid, searchQuery, lockToOwnTrade) {
        val tradeFiltered = if (lockToOwnTrade || selectedTradeId == null) {
            trainees
        } else {
            val tName = selectedTrade?.tradeName ?: ""
            trainees.filter {
                it.tradeId == selectedTradeId || (tName.isNotBlank() && it.tradeName.equals(tName, ignoreCase = true))
            }
        }

        val traineeFiltered = if (selectedTraineeUid != null) {
            tradeFiltered.filter { it.uid == selectedTraineeUid || it.traineeId == selectedTraineeUid }
        } else {
            tradeFiltered
        }

        if (searchQuery.isBlank()) {
            traineeFiltered.sortedByTraineeIdAscending()
        } else {
            val q = searchQuery.trim()
            traineeFiltered.filter {
                it.name.contains(q, ignoreCase = true) ||
                it.traineeId.contains(q, ignoreCase = true) ||
                it.parentage.contains(q, ignoreCase = true) ||
                it.contact.contains(q, ignoreCase = true) ||
                it.guardianContact.contains(q, ignoreCase = true) ||
                it.address.contains(q, ignoreCase = true) ||
                it.tradeName.contains(q, ignoreCase = true)
            }.sortedByTraineeIdAscending()
        }
    }

    val tableScrollState = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Filter Card: Select Trade and Controls
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Trade available trainees for selection filter
                val tradeAvailableTrainees = remember(trainees, selectedTradeId, selectedTrade, lockToOwnTrade) {
                    val list = if (lockToOwnTrade || selectedTradeId == null) {
                        trainees
                    } else {
                        val tName = selectedTrade?.tradeName ?: ""
                        trainees.filter {
                            it.tradeId == selectedTradeId || (tName.isNotBlank() && it.tradeName.equals(tName, ignoreCase = true))
                        }
                    }
                    list.sortedByTraineeIdAscending()
                }

                val selectedTrainee = remember(tradeAvailableTrainees, selectedTraineeUid) {
                    tradeAvailableTrainees.find { it.uid == selectedTraineeUid || it.traineeId == selectedTraineeUid }
                }

                // Row with 'Select Trainee' filter and Action Buttons (Print & Save PDF)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Select Trainee Dropdown Filter
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedCard(
                            onClick = { traineeDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("select_trainee_dropdown_trigger"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f, fill = false)
                                ) {
                                    Icon(
                                        if (selectedTraineeUid == null) Icons.Default.People else Icons.Default.Person,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text("Select Trainee", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = if (selectedTrainee != null) "${selectedTrainee.name} (${selectedTrainee.traineeId})" else "All Trainees (${tradeAvailableTrainees.size})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (selectedTraineeUid != null) {
                                        IconButton(
                                            onClick = { selectedTraineeUid = null },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear trainee filter", modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    Icon(if (traineeDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = traineeDropdownExpanded,
                            onDismissRequest = { traineeDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Trainees (${tradeAvailableTrainees.size})", fontWeight = if (selectedTraineeUid == null) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedTraineeUid = null
                                    traineeDropdownExpanded = false
                                },
                                leadingIcon = { Icon(Icons.Default.People, contentDescription = null) }
                            )
                            tradeAvailableTrainees.forEach { t ->
                                DropdownMenuItem(
                                    text = { Text("${t.name} (${t.traineeId})", fontWeight = if (selectedTraineeUid == t.uid || selectedTraineeUid == t.traineeId) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedTraineeUid = t.uid.ifBlank { t.traineeId }
                                        traineeDropdownExpanded = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                                )
                            }
                        }
                    }

                    // Save PDF Button
                    OutlinedButton(
                        onClick = {
                            if (filteredTrainees.isEmpty()) {
                                Toast.makeText(context, "No trainees to save", Toast.LENGTH_SHORT).show()
                            } else {
                                val success = PrintTableUtils.saveTraineesPdfToDownloads(
                                    context = context,
                                    trainees = filteredTrainees,
                                    tradeFilterName = currentTradeName
                                )
                                if (success) {
                                    Toast.makeText(context, "PDF saved to Downloads folder", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save PDF", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_save_trainee_pdf")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PDF")
                    }

                    // Print Button
                    Button(
                        onClick = {
                            if (filteredTrainees.isEmpty()) {
                                Toast.makeText(context, "No trainees to print", Toast.LENGTH_SHORT).show()
                            } else {
                                PrintTableUtils.printTraineesTable(
                                    context = context,
                                    trainees = filteredTrainees,
                                    tradeFilterName = currentTradeName
                                )
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("btn_print_trainee_table")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Print", fontWeight = FontWeight.Bold)
                    }
                }

                if (!lockToOwnTrade) {
                    // Select Trade Dropdown
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = { tradeDropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth().testTag("select_trade_dropdown_trigger"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(
                                        if (selectedTradeId == null) Icons.Default.Apps else Icons.Default.Engineering,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Column {
                                        Text("Select Trade", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(
                                            text = if (selectedTradeId == null) "All Trades (${trainees.size} Staff)" else "$currentTradeName (${filteredTrainees.size} Staff)",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Icon(if (tradeDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }

                        DropdownMenu(
                            expanded = tradeDropdownExpanded,
                            onDismissRequest = { tradeDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("All Trades (${trainees.size})", fontWeight = if (selectedTradeId == null) FontWeight.Bold else FontWeight.Normal) },
                                onClick = {
                                    selectedTradeId = null
                                    tradeDropdownExpanded = false
                                },
                                leadingIcon = { Icon(Icons.Default.Apps, contentDescription = null) }
                            )
                            trades.forEach { trade ->
                                val count = trainees.count { it.tradeId == trade.tradeId || (trade.tradeName.isNotBlank() && it.tradeName.equals(trade.tradeName, ignoreCase = true)) }
                                DropdownMenuItem(
                                    text = { Text("${trade.tradeName} ($count)", fontWeight = if (selectedTradeId == trade.tradeId) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedTradeId = trade.tradeId
                                        tradeDropdownExpanded = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.Engineering, contentDescription = null) }
                                )
                            }
                        }
                    }

                    // Quick Trade Filter Chips
                    if (trades.isNotEmpty()) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedTradeId == null,
                                    onClick = { selectedTradeId = null },
                                    label = { Text("All Trades (${trainees.size})", style = MaterialTheme.typography.labelSmall) },
                                    leadingIcon = {
                                        Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp))
                                    },
                                    modifier = Modifier.testTag("chip_print_trade_all")
                                )
                            }
                            items(trades, key = { it.tradeId }) { trade ->
                                val count = trainees.count { it.tradeId == trade.tradeId || (trade.tradeName.isNotBlank() && it.tradeName.equals(trade.tradeName, ignoreCase = true)) }
                                FilterChip(
                                    selected = selectedTradeId == trade.tradeId,
                                    onClick = {
                                        selectedTradeId = if (selectedTradeId == trade.tradeId) null else trade.tradeId
                                    },
                                    label = { Text("${trade.tradeName} ($count)", style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("chip_print_trade_${trade.tradeCode.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Table Section
        if (filteredTrainees.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.TableChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No trainees found for the selected trade / search.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            // Horizontal scrollable table container
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
            ) {
                Box(modifier = Modifier.fillMaxSize().horizontalScroll(tableScrollState)) {
                    val snoWidth = 60.dp
                    val nameWidth = 180.dp
                    val parentageWidth = 160.dp
                    val addressWidth = 220.dp
                    val contactWidth = 140.dp
                    val fatherContactWidth = 160.dp
                    val tradeWidth = 160.dp

                    LazyColumn(modifier = Modifier.fillMaxHeight()) {
                        // Header Row
                        item {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                tonalElevation = 3.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Sno",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )
                                    Text(
                                        text = "Name",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(nameWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Parentage",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(parentageWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Address",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(addressWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Contact No",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(contactWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Father's contact No",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(fatherContactWidth).padding(horizontal = 6.dp)
                                    )
                                    Text(
                                        text = "Trade",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.width(tradeWidth).padding(horizontal = 6.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }

                        // Table Body Rows
                        items(filteredTrainees.size) { index ->
                            val trainee = filteredTrainees[index]
                            val isEven = index % 2 == 0
                            val rowColor = if (isEven) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            }

                            Surface(
                                color = rowColor,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Sno
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.width(snoWidth)
                                    )

                                    // Name & ID
                                    Column(
                                        modifier = Modifier
                                            .width(nameWidth)
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Text(
                                            text = trainee.name.ifBlank { "-" },
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (trainee.traineeId.isNotBlank()) {
                                            Text(
                                                text = trainee.traineeId,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = ItiNavyPrimary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    // Parentage
                                    Text(
                                        text = trainee.parentage.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(parentageWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Address
                                    Text(
                                        text = trainee.address.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .width(addressWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Contact No
                                    Text(
                                        text = trainee.contact.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier
                                            .width(contactWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Father's contact No
                                    Text(
                                        text = trainee.guardianContact.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (trainee.guardianContact.isNotBlank()) FontWeight.Medium else FontWeight.Normal,
                                        modifier = Modifier
                                            .width(fatherContactWidth)
                                            .padding(horizontal = 6.dp)
                                    )

                                    // Trade
                                    Text(
                                        text = trainee.tradeName.ifBlank { "-" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier
                                            .width(tradeWidth)
                                            .padding(horizontal = 6.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            }
        }
    }
}
