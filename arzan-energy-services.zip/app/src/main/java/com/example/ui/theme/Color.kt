package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Natural Tones - Light Theme Colors
val NaturalPrimary = Color(0xFF386B39)
val NaturalOnPrimary = Color(0xFFFFFFFF)
val NaturalPrimaryContainer = Color(0xFFD8E7D8)
val NaturalOnPrimaryContainer = Color(0xFF111F11)

val NaturalSecondary = Color(0xFF52634F)
val NaturalOnSecondary = Color(0xFFFFFFFF)
val NaturalSecondaryContainer = Color(0xFFD5E8CF)
val NaturalOnSecondaryContainer = Color(0xFF111F0F)

val NaturalTertiary = Color(0xFF386567)
val NaturalOnTertiary = Color(0xFFFFFFFF)
val NaturalTertiaryContainer = Color(0xFFBCEBEB)
val NaturalOnTertiaryContainer = Color(0xFF002021)

val NaturalBackgroundLight = Color(0xFFFBFDF8)
val NaturalOnBackgroundLight = Color(0xFF191C1A)
val NaturalSurfaceLight = Color(0xFFFFFFFF)
val NaturalOnSurfaceLight = Color(0xFF191C1A)
val NaturalSurfaceVariantLight = Color(0xFFF1F3EE)
val NaturalOnSurfaceVariantLight = Color(0xFF414941)
val NaturalOutlineLight = Color(0xFFC4D1C4)
val NaturalOutlineVariantLight = Color(0xFFE1E3DF)

// Natural Tones - Dark Theme Colors
val NaturalPrimaryDark = Color(0xFF9DD49E)
val NaturalOnPrimaryDark = Color(0xFF003913)
val NaturalPrimaryContainerDark = Color(0xFF1E5124)
val NaturalOnPrimaryContainerDark = Color(0xFFB9F0B8)

val NaturalSecondaryDark = Color(0xFFB9CCB3)
val NaturalOnSecondaryDark = Color(0xFF253423)
val NaturalSecondaryContainerDark = Color(0xFF3B4B38)
val NaturalOnSecondaryContainerDark = Color(0xFFD5E8CF)

val NaturalTertiaryDark = Color(0xFFA0CFD0)
val NaturalOnTertiaryDark = Color(0xFF003738)
val NaturalTertiaryContainerDark = Color(0xFF1E4D4F)
val NaturalOnTertiaryContainerDark = Color(0xFFBCEBEB)

val NaturalBackgroundDark = Color(0xFF111411)
val NaturalOnBackgroundDark = Color(0xFFE1E3DF)
val NaturalSurfaceDark = Color(0xFF191C19)
val NaturalOnSurfaceDark = Color(0xFFE1E3DF)
val NaturalSurfaceVariantDark = Color(0xFF414941)
val NaturalOnSurfaceVariantDark = Color(0xFFC4D1C4)
val NaturalOutlineDark = Color(0xFF8A9388)
val NaturalOutlineVariantDark = Color(0xFF414941)

// Backward Compatibility Aliases & Semantic Colors
val ItiNavyPrimary = NaturalPrimary
val ItiNavyOnPrimary = NaturalOnPrimary
val ItiNavyPrimaryContainer = NaturalPrimaryContainer
val ItiNavyOnPrimaryContainer = NaturalOnPrimaryContainer

val ItiOrangeSecondary = NaturalSecondary
val ItiOrangeOnSecondary = NaturalOnSecondary
val ItiOrangeSecondaryContainer = NaturalSecondaryContainer
val ItiOrangeOnSecondaryContainer = NaturalOnSecondaryContainer

val ItiTertiary = NaturalTertiary
val ItiOnTertiary = NaturalOnTertiary
val ItiTertiaryContainer = NaturalTertiaryContainer
val ItiOnTertiaryContainer = NaturalOnTertiaryContainer

val ItiBackgroundLight = NaturalBackgroundLight
val ItiOnBackgroundLight = NaturalOnBackgroundLight
val ItiSurfaceLight = NaturalSurfaceLight
val ItiOnSurfaceLight = NaturalOnSurfaceLight
val ItiSurfaceVariantLight = NaturalSurfaceVariantLight
val ItiOnSurfaceVariantLight = NaturalOnSurfaceVariantLight
val ItiOutlineLight = NaturalOutlineLight

// Status Colors - Organic Natural Palette
val StatusPresentGreen = Color(0xFF386B39)
val StatusLateOrange = Color(0xFF9C6800)
val StatusAbsentRed = Color(0xFFBA1A1A)
val StatusLeaveBlue = Color(0xFF2E627B)
val StatusPendingAmber = Color(0xFF8B6612)
