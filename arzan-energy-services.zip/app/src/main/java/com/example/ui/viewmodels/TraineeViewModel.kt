package com.example.ui.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AttendanceRecord
import com.example.data.model.DiaryNote
import com.example.data.model.DistanceResult
import com.example.data.model.InstituteNotification
import com.example.data.model.InstituteSettings
import com.example.data.model.TraineeProfile
import com.example.data.repository.AttendanceRepository
import com.example.util.DateUtils
import com.example.util.LocationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

data class TraineeUiState(
    val isLoading: Boolean = false,
    val isLocationChecking: Boolean = false,
    val traineeProfile: TraineeProfile? = null,
    val instituteSettings: InstituteSettings = InstituteSettings(),
    val todayAttendance: AttendanceRecord? = null,
    val attendanceHistory: List<AttendanceRecord> = emptyList(),
    val distanceResult: DistanceResult? = null,
    val notifications: List<InstituteNotification> = emptyList(),
    val diaryNotes: List<DiaryNote> = emptyList(),
    val tasks: List<com.example.data.model.TaskRecord> = emptyList(),
    val isTasksLoading: Boolean = false,
    val isTaskUpdating: Boolean = false,
    val attendancePercentage: Double = 0.0,
    val totalDays: Int = 0,
    val presentDays: Int = 0,
    val lateDays: Int = 0,
    val absentDays: Int = 0,
    val isLocationPermissionGranted: Boolean = false,
    val message: String? = null,
    val error: String? = null
)

class TraineeViewModel(
    private val repo: AttendanceRepository = AttendanceRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(TraineeUiState())
    val uiState: StateFlow<TraineeUiState> = _uiState.asStateFlow()

    private var tasksListener: com.google.firebase.firestore.ListenerRegistration? = null

    fun setTrainee(trainee: TraineeProfile) {
        _uiState.update { it.copy(traineeProfile = trainee) }
        loadTraineeData(trainee)
    }

    fun setLocationPermissionGranted(granted: Boolean) {
        _uiState.update { it.copy(isLocationPermissionGranted = granted) }
    }

    fun loadTraineeData(trainee: TraineeProfile) {
        tasksListener?.remove()
        tasksListener = repo.observeTasksForStaff(trainee.uid) { tasks ->
            _uiState.update { it.copy(tasks = tasks) }
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            // Run independent queries in parallel using async
            val latestProfileDeferred = async { repo.getTraineeProfile(trainee.uid) ?: trainee }
            val settingsDeferred = async { repo.getInstituteSettings() }
            val todayRecordDeferred = async { repo.getTodayAttendance(trainee.uid) }
            val historyDeferred = async { repo.getTraineeAttendanceHistory(trainee.uid) }
            val diaryDeferred = async { repo.getDiaryNotesForTrainee(trainee.uid) }

            val latestProfile = latestProfileDeferred.await()
            // Notifications for trainee: Admin broadcasts and trade instructor announcements
            val notifs = repo.getNotifications(role = "trainee", tradeId = latestProfile.tradeId, userId = latestProfile.uid)
            
            val settings = settingsDeferred.await()
            val todayRecord = todayRecordDeferred.await()
            val history = historyDeferred.await()
            val diary = diaryDeferred.await()

            // Compute statistics (excluding marked holidays from working days count)
            val holidayDates = settings.holidays.map { it.date.replace("/", "-").trim() }.toSet()
            val validWorkingRecords = history.filter { it.date.replace("/", "-").trim() !in holidayDates }

            val presentCount = validWorkingRecords.count { it.attendanceStatus.equals("present", ignoreCase = true) }
            val lateCount = validWorkingRecords.count { it.attendanceStatus.equals("late", ignoreCase = true) }
            val totalPresent = presentCount + lateCount
            val totalWorkingDays = validWorkingRecords.size
            val percent = if (totalWorkingDays > 0) {
                (totalPresent.toDouble() / totalWorkingDays.toDouble()) * 100.0
            } else 0.0

            _uiState.update {
                it.copy(
                    isLoading = false,
                    traineeProfile = latestProfile,
                    instituteSettings = settings,
                    todayAttendance = todayRecord,
                    attendanceHistory = history,
                    notifications = notifs,
                    diaryNotes = diary,
                    attendancePercentage = percent,
                    totalDays = totalWorkingDays,
                    presentDays = presentCount,
                    lateDays = lateCount,
                    absentDays = (totalWorkingDays - totalPresent).coerceAtLeast(0)
                )
            }
        }
    }

    /**
     * Check device GPS and calculate real-time distance to institute
     */
    fun checkCurrentLocation(context: Context) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLocationChecking = true, error = null) }
            val location = LocationHelper.getCurrentLocation(context)
            if (location == null) {
                _uiState.update {
                    it.copy(
                        isLocationChecking = false,
                        error = "Unable to retrieve device GPS location. Ensure Location Services / GPS is turned ON."
                    )
                }
                return@launch
            }

            val isMock = LocationHelper.isMockLocation(location)
            val settings = _uiState.value.instituteSettings
            val distResult = LocationHelper.verifyLocation(location.latitude, location.longitude, settings)

            _uiState.update {
                it.copy(
                    isLocationChecking = false,
                    distanceResult = distResult,
                    message = if (isMock) "Warning: Simulated location detected." else null
                )
            }
        }
    }

    /**
     * Perform GPS Punch In
     */
    fun punchIn(context: Context) {
        val trainee = _uiState.value.traineeProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            val location = LocationHelper.getCurrentLocation(context)
            if (location == null) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = "GPS Location unavailable. Please enable High Accuracy location and retry."
                    )
                }
                return@launch
            }

            val isMock = LocationHelper.isMockLocation(location)
            val result = repo.punchIn(trainee, location.latitude, location.longitude, isMock)

            if (result.isSuccess) {
                val record = result.getOrNull()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        todayAttendance = record,
                        message = "Punch In recorded successfully at ${DateUtils.formatTime(record?.punchInTime)}."
                    )
                }
                loadTraineeData(trainee)
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = result.exceptionOrNull()?.message ?: "Failed to punch in."
                    )
                }
            }
        }
    }

    /**
     * Perform GPS Punch Out
     */
    fun punchOut(context: Context) {
        val trainee = _uiState.value.traineeProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, message = null) }
            val location = LocationHelper.getCurrentLocation(context)
            if (location == null) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = "GPS Location unavailable. Please enable High Accuracy location and retry."
                    )
                }
                return@launch
            }

            val isMock = LocationHelper.isMockLocation(location)
            val result = repo.punchOut(trainee, location.latitude, location.longitude, isMock)

            if (result.isSuccess) {
                val record = result.getOrNull()
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        todayAttendance = record,
                        message = "Punch Out recorded successfully at ${DateUtils.formatTime(record?.punchOutTime)}."
                    )
                }
                loadTraineeData(trainee)
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = result.exceptionOrNull()?.message ?: "Failed to punch out."
                    )
                }
            }
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(message = null, error = null) }
    }

    fun deleteNotification(notificationId: String) {
        viewModelScope.launch {
            val success = repo.deleteNotification(notificationId)
            if (success) {
                _uiState.update { state ->
                    state.copy(notifications = state.notifications.filter { it.notificationId != notificationId })
                }
            }
        }
    }

    fun markTaskCompleted(
        taskId: String,
        remarks: String = "",
        onComplete: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        val currentTrainee = _uiState.value.traineeProfile ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isTaskUpdating = true, error = null) }
            val result = repo.markTaskCompleted(
                taskId = taskId,
                authenticatedStaffUid = currentTrainee.uid,
                staffName = currentTrainee.name,
                remarks = remarks
            )
            if (result.isSuccess) {
                _uiState.update { current ->
                    val updatedTasks = current.tasks.map { task ->
                        if (task.id == taskId) {
                            task.copy(
                                status = "Completed",
                                completedAt = System.currentTimeMillis(),
                                completedDate = DateUtils.formatDateTime(System.currentTimeMillis()),
                                remarks = remarks.trim()
                            )
                        } else task
                    }
                    current.copy(
                        isTaskUpdating = false,
                        tasks = updatedTasks,
                        message = "Task marked as completed."
                    )
                }
                onComplete(true, "Task marked as completed.")
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to mark task as completed."
                _uiState.update { it.copy(isTaskUpdating = false, error = err) }
                onComplete(false, err)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        tasksListener?.remove()
    }
}
