package com.example.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AttendanceRecord
import com.example.data.model.DiaryNote
import com.example.data.model.InstituteNotification
import com.example.data.model.TraineeProfile
import com.example.data.repository.AttendanceRepository
import com.example.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

data class ParentUiState(
    val isLoading: Boolean = false,
    val traineeProfile: TraineeProfile? = null,
    val todayAttendance: AttendanceRecord? = null,
    val attendanceHistory: List<AttendanceRecord> = emptyList(),
    val diaryNotes: List<DiaryNote> = emptyList(),
    val notifications: List<InstituteNotification> = emptyList(),
    val attendancePercentage: Double = 0.0,
    val totalWorkingDays: Int = 0,
    val presentDays: Int = 0,
    val lateDays: Int = 0,
    val absentDays: Int = 0,
    val error: String? = null
)

class ParentViewModel(
    private val repo: AttendanceRepository = AttendanceRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ParentUiState())
    val uiState: StateFlow<ParentUiState> = _uiState.asStateFlow()

    fun setLinkedTrainee(trainee: TraineeProfile) {
        _uiState.update { it.copy(traineeProfile = trainee) }
        loadTraineeMonitoringData(trainee)
    }

    fun loadTraineeMonitoringData(trainee: TraineeProfile) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            // Run independent queries concurrently in parallel using async
            val settingsDeferred = async { repo.getInstituteSettings() }
            val todayRecordDeferred = async { repo.getTodayAttendance(trainee.uid) }
            val historyDeferred = async { repo.getTraineeAttendanceHistory(trainee.uid) }
            val diaryDeferred = async { repo.getDiaryNotesForTrainee(trainee.uid) }
            val notifsDeferred = async { repo.getNotifications(role = "parent", tradeId = trainee.tradeId, userId = trainee.uid) }

            val settings = settingsDeferred.await()
            val todayRecord = todayRecordDeferred.await()
            val history = historyDeferred.await()
            val diary = diaryDeferred.await()
            val notifs = notifsDeferred.await()

            val holidayDates = settings.holidays.map { it.date.replace("/", "-").trim() }.toSet()
            val validWorkingRecords = history.filter { it.date.replace("/", "-").trim() !in holidayDates }

            val presentCount = validWorkingRecords.count { it.attendanceStatus.equals("present", ignoreCase = true) }
            val lateCount = validWorkingRecords.count { it.attendanceStatus.equals("late", ignoreCase = true) }
            val totalPresent = presentCount + lateCount
            val totalDays = validWorkingRecords.size
            val percentage = if (totalDays > 0) {
                (totalPresent.toDouble() / totalDays.toDouble()) * 100.0
            } else 0.0

            _uiState.update {
                it.copy(
                    isLoading = false,
                    todayAttendance = todayRecord,
                    attendanceHistory = history,
                    diaryNotes = diary,
                    notifications = notifs,
                    attendancePercentage = percentage,
                    totalWorkingDays = totalDays,
                    presentDays = presentCount,
                    lateDays = lateCount,
                    absentDays = (totalDays - totalPresent).coerceAtLeast(0)
                )
            }
        }
    }
}
