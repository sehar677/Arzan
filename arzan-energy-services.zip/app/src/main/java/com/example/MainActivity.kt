package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.AccountStatus
import com.example.data.model.UserRole
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.InstructorScreen
import com.example.ui.screens.ParentScreen
import com.example.ui.screens.TraineeScreen
import com.example.ui.theme.ItiAttendanceTheme
import com.example.ui.viewmodels.AdminViewModel
import com.example.ui.viewmodels.AuthViewModel
import com.example.ui.viewmodels.InstructorViewModel
import com.example.ui.viewmodels.ParentViewModel
import com.example.ui.viewmodels.TraineeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ItiAttendanceTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ItiAttendanceApp()
                }
            }
        }
    }
}

@Composable
fun ItiAttendanceApp(
    authViewModel: AuthViewModel = viewModel(),
    adminViewModel: AdminViewModel = viewModel(),
    instructorViewModel: InstructorViewModel = viewModel(),
    traineeViewModel: TraineeViewModel = viewModel(),
    parentViewModel: ParentViewModel = viewModel()
) {
    val context = LocalContext.current
    val authState by authViewModel.uiState.collectAsState()

    // Runtime Permission Request for Location & Notifications
    val permissionsToRequest = remember {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        list.toTypedArray()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocation = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseLocation = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        traineeViewModel.setLocationPermissionGranted(fineLocation || coarseLocation)
    }

    LaunchedEffect(Unit) {
        authViewModel.checkAutoLogin(context)
        permissionLauncher.launch(permissionsToRequest)
    }

    // Role-based Router
    val currentUser = authState.currentUserProfile
    val activeRole = authState.currentRole ?: authState.selectedRole

    when {
        currentUser != null && activeRole == UserRole.ADMIN && authState.currentAdmin != null -> {
            AdminScreen(
                admin = authState.currentAdmin!!,
                viewModel = adminViewModel,
                onLogout = { authViewModel.logout(context) }
            )
        }

        currentUser != null && activeRole == UserRole.INSTRUCTOR && authState.currentInstructor != null &&
                authState.currentInstructor?.status == AccountStatus.APPROVED.statusName -> {
            InstructorScreen(
                instructor = authState.currentInstructor!!,
                viewModel = instructorViewModel,
                onLogout = { authViewModel.logout(context) }
            )
        }

        currentUser != null && activeRole == UserRole.TRAINEE && authState.currentTrainee != null &&
                authState.currentTrainee?.status == AccountStatus.APPROVED.statusName -> {
            TraineeScreen(
                trainee = authState.currentTrainee!!,
                viewModel = traineeViewModel,
                onLogout = { authViewModel.logout(context) }
            )
        }

        activeRole == UserRole.PARENT && authState.currentParentTrainee != null -> {
            ParentScreen(
                trainee = authState.currentParentTrainee!!,
                viewModel = parentViewModel,
                onLogout = { authViewModel.logout(context) }
            )
        }

        else -> {
            // Auth / Login / Registration / Pending Screen
            AuthScreen(viewModel = authViewModel)
        }
    }
}
